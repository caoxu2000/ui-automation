import LoginPage from '../pageobjects/login.page';
import Home from '../pageobjects/home.page';

const config = require('config');


describe('Login Test', () => {

	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it('should login and see library table on home page', () => {

		let isExisting;

		browser.waitUntil(() => {
			isExisting = Home.libraryTable.isExisting()
			return isExisting;
		}, 3000, 'login takes more than 3 seconds to load the library element');
		browser.pause(5000);
    Home.closeVideoBtn.click();
    browser.pause(2000);
    // Home.closeBrowserSize.click();
    browser.actions([{
	    "type": "pointer",
	    "id": "doubleClick",
	    "parameters": {"pointerType": "mouse"},
	    "actions": [
	    	{"type": "pointerMove", "duration": 0, "x": 300, "y": 400},
	      {"type": "pointerDown", "button": 0},
	      {"type": "pointerUp", "button": 0},
	      {"type": "pointerDown", "button": 0},
	      {"type": "pointerUp", "button": 0}
	    ]
	  }]);

	  // release an action
	  browser.actions();
	  browser.debug();
		expect(isExisting).to.be.true;
		expect(browser.getUrl()).to.contain('library/processes');
		expect(browser.getTitle()).to.equal('Process Library');
		expect(Home.appTitleText.getText()).to.equal('PROCESS LIBRARY');

	});

})