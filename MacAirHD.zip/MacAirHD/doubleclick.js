browser.selectorExecute(selector, function(sel) {
    var event = new MouseEvent(
    	'dblclick',
    	{ 'view': window,
    	  'bubbles': true,
    	  'cancelable': true
    	});
    sel[0].dispatchEvent(event);
});

browser.waitUntil(() => {
   const found = (browser.elements('input.username').value.length > 0);
   if(found) {
     return $('input.username').getValue().length > 0;
  }
  return found;
});

browser.waitUntil(() => {
   return $('input.username').getValue().length > 0
});