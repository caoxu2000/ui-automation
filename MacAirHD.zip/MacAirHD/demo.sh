#!/bin/bash
npm run eng01 -- --spec test/specs/exportPlannedMultiValuesTests.js
npm run eng01 -- --spec test/specs/exportPlannedMultiValuesTests.js
npm run eng01 -- --spec test/specs/exportSingleValuedDataTests.js
npm run eng01 -- --spec test/specs/createConnetionBetweenStepsTests.js
