import LoginPage from '../pageobjects/login.page';
import Process from '../pageobjects/process.page';
import deleteProcess from '../pageobjects/delete.process.page';
import getRandomName from '../helpers/get_random_name';
import Task from '../pageobjects/task.page';
import Comment from '../pageobjects/comment.page';
import waitForElement from '../helpers/wait_for_element';

const config = require('config');
const expectedText = getRandomName();
const taskText = 'Add first procedure task';
const errMsg = 'element was not loaded';


describe('Edit Task Note of Step 1 in a Process Test', () => {

	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it('should update the Task note to the one was just entered', () => {

		Process.create(expectedText);
		browser.waitForElement(Comment.firstTaskStepText, config.app.waitTime,
			`firstTaskStepText ${errMsg}`);
		Task.delete1stTask();
		expect(Comment.firstTaskStepText.isExisting()).to.be.false;
		expect(Comment.addTaskBtn.getText()).to.equals(taskText.toUpperCase());
		// deleteProcess.delete(expectedText);

	});

});