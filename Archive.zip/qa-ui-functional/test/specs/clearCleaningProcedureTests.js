import LoginPage from '../pageobjects/login.page';
import Run from '../pageobjects/run.page';
import createRun from '../pageobjects/create.run.page';
import experimentOfProcess from '../pageobjects/create.experiment.page';
import getRandomName from '../helpers/get_random_name';
import getRandomNum from '../helpers/get_random_num';
import waitForElement from '../helpers/wait_for_element';

const config = require('config');
const testName = 'Clear Applied Cleaning Procedure Test';
const randomName = getRandomName();
const randomNumber = getRandomNum();
const errMsg = 'element was not loaded';


describe(testName, () => {

	it('should remove the applied cleaning rule and apply to a run', () => {

		LoginPage.login(config.app.admin.username, config.app.admin.password);
		experimentOfProcess.createConnectedSteps(randomName);
		createRun.create1RunAtATime(randomName);
		Run.addMultiValueRuns();
		Run.createNewCleaningProcedure(randomName);
		browser.pause(config.app.waitTime);
		Run.clearProcedureFromStep();
		let val = '';
		for (let i = 0; i <= 4; i++) {
			val += Run.cleaningRule8thCol[i].getText() ;
		}
		console.log(val);
		expect(val == '12345' || val == '54321').to.be.true;

	});
});
