import LoginPage from '../pageobjects/login.page';
import getRandomName from '../helpers/get_random_name';
import Home from '../pageobjects/home.page';
import ResourceInventory from '../pageobjects/resource.inventory.page';
import Resource from '../pageobjects/resource.page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const randomName = getRandomName() + 'uitest12345';
const errMsg = 'element was not loaded';


describe('Delete Resource Test', () => {

	it('resource should be deleted', () => {

		LoginPage.login(config.app.admin.username,
			config.app.admin.password);
		Resource.create(randomName);
		browser.waitForElement(ResourceInventory.findResource,
			config.app.waitTime, `Find Resource Search Input Field ${errMsg}`);
		ResourceInventory.findResource.setValue(randomName);
		browser.keys(['Enter']);
		browser.waitForElement($(`td*=${randomName}`),
			config.app.waitTime, `resource row ${errMsg}`);
		$(`td*=${randomName}`).rightClick();
		browser.waitForElement(Home.delete,
			config.app.waitTime, `Delete in Context menu ${errMsg}`);
    Home.delete.click();
    browser.waitForElement(Home.confirm,
			config.app.waitTime, `Delete button in popup ${errMsg}`);
		Home.confirm.click();
		browser.pause(config.app.waitTime);
		browser.waitForElement(Resource.newResourceSearch,
			config.app.waitTime, `New Resouce Search Icon ${errMsg}`);
		Resource.newResourceSearch.click();
		browser.waitForElement(ResourceInventory.findResource,
			config.app.waitTime, `Find Resource Search Input Field ${errMsg}`);
		ResourceInventory.findResource.setValue(randomName);
		browser.keys(['Enter']);
		browser.pause(config.app.waitTime);
    expect($(`td*=${randomName}`).isExisting()).to.be.false;
    expect(Home.noSearchResults.isExisting()).to.be.true;
    expect(Home.noSearchResults.getText()).to.equal('No search results found.');

	});

});
