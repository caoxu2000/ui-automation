import LoginPage from '../pageobjects/login.page';
import Step from '../pageobjects/step.page';
import Resource from '../pageobjects/resource.page';
import waitForElement from '../helpers/wait_for_element';
import Process from '../pageobjects/process.page';
import deleteProcess from '../pageobjects/delete.process.page';
import getRandomName from '../helpers/get_random_name';
const config = require('config');
const resourceName = 'air compressor';
const randomName = getRandomName();
const errMsg = 'element was not loaded';


describe('Add Input Resource Test', () => {

 	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it('should add input resource to resource table in bottom panel', () => {

		Process.create(randomName);
		Step.firstStepBox.rightClick();
		Step.addInput.click();
		browser.waitForElement(Resource.resourceTypeSearch, config.app.waitTime,
			`resourceTypeSearch ${errMsg}`);
		browser.waitUntil(() => {
			return Resource.resourceTypeSearch.isEnabled();
		}, config.app.waitTime, `resource search input field ${errMsg}`);
		Resource.addResource(resourceName);
		expect(Resource.inputSecondResource.getText()).to.equal(resourceName.toUpperCase());
		// deleteProcess.delete(randomName);

	});

});