import LoginPage from '../pageobjects/login.page';
import Home from '../pageobjects/home.page';
import ResourceInventory from '../pageobjects/resource.inventory.page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const existingResource = 'SCC-1000';
const errMsg = 'element was not loaded';
let numOfResources;


describe('Search Resource In Resource Inventory Test', () => {

	it('should find the Resource in Resource Inventory', () => {

		LoginPage.login(config.app.admin.username,
			config.app.admin.password);
		browser.waitForElement(Home.openLeftNav,
			config.app.waitTime, `openLeftNav ${errMsg}`);
		Home.openLeftNav.click();
		browser.waitForElement(ResourceInventory.resourceInventoryLibraryLink,
			config.app.waitTime, `Create Resource Link ${errMsg}`);
		ResourceInventory.resourceInventoryLibraryLink.click();
		browser.waitForElement(ResourceInventory.findResource,
			config.app.waitTime, `Find Resource Search Input Field ${errMsg}`);
		ResourceInventory.findResource.setValue(existingResource);
		browser.keys(['Enter']);
		browser.waitForElement(Home.libraryTableTRs,
			config.app.waitTime, `Search Results Table Rows ${errMsg}`);
		browser.waitUntil(() => {
			return browser.selectorExecute('.library-table.table tbody > tr', (tr) => {
				return tr.length == 4;
			});
		}, config.app.waitTime, `4 Resource search result rows ${errMsg}`);
		numOfResources = browser.selectorExecute('.library-table.table tbody > tr', (tr) => {
			return tr.length;
		});
		expect(numOfResources).to.equal(4);
		expect(Home.libraryTable1stTR1stTD.getText()).to.equal('SCC-1000');

	});

});
