import LoginPage from '../pageobjects/login.page';
import experimentOfProcess from '../pageobjects/create.experiment.page';
import fileUpload from '../pageobjects/fileupload.config';
import testProcessAndExperiment from '../pageobjects/testdata.delete';
import Step from '../pageobjects/step.page';
import Run from '../pageobjects/run.page';
import Plate from '../pageobjects/plate.page';
import getRandomName from '../helpers/get_random_name';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const randomName = getRandomName();
const errMsg = 'element was not loaded';
const path = require('path');
const filePath = path.join(__dirname, config.app.plateTest);


describe('Plate Transfer Test', () => {

	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it('should copy over the run data from 1 step over to another', () => {

		experimentOfProcess.createConnectedStepsForPlateTransfer(randomName);
		browser.waitForElement(Run.fileUploadIcon, config.app.waitTime,
			`fileUploadIcon ${errMsg}`);
		fileUpload.configPlateTest(filePath);
		browser.waitForElement(Step.nextStepBox, config.app.waitTime,
			`Next Step Box ${errMsg}`);
		Step.nextStepBox.click();
		browser.waitUntil(() => {
			return browser.selectorExecute('.resource-details-table tr', (row) => {
				return row.length >= 3;
			});
		}, config.app.waitTime, `Run table ${errMsg}`);
		Run.plate.click();
		Plate.transferPlate('QWERT');
		Run.actualRun.click();
		browser.waitForElement(Run.run6thProperty13thCol, config.app.waitTime,
			`6th Run 13th Col Cell ${errMsg}`);
		expect(Run.run1stOutputsUnassignedResource.getValue()).to.equals('QWERT');
		expect(Run.run1stProperty8thCol.getValue()).to.equals('A');
		expect(Run.run1stProperty9thCol.getValue()).to.equals('1');
		expect(Run.run1stProperty11thCol.getValue()).to.equals('QWERT');
		expect(Run.run1stProperty12thCol.getValue()).to.equals('A');
		expect(Run.run1stProperty13thCol.getValue()).to.equals('1');
		expect(Run.run2ndOutputsUnassignedResource.getValue()).to.equals('QWERT');
		expect(Run.run2ndProperty8thCol.getValue()).to.equals('A');
		expect(Run.run2ndProperty9thCol.getValue()).to.equals('2');
		expect(Run.run2ndProperty11thCol.getValue()).to.equals('QWERT');
		expect(Run.run2ndProperty12thCol.getValue()).to.equals('A');
		expect(Run.run2ndProperty13thCol.getValue()).to.equals('2');
		expect(Run.run3rdOutputsUnassignedResource.getValue()).to.equals('QWERT');
		expect(Run.run3rdProperty8thCol.getValue()).to.equals('A');
		expect(Run.run3rdProperty9thCol.getValue()).to.equals('3');
		expect(Run.run3rdProperty11thCol.getValue()).to.equals('QWERT');
		expect(Run.run3rdProperty12thCol.getValue()).to.equals('A');
		expect(Run.run3rdProperty13thCol.getValue()).to.equals('3');
		expect(Run.run4thOutputsUnassignedResource.getValue()).to.equals('QWERT');
		expect(Run.run4thProperty8thCol.getValue()).to.equals('B');
		expect(Run.run4thProperty9thCol.getValue()).to.equals('1');
		expect(Run.run4thProperty11thCol.getValue()).to.equals('QWERT');
		expect(Run.run4thProperty12thCol.getValue()).to.equals('B');
		expect(Run.run4thProperty13thCol.getValue()).to.equals('1');
		expect(Run.run5thOutputsUnassignedResource.getValue()).to.equals('QWERT');
		expect(Run.run5thProperty8thCol.getValue()).to.equals('B');
		expect(Run.run5thProperty9thCol.getValue()).to.equals('2');
		expect(Run.run5thProperty11thCol.getValue()).to.equals('QWERT');
		expect(Run.run5thProperty12thCol.getValue()).to.equals('B');
		expect(Run.run5thProperty13thCol.getValue()).to.equals('2');
		expect(Run.run6thOutputsUnassignedResource.getValue()).to.equals('QWERT');
		expect(Run.run6thProperty8thCol.getValue()).to.equals('B');
		expect(Run.run6thProperty9thCol.getValue()).to.equals('3');
		expect(Run.run6thProperty11thCol.getValue()).to.equals('QWERT');
		expect(Run.run6thProperty12thCol.getValue()).to.equals('B');
		expect(Run.run6thProperty13thCol.getValue()).to.equals('3');
		// testProcessAndExperiment.delete(randomName);

	});

});