import LoginPage from '../pageobjects/login.page';
import getRandomName from '../helpers/get_random_name';
import Process from '../pageobjects/process.page';
import deleteProcess from '../pageobjects/delete.process.page';
import Home from '../pageobjects/home.page';
import waitForElement from '../helpers/wait_for_element';

const config = require('config');
const randomName = getRandomName();
const errMsg = 'element was not loaded';


describe('Create Process', () => {

	it('should create a new process', () => {

		LoginPage.login(config.app.admin.username, config.app.admin.password);
		Process.create(randomName);
		expect(browser.getUrl()).to.contain('process');
		browser.waitForElement(Home.appTitleText, config.app.waitTime,
			`Process Title ${errMsg}`);
		Home.appTitleText.waitForEnabled();
		expect(Home.appTitleText.getText()).to.equal(randomName);
		// deleteProcess.delete(randomName);

	});

});
