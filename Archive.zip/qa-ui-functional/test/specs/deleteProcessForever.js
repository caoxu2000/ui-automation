import LoginPage from '../pageobjects/login.page';
import Home from '../pageobjects/home.page';
import Process from '../pageobjects/process.page';
import getRandomName from '../helpers/get_random_name';
import deleteProcess from '../pageobjects/delete.process.page';

const config = require('config');
const randomName = getRandomName();

describe('Delete process permanently', () => {

	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it('should delete a test process permanently', () => {

		Process.create(randomName);
		browser.switchTab(browser.getTabIds()[0]);
		// deleteProcess.delete(randomName);

	});

});
