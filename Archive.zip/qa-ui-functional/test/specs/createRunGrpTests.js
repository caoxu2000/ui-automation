import LoginPage from '../pageobjects/login.page';
import Experiment from '../pageobjects/experiment.page';
import RunGroup from '../pageobjects/run.group.page';
import getRandomName from '../helpers/get_random_name';
import experimentOfProcess from '../pageobjects/create.experiment.page';
import testProcessAndExperiment from '../pageobjects/testdata.delete';
import ResourceToolbar from '../pageobjects/resource.toolbar.page';
import waitForElement from '../helpers/wait_for_element';

const config = require('config');
const testName = 'Create Run Group Test';
const randomName = getRandomName();
const errMsg = 'element was not loaded';


describe(testName, () => {

	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
		experimentOfProcess.create(randomName);
		browser.waitForElement(ResourceToolbar.createNewRunPlus, config.app.waitTime,
			`createNewRunPlus ${errMsg}`);
		ResourceToolbar.createNewRunPlus.click();
		browser.waitForElement(ResourceToolbar.runCounter, config.app.waitTime,
			`runCounter ${errMsg}`);
		ResourceToolbar.runCounter.setValue('2');
		ResourceToolbar.runPrefixName.setValue(randomName);
		ResourceToolbar.createRunBtn.click();
	});

	it('should create a new run group replacing the default group', () => {

		browser.waitForElement(Experiment.runTableRow(1, 2), config.app.waitTime,
			`1st Run Name Column ${errMsg}`);
		RunGroup.runGroupDropDown.click();
		RunGroup.newRunGroup.click();
		browser.waitForElement(RunGroup.groupName, config.app.waitTime,
			`groupName ${errMsg}`);
		RunGroup.groupName.setValue(randomName);
		RunGroup.confirmBtn.click();
		browser.pause(config.app.downloadWaitTime);
		let actualRunGrpName = RunGroup.runGroupDropDown.getText();
		expect(actualRunGrpName).equals(randomName);
		// testProcessAndExperiment.delete(randomName);

	});

});