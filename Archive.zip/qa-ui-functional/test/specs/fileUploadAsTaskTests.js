import LoginPage from '../pageobjects/login.page';
import Comment from '../pageobjects/comment.page';
import Process from '../pageobjects/process.page';
import deleteProcess from '../pageobjects/delete.process.page';
import Task from '../pageobjects/task.page';
import getRandomName from '../helpers/get_random_name';
import waitForElement from '../helpers/wait_for_element';

const config = require('config');
const path = require('path');
const filePath = path.join(__dirname, config.app.TasksExpected);
const randomName = getRandomName();
const errMsg = 'element was not loaded';


describe('Upload file attachment to a Task Test', () => {

	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it('should upload the file to Task 1', () => {

		Process.create(randomName);
		browser.waitForElement(Comment.addTaskBtn, config.app.waitTime,
			`Add Task Button ${errMsg}`);
		Comment.taskMain.doubleClick();
		browser.waitForElement(Comment.uploadButton, config.app.waitTime,
			`Upload File Icon ${errMsg}`);
		browser.chooseFile('.add-media-files', filePath);
		browser.pause(config.app.waitTime);
		Comment.updateTaskButton.click();
		browser.pause(config.app.waitTime);
		expect(Comment.mediaImage.isExisting()).to.be.true;
		browser.pause(config.app.downloadWaitTime);
		// deleteProcess.delete(randomName);

	});

});