import LoginPage from '../pageobjects/login.page';
import Process from '../pageobjects/process.page';
import deleteProcess from '../pageobjects/delete.process.page';
import getRandomName from '../helpers/get_random_name';
import addNote from '../pageobjects/add.note.page';
import Note from '../pageobjects/comment.page';
import waitForElement from '../helpers/wait_for_element';

const config = require('config');
const expectedNote = getRandomName();
const errMsg = 'element was not loaded';


describe('Delete Design Notes of First Step Test', () => {

	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it('should remove the design notes off of First Step in Process', () => {

		Process.create(expectedNote);
		browser.waitForElement(Note.sideBar, config.app.waitTime,
			`sideBar ${errMsg}`);
		addNote.add(expectedNote);
		browser.waitForElement(Note.deleteComment, config.app.waitTime,
			`delete trash icon ${errMsg}`);
		Note.deleteComment.click();
		browser.pause(config.app.waitTime);
		expect(Note.firstCommentView.isExisting()).to.be.false;
		// deleteProcess.delete(expectedNote);

	});

});