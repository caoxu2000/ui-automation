import LoginPage from '../pageobjects/login.page';
import Experiment from '../pageobjects/experiment.page';
import RunGroup from '../pageobjects/run.group.page';
import waitForElement from '../helpers/wait_for_element';
import experimentOfProcess from '../pageobjects/create.experiment.page';
import testProcessAndExperiment from '../pageobjects/testdata.delete';
import getRandomName from '../helpers/get_random_name';
import getRandomNum from '../helpers/get_random_num';
import Run from '../pageobjects/run.page';
const randomName = getRandomName();
const randomNumber = getRandomNum();
const config = require('config');
const path = require('path');
const filePath = path.join(__dirname, config.app.uploadFile);
const downloadPlan = path.join(__dirname, config.app.downloadPlanned);
const downloadActual = path.join(__dirname, config.app.downloadActual);
const csv = require('csv-parser');
const fs = require('fs-extra');
const headerActual = [
	'process_id',
	'process_name',
	'experiment_id',
	'experiment_label',
	'experiment_name',
	'run_id',
	'run_label',
	'run_num',
	'run_type',
	'run_name',
	'resource_name',
	'resource_rifID',
	'resource_name',
	'resource_rifID',
	'value'
];

const headerPlan = [
	'process_id',
	'process_name',
	'experiment_id',
	'experiment_label',
	'experiment_name',
	'run_id',
	'run_label',
	'run_num',
	'run_type',
	'run_name',
	'value'
];

const expectedPlan = [
	'First Step | run name',
	'automation  1',
	'automation  2',
	'automation  3',
	'automation  4',
	'automation  5',
];

const expectedActual = [
	'First Step | output | water | pH | value',
	randomNumber.toString(),
	randomNumber.toString(),
	randomNumber.toString(),
	randomNumber.toString(),
	randomNumber.toString()
];

let actualPlan = [];
let actualExecute = [];
const errMsg = 'element was not loaded';


describe('Export Planned Multiple Values For Groups Test', () => {

	it('should export to CSV with expected content', () => {

		LoginPage.login(config.app.admin.username, config.app.admin.password);
		experimentOfProcess.createConnectedSteps(randomName);
		Run.createRunsAndFillPHValue('automation ', 5, randomNumber);
		browser.waitForElement(RunGroup.runGroupDropDown, config.app.waitTime,
			`Run Group DropDown ${errMsg}`);
		RunGroup.runGroupDropDown.click();
		browser.waitForElement(RunGroup.actualSingleValued, config.app.waitTime,
			`Export Actual Single Valued Data ${errMsg}`);
		RunGroup.actualSingleValued.click();
		browser.pause(config.app.waitTime);
		RunGroup.confirmBtn.click();
		browser.pause(config.app.downloadWaitTime);
		browser.waitForElement(RunGroup.planMenu, config.app.waitTime,
			`Plan Menu ${errMsg}`);
		RunGroup.planMenu.click();
		browser.waitForElement(RunGroup.createRunPlusBtn, config.app.waitTime,
			`Create Run Plus Icon ${errMsg}`);
		RunGroup.runGroupDropDown.click();
		browser.waitForElement(RunGroup.plannedMultipleValues, config.app.waitTime,
			`Export Planned Multiple Values ${errMsg}`);
		RunGroup.plannedMultipleValues.click();
		browser.pause(config.app.waitTime);
		RunGroup.confirmBtn.click();
		browser.pause(config.app.downloadWaitTime);
		fs.createReadStream(downloadActual)
			.pipe(csv(headerActual))
			.on('data', function(data) {
				actualExecute.push(data.value);
			});
		browser.pause(config.app.downloadWaitTime);
		expect(actualExecute).to.deep.equal(expectedActual);
		fs.removeSync(downloadActual);
		fs.createReadStream(downloadPlan)
			.pipe(csv(headerPlan))
			.on('data', function(data) {
				actualPlan.push(data.run_name);
			});
		browser.pause(config.app.downloadWaitTime);
		expect(actualPlan).to.deep.equal(expectedPlan);
		fs.removeSync(downloadPlan);
		// testProcessAndExperiment.delete(randomName);

	});

});