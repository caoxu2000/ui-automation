import LoginPage from '../pageobjects/login.page';
import Task from '../pageobjects/task.page';
import Comment from '../pageobjects/comment.page';
import waitForElement from '../helpers/wait_for_element';
import Process from '../pageobjects/process.page';
import deleteProcess from '../pageobjects/delete.process.page';
import getRandomName from '../helpers/get_random_name';
const randomName = getRandomName();
const config = require('config');
const errMsg = 'element was not loaded';


describe('Move Task within First Step Test', () => {

	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it('should move 2nd task to the 3rd position within First Step', () => {

		Process.create(randomName);
		browser.waitForElement(Comment.infoTab, config.app.waitTime,
			`Info Tab ${errMsg}`);
		Task.addTask(`2nd Task with dynamic text ${randomName}`);
		Task.addTask('3rd Task with Static Text');
		Task.make2ndTaskLast();
		browser.pause(config.app.waitTime);
		let thirdTaskText = Comment.thirdTaskText.getText();
		let thirdTaskOrderText = Comment.thirdTaskOrder.getText();
		expect(thirdTaskText).to.equal(`2nd Task with dynamic text ${randomName}`);
		expect(thirdTaskOrderText).equals('3.');
		// deleteProcess.delete(randomName);

	});

});