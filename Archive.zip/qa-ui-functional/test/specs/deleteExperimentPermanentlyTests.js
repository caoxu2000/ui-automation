import LoginPage from '../pageobjects/login.page';
import deleteExperiment from '../pageobjects/delete.experiment.page';
import experimentOfProcess from '../pageobjects/create.experiment.page';
import deleteProcess from '../pageobjects/delete.process.page';
import getRandomName from '../helpers/get_random_name';
const config = require('config');
const randomName = getRandomName();
const testsuite = 'Delete Experiment Permanently Test';
const testcase = 'Should purge the Experiment from Trash';


describe(testsuite, () => {

	it(testcase, () => {

		LoginPage.login(config.app.admin.username,
			config.app.admin.password);
		experimentOfProcess.create(randomName);
		deleteExperiment.deleteTestExperiment(randomName);
		expect($(`td*=${randomName}`).isExisting()).to.be.false;
		// deleteProcess.delete(randomName);

	});

});
