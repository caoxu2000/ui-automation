import LoginPage from '../pageobjects/login.page';
import Home from '../pageobjects/home.page';
import Process from '../pageobjects/process.page';
import deleteProcess from '../pageobjects/delete.process.page';
import getRandomName from '../helpers/get_random_name';
import waitForElement from '../helpers/wait_for_element';
import ContextMenu from '../pageobjects/context.menu.page';

const config = require('config');
const randomName = getRandomName();
const errMsg = 'element was not loaded';
const noResults = 'No search results found.';


describe('Add/remove tag of a process test', function() {

	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it('should add the tag only to that the selected process', function() {

		Process.create(randomName);
		browser.waitForElement(Process.logo,
			config.app.waitTime, `Riffyn logo ${errMsg}`);
		Process.logo.click();
		browser.waitForElement($(`td*=${randomName}`), config.app.waitTime,
			`Test Process Row In Library ${errMsg}`);
		$(`td*=${randomName}`).rightClick();
		browser.waitForElement(Process.addTagLinkContextMnu, config.app.waitTime,
			`addTagLinkContextMnu ${errMsg}`);
		Process.addTagLinkContextMnu.click();
		browser.keys(['Clear']);
		browser.waitForElement(Process.tagNameField, config.app.waitTime,
			`tagNameField ${errMsg}`);
		Process.tagNameField.setValue(randomName);
		browser.keys(['Enter']);
		browser.waitForElement(Process.tagUpdateBtn, config.app.waitTime,
			`tagUpdateBtn ${errMsg}`);
		Process.tagUpdateBtn.click();
		browser.waitForElement(Process.tagPill, config.app.waitTime,
			`tag clip on left nav ${errMsg}`);
		expect(Process.tagPill.isExisting()).to.be.true;
		// remove tag added from above
		Process.tagPill.click();
		browser.pause(config.app.waitTime);
		let itemCounter1 = browser.selectorExecute('.library-table-row', (item) => {
			return item.length;
		});
		expect(itemCounter1).to.equal(1);
		browser.waitForElement($(`td*=${randomName}`), config.app.waitTime,
			`Test Process Row In Library ${errMsg}`);
		$(`td*=${randomName}`).rightClick();
		browser.waitForElement(Process.addTagLinkContextMnu, config.app.waitTime,
			`addTagLinkContextMnu ${errMsg}`);
		Process.addTagLinkContextMnu.click();
		browser.pause(config.app.waitTime);
		Process.removeTag.click();
		browser.waitForElement(Process.tagUpdateBtn, config.app.waitTime,
			`tagUpdateBtn ${errMsg}`);
		Process.tagUpdateBtn.click();
		browser.pause(config.app.waitTime);
		expect(Process.tagPill.isExisting()).to.be.false;
		let itemCounter2 = browser.selectorExecute('.library-table-empty-row', (item) => {
			return item.length;
		});
		expect(itemCounter2).to.equal(1);
		expect(Home.libraryEmptyRow.getText()).to.equals(noResults);
		// deleteProcess.delete(randomName);
		
	});

});
