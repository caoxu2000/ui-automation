import LoginPage from '../pageobjects/login.page';
import experimentOfProcess from '../pageobjects/create.experiment.page';
import testProcessAndExperiment from '../pageobjects/testdata.delete';
import fileUpload from '../pageobjects/fileupload.config';
import dbUpload from '../pageobjects/dbupload.config';
import getRandomName from '../helpers/get_random_name';
import Run from '../pageobjects/run.page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const randomName = getRandomName();
const path = require('path');
const filePath = path.join(__dirname, config.app.uploadFile);
const errMsg = 'element was not loaded';
const tc = 'should filter data value according to the selection from dropdown list';


describe('Data Display Filter Test', () => {

	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it(tc, () => {

		experimentOfProcess.createConnectedSteps(randomName);
		browser.waitForElement(Run.fileUploadIcon, config.app.waitTime,
			`fileUploadIcon ${errMsg}`);
		fileUpload.config(filePath, 'output');
		dbUpload.requireFromDB();
		browser.waitForElement(dbUpload.addQuery, config.app.waitTime,
			`Add Query Plus ${errMsg}`);
		dbUpload.addQuery.click();
		dbUpload.clickDBUpload(`test ${randomName}`, 'compression_data', 'run');
		dbUpload.executeQuery();
		dbUpload.config('runOption', 'topMaxFNewtons');
		Run.showDataDropdown.click();
		Run.dbOption.click();
		browser.pause(config.app.waitTime);
		expect(Run.run1stProperty8thCol.getValue()).to.equal('');
		expect(Run.run9thProperty8thCol.getValue()).to.equal('10.65');
		Run.showDataDropdown.click();
		Run.fileOption.click();
		browser.pause(config.app.waitTime);
		expect(Run.run1stProperty8thCol.getValue()).to.equal('6.96');
		expect(Run.run9thProperty8thCol.getValue()).to.equal('');
		// testProcessAndExperiment.delete(randomName);

	});

});