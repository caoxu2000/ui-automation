import LoginPage from '../pageobjects/login.page';
import experimentOfProcess from '../pageobjects/create.experiment.page';
import testProcessAndExperiment from '../pageobjects/testdata.delete';
import Property from '../pageobjects/property.page';
import fileUpload from '../pageobjects/fileupload.config';
import getRandomName from '../helpers/get_random_name';
import Run from '../pageobjects/run.page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const randomName = getRandomName();
const path = require('path');
const filePath1 = path.join(__dirname, config.app.uploadFile);
const filePath2 = path.join(__dirname, config.app.anotherUploadFile);
const testName = `should upload different run data files with 
	only config difference being the first one with 'Create as 
	many runs as rows of file data', the second one with 'Use
	existing runs on current step`;
const errMsg = 'element was not loaded';


describe('Add To Existing Runs With Multiple Values Test', () => {

	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it(testName, () => {

		experimentOfProcess.createConnectedSteps(randomName);
		browser.waitForElement(Run.fileUploadIcon, config.app.waitTime,
			`fileUploadIcon ${errMsg}`);
		fileUpload.config(filePath1, 'output');
		fileUpload.overwriteExistingRuns(filePath2);
		Run.multiValueCell.click();
		browser.pause(config.app.waitTime);
		let firstPH = Run.firstMultiValuePH.getText();
		let secondPH = Run.secondMultiValuePH.getText();
		expect([firstPH, secondPH]).to.deep.equal(['6.96', '7.48']);

	});

});