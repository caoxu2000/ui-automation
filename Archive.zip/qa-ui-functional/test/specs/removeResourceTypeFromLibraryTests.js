import LoginPage from '../pageobjects/login.page';
import getRandomName from '../helpers/get_random_name';
import Home from '../pageobjects/home.page';
import ResourceType from '../pageobjects/resourcetype.page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const randomName = getRandomName();
const errMsg = 'element was not loaded';
const testProperty = 'pH';
const testComponent = 'WATER';
const testCaseLabel = 'should remove the resource type in ' + 
	'riffyn.test.2\'s Resource Type library';


describe('Remove a Resource Type From My Library Test', () => {

	it(testCaseLabel, () => {

		LoginPage.login(config.app.admin.username, config.app.admin.password);
		ResourceType.create(randomName, testProperty, testComponent);
		Home.searchInputField.setValue(randomName);
		browser.keys(['Enter']);
		browser.pause(config.app.waitTime);
		browser.waitForElement($(`td*=${randomName}`),
			config.app.waitTime, `resource type row ${randomName} ${errMsg}`);
		$(`td*=${randomName}`).rightClick();
		browser.waitForElement(Home.share,
			config.app.waitTime, `Share Context Menu ${errMsg}`);
		Home.share.click();
		browser.waitForElement(Home.inactiveTab,
			config.app.waitTime, `Collaborator Tab which is inactive ${errMsg}`);
		Home.inactiveTab.click();
		Home.removeCollaborator();
		Home.inactiveTab.click();
		browser.waitForElement(Home.searchUserBox,
			config.app.waitTime, `Search User Box ${errMsg}`);
		Home.searchUserBox.setValue('riffyn.test.2');
		browser.waitForElement(Home.selectFirstUser,
			config.app.waitTime, `First User In Search Results ${errMsg}`);
		Home.selectFirstUser.click();
		browser.waitForElement(Home.userRoleDropDown,
			config.app.waitTime, `User Role DropDown ${errMsg}`);
		Home.userRoleDropDown.selectByValue('viewer');
		browser.waitForElement(Home.shareBtn,
			config.app.waitTime, `Share Button ${errMsg}`);
		Home.shareBtn.click();
		browser.pause(config.app.waitTime);
		Home.confirm.click();
		browser.pause(config.app.waitTime);

		LoginPage.logout();
		LoginPage.login(config.app.test2.username,
			config.app.test2.password);
		browser.waitForElement(Home.openLeftNav,
			config.app.waitTime, `Open in LeftNav ${errMsg}`);
		Home.openLeftNav.click();
		browser.waitForElement(ResourceType.resourceTypeLink,
			config.app.waitTime, `Resource Type Menu ${errMsg}`);
		ResourceType.resourceTypeLink.click();
		browser.waitForElement(Home.searchInputField,
			config.app.waitTime, `Search Input in Resource Type Library ${errMsg}`);
		Home.searchInputField.setValue(randomName);
		browser.keys(['Enter']);
		browser.pause(config.app.waitTime);
		$(`td*=${randomName}`).rightClick();
		browser.waitForElement(Home.removeFromMyLibrary,
			config.app.waitTime, `Remove From My Library Menu ${errMsg}`);
		Home.removeFromMyLibrary.click();
		browser.waitForElement(Home.confirm,
			config.app.waitTime, `Remove Resource Type Confirm Button ${errMsg}`);
		Home.confirm.click();
		browser.pause(config.app.waitTime);
    expect($(`td*=${randomName}`).isExisting()).to.be.false;
    expect(Home.noSearchResults.isExisting()).to.be.true;
    expect(Home.noSearchResults.getText()).to.equal('No search results found.');

	});

});
