import LoginPage from '../pageobjects/login.page';
import Process from '../pageobjects/process.page';
import deleteProcess from '../pageobjects/delete.process.page';
import crudComponent from '../pageobjects/crud.component.resource';
import Step from '../pageobjects/step.page';
import Resource from '../pageobjects/resource.page';
import waitForElement from '../helpers/wait_for_element';
import getRandomName from '../helpers/get_random_name';
const config = require('config');
const componentName = 'abequose';
const testProcessName = getRandomName();
const errMsg = 'element was not loaded';


describe('Change Name of a Component to Resource Test', () => {

 	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it('should change the name of the component to a new name', () => {

		Process.create(testProcessName);
		browser.waitForElement(Step.outputResourceToolbar, config.app.waitTime, 
			`Output Resource Toolbar ${errMsg}`);
		crudComponent.add(componentName);
		crudComponent.propagate();
		expect(Resource.outputComponent.getText()).to.equal(componentName.toUpperCase());
		// deleteProcess.delete(testProcessName);

	});

});