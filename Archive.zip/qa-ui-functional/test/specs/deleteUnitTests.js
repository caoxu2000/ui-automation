import LoginPage from '../pageobjects/login.page';
import getRandomName from '../helpers/get_random_name';
import Home from '../pageobjects/home.page';
import Unit from '../pageobjects/unit.page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const errMsg = 'element was not loaded';
const name = getRandomName();


describe('Delete Unit Test', () => {

	it('should remove the unit from Unit Library', () => {

		LoginPage.login(config.app.admin.username, config.app.admin.password);
		Unit.create(name);
		Home.searchInputField.setValue(name);
		browser.keys(['Enter']);
		browser.pause(config.app.waitTime);
		browser.waitForElement($(`td*=${name}`),
			config.app.waitTime, `Newly Created Unit Row ${errMsg}`);
		$(`td*=${name}`).rightClick();
		browser.waitForElement(Home.delete,
			config.app.waitTime, `Delete in Context menu ${errMsg}`);
    Home.delete.click();
    browser.waitForElement(Home.confirm,
			config.app.waitTime, `Delete button in popup ${errMsg}`);
		Home.confirm.click();
		browser.pause(config.app.waitTime);
    expect($(`td*=${name}`).isExisting()).to.be.false;
    expect(Home.noSearchResults.isExisting()).to.be.true;
    expect(Home.noSearchResults.getText()).to.equal('No search results found.');

	});

});
