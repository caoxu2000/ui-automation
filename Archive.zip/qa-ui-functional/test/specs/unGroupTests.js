import LoginPage from '../pageobjects/login.page';
import Step from '../pageobjects/step.page';
import Resource from '../pageobjects/resource.page';
import waitForElement from '../helpers/wait_for_element';
import Process from '../pageobjects/process.page';
import getRandomName from '../helpers/get_random_name';
const config = require('config');
const randomName = getRandomName();
const label = 'First step ofNew Base Step';
const errMsg = 'element was not loaded';


describe('Enclose a Step in a New Group Test', () => {

 	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it('should include a step into a new Group in a New Sub Process', () => {

		Process.create(randomName);
		Step.addNewStep();
		Step.newBaseStep.rightClick();
		Step.encloseInNewGroup.click();
		browser.waitForElement(Step.groupIcon, config.app.waitTime,
			`Group Folder Icon ${errMsg}`);
		Step.newBaseStep.rightClick();
		Step.unGroupSteps.click();
		browser.pause(config.app.waitTime);
		expect(Step.groupIcon.isExisting()).to.be.false;
		expect(Step.unGroupNewBaseStepLabel.getText()).to.equals(label);

	});

});