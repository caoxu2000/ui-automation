import LoginPage from '../pageobjects/login.page';
import Home from '../pageobjects/home.page';
import getRandomName from '../helpers/get_random_name';
import waitForElement from '../helpers/wait_for_element';
import Team from '../pageobjects/team.page';
const config = require('config');
const team1 = 'Team ' + getRandomName();
const test2 = 'riffyn.test.2';
const errMsg = 'element was not loaded';
const testCase = 'should create a team and add creator' + 
	' and a member to the team member list';


describe('Create Team Test', () => {

	it(testCase, () => {

		LoginPage.login(config.app.admin.username,
			config.app.admin.password);
		browser.url('library/teams');
		browser.waitForElement(Team.createTeamPlus, config.app.longerWait,
			`Create Team Plus ${errMsg}`);
		Team.create(team1, test2);
		browser.waitForElement(Home.searchInputField, config.app.waitTime,
			`Search box ${errMsg}`);
		Home.searchInputField.setValue(team1);
		browser.keys(['Enter']);
		browser.waitForElement($(`td*=${team1}`), config.app.waitTime,
			`Newly Created Team ${errMsg}`);
		$(`td*=${team1}`).doubleClick();
		browser.pause(config.app.waitTime);
		browser.waitForElement(Team.teamCreator, config.app.waitTime,
			`Creator's username  ${errMsg}`);
		expect(Team.teamCreator.getText()).to.equal(config.app.admin.username);
		expect(Team.firstTeamMemberName.getText()).to.equal(test2);

	});

});
