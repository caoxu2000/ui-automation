import LoginPage from '../pageobjects/login.page';
import Home from '../pageobjects/home.page';
import ResourceType from '../pageobjects/resourcetype.page';
import getRandomName from '../helpers/get_random_name';
const config = require('config');
const allEntry = '';
const createdByMeEntry = getRandomName(), sharedWithRiffynEntry = createdByMeEntry;
const sharedWithMeEntry = '';
const publicEntry = 'data';
const testProperty = 'pH';
const testComponent = 'WATER';
const testCase = 'should display resource type according ' + 
								 'to their respective left panel filters';


describe('View Filter In Resource Type Library Test', () => {

	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it(testCase, () => {

		ResourceType.create(createdByMeEntry, testProperty, testComponent);
		browser.pause(config.app.waitTime);
		// Home.searchAndAssert(allEntry);
		Home.createdByMe.click();
		Home.searchAndAssert(createdByMeEntry);
		// Home.sharedWithMe.click();
		// Home.searchAndAssert(sharedWithMeEntry);
		Home.sharedWithRiffyn.click();
		Home.searchAndAssert(sharedWithRiffynEntry);
		browser.pause(config.app.waitTime);
		Home.public.click();
		Home.searchAndAssert(publicEntry);

	});

})