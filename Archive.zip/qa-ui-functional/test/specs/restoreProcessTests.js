import LoginPage from '../pageobjects/login.page';
import Home from '../pageobjects/home.page';
import Process from '../pageobjects/process.page';
import deleteProcess from '../pageobjects/delete.process.page';
import getRandomName from '../helpers/get_random_name';
import waitForElement from '../helpers/wait_for_element';

const config = require('config');
const randomName = `Move to Trash then Restore Test ${getRandomName()}`;
const errMsg = 'element was not loaded';


describe('Move to Trash then Restore Process tests', () => {

	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
		Process.create(randomName);
		browser.switchTab(browser.getTabIds()[0]);
	});

	it('should Move to Trash then restore', () => {

		browser.pause(config.app.waitTime);
		$(`td*=${randomName}`).rightClick();
		browser.waitForElement(Process.moveToTrash, config.app.waitTime,
			`MoveToTrash Menu ${errMsg}`);
		Process.moveToTrash.click();
		browser.pause(config.app.waitTime);
		Process.purgeButton.click();
		browser.pause(config.app.waitTime);
		let isProcessRemoved = $(`td*=${randomName}`).isExisting();
		expect(isProcessRemoved).to.be.false;

		browser.waitForElement(Process.trashProcess, config.app.waitTime,
			`Trash Link in Left Nav ${errMsg}`);
		Process.trashProcess.click();
		browser.pause(config.app.waitTime);
		$(`td*=${randomName}`).rightClick();
		browser.waitForElement(Process.restore, config.app.waitTime,
			`Restore menu ${errMsg}`);
		Process.restore.click();
		browser.pause(config.app.waitTime);
		Process.purgeButton.click();
		browser.waitForElement(Process.allProcess, config.app.waitTime,
			`All Link in Left Nav ${errMsg}`);
		Process.allProcess.click();
		browser.pause(config.app.waitTime);
		let isProcessRestored = $(`td*=${randomName}`).isExisting();
		expect(isProcessRestored).to.be.true;
		// deleteProcess.delete(randomName);

	});

});
