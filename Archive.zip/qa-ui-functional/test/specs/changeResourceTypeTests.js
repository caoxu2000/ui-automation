import LoginPage from '../pageobjects/login.page';
import Resource from '../pageobjects/resource.page';
import Process from '../pageobjects/process.page';
import deleteProcess from '../pageobjects/delete.process.page';
import getRandomName from '../helpers/get_random_name';
const config = require('config');
const resourceName = 'zebularine';
const randomName = getRandomName();


describe('Change Input Resource Type Test', () => {

 	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it('should update input resource type in the bottom panel', () => {

		Process.create(randomName);
		Resource.changeInputUnassignedResourceType(resourceName);
		expect(Resource.inputFirstResource.getText()).to.equal(resourceName.toUpperCase());
		// deleteProcess.delete(randomName);

	});

});