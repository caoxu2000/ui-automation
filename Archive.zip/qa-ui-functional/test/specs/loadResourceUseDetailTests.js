import LoginPage from '../pageobjects/login.page';
import Home from '../pageobjects/home.page';
import ResourceInventory from '../pageobjects/resource.inventory.page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const existingResource = 'IR-8aqH73qv2XMaEmrad';
const errMsg = 'element was not loaded';
const rowsSelector = '.resource-details-section ' +
	'tr.table-fixed-row:not(.born-on-row)';
const expectedText1 = 'Components and PropertiesExp 12017-12-18Step 1R497';
const expectedText2 = 'Components and PropertiesExp 12017-12-18Step 2R497';
let numOfUsage;


describe('Load Resource Use Detail Test', () => {

	it('should show use detail of the resource', () => {

		LoginPage.login(config.app.admin.username,
			config.app.admin.password);
		browser.waitForElement(Home.openLeftNav,
			config.app.waitTime, `openLeftNav ${errMsg}`);
		Home.openLeftNav.click();
		browser.waitForElement(ResourceInventory.resourceInventoryLibraryLink,
			config.app.waitTime, `Create Resource Link ${errMsg}`);
		ResourceInventory.resourceInventoryLibraryLink.click();
		browser.waitForElement(ResourceInventory.findResource,
			config.app.waitTime, `Find Resource Search Input Field ${errMsg}`);
		ResourceInventory.findResource.setValue(existingResource);
		browser.keys(['Enter']);
		browser.pause(config.app.waitTime);
		browser.waitForElement($(`td*=IR-8aqH73qv2XMaEmrad`),
			config.app.waitTime, `resource IR-8aqH73qv2XMaEmrad ${errMsg}`);
		$(`td*=IR-8aqH73qv2XMaEmrad`).doubleClick();
		browser.waitForElement(ResourceInventory.loadResourceUseDetailButton,
			config.app.waitTime, `Load Resource Use Detail Button ${errMsg}`);
		ResourceInventory.loadResourceUseDetailButton.click();
		browser.pause(config.app.waitTime);
		numOfUsage = browser.selectorExecute(rowsSelector, (tr) => {
			return tr.length;
		});
		expect(numOfUsage).to.equal(2);
		let firstUsageText = '';
		for (let i = 0; i < ResourceInventory.resourceUseDetail2ndTRAllTDs.length; i++) {
			firstUsageText += ResourceInventory.resourceUseDetail2ndTRAllTDs[i].getText();
		}
		expect(firstUsageText)
			.to.equal(expectedText1);

	});

});
