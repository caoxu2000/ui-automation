import LoginPage from '../pageobjects/login.page';
import crudComponent from '../pageobjects/crud.component.resource';
import Step from '../pageobjects/step.page';
import Resource from '../pageobjects/resource.page';
import waitForElement from '../helpers/wait_for_element';
import Process from '../pageobjects/process.page';
import deleteProcess from '../pageobjects/delete.process.page';
import getRandomName from '../helpers/get_random_name';
const config = require('config');
const componentName1 = 'Japonine';
const componentName2 = 'Zerbaxa';
const testProcessName = getRandomName();
const errMsg = 'element was not loaded';


describe('Change Component Test', () => {

 	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it('should change component from Japonine to Zerbaxa', () => {

		Process.create(testProcessName);
		browser.waitForElement(Step.outputResourceToolbar, config.app.waitTime,
			`outputResourceToolbar ${errMsg}`);
		crudComponent.add(componentName1);
		crudComponent.change(componentName2);
		expect(Resource.componentName.getText()).to.equal(componentName2.toUpperCase());
		// deleteProcess.delete(testProcessName);

	});

});