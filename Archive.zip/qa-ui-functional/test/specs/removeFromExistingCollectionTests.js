import LoginPage from '../pageobjects/login.page';
import Run from '../pageobjects/run.page';
import experimentOfProcess from '../pageobjects/create.experiment.page';
import testProcessAndExperiment from '../pageobjects/testdata.delete';
import fileUpload from '../pageobjects/fileupload.config';
import getRandomName from '../helpers/get_random_name';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const path = require('path');
const filePath = path.join(__dirname, config.app.uploadFile);
const randomName = getRandomName();
const testSuiteName = 'should remove the config from existing collection';
const expectedNoConfigText = 'No configurations in this collection';
const errMsg = 'element was not loaded';


describe('Remove from Existing Collection', () => {

	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it(testSuiteName, () => {

		experimentOfProcess.createConnectedSteps(randomName);
		browser.waitForElement(Run.fileUploadIcon, config.app.downloadWaitTime, 
			`fileUploadIcon ${errMsg}`);
		fileUpload.config(filePath, 'output');
		fileUpload.addToNewCollection(randomName, filePath);
		fileUpload.applyNewCollection();
		fileUpload.removeConfigFromCollection(filePath);
		fileUpload.collectionExpand.click();
		browser.pause(config.app.waitTime);
		let noConfigText = fileUpload.noConfigText.getText();
		expect(noConfigText).to.equal(expectedNoConfigText);

	});

});