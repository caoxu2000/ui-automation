import LoginPage from '../pageobjects/login.page';
import Process from '../pageobjects/process.page';
import Comment from '../pageobjects/comment.page';
import Run from '../pageobjects/run.page';
import Experiment from '../pageobjects/experiment.page';
import Note from '../pageobjects/comment.page';
import getRandomName from '../helpers/get_random_name';
import waitForElement from '../helpers/wait_for_element';

const config = require('config');
const path = require('path');
const filePath1 = path.join(__dirname, config.app.TasksExpected);
const filePath2 = path.join(__dirname, config.app.DesignNotesExpected);
const filePath3 = path.join(__dirname, config.app.ObservationsExpected);
const randomName = getRandomName();
const errMsg = 'element was not loaded';
const procedureFileName = config.app.TasksUploadFileName;
const designNotesFileName = config.app.DesignNotesUploadFileName;
const observationsFileName = config.app.ObservationsUploadFileName;


describe('File Attachment in Attachment menu Bottom Panel Test', () => {

	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it('should show up under 3 tabs under Attachment menu', () => {

		// Attach file to Design Notes tab in sidebar in Design Mode
		Process.create(randomName);
		browser.switchTab(browser.getTabIds()[1]);
		browser.waitForElement(Note.designNotesTab, config.app.waitTime,
			`Design Notes Tab ${errMsg}`);
		Note.designNotesTab.click();
		browser.waitForElement(Note.uploadClip, config.app.waitTime,
			`Upload File Clip Icon ${errMsg}`);
		Note.uploadClip.click();
		browser.pause(config.app.waitTime);
		browser.chooseFile('.add-media-files', filePath2);
		browser.pause(config.app.dbConfigLoadTime);
		Note.saveComment.click();
		browser.pause(config.app.waitTime);
		
		Experiment.create(randomName);
		browser.switchTab(browser.getTabIds()[2]);
		browser.pause(config.app.waitTime);

		// Attach file to Procedure/Task section in sidebar in Measure Mode
		browser.waitForElement(Comment.addTaskBtn, config.app.waitTime,
			`Add Task Button ${errMsg}`);
		Comment.taskMain.doubleClick();
		browser.waitForElement(Comment.uploadButton, config.app.waitTime,
			`Upload File Icon ${errMsg}`);
		browser.chooseFile('.add-media-files', filePath1);
		browser.pause(config.app.dbConfigLoadTime);
		Comment.updateTaskButton.click();
		browser.pause(config.app.waitTime);

		// Attach file to Observations tab in sidebar in Measure Mode
		browser.waitForElement(Comment.observationsTab, config.app.waitTime,
			`Observations Tab ${errMsg}`);
		Comment.observationsTab.click();
		browser.waitForElement(Comment.uploadClip, config.app.waitTime,
			`Upload File Clipper Icon ${errMsg}`);
		Comment.uploadClip.click();
		browser.pause(config.app.waitTime);
		browser.chooseFile('.add-media-files', filePath3);
		browser.pause(config.app.dbConfigLoadTime);
		Comment.saveComment.click();
		browser.pause(config.app.waitTime); 

		Run.attachments.click();
		browser.pause(config.app.waitTime);
		expect(Run.attachmentFileName.getText()).to.equal(procedureFileName);
		Run.designNotesTab.click();
		browser.pause(config.app.waitTime);
		expect(Run.attachmentFileName.getText()).to.equal(designNotesFileName);
		Run.observationsTab.click();
		browser.pause(config.app.waitTime);
		expect(Run.attachmentFileName.getText()).to.equal(observationsFileName);

	});

});