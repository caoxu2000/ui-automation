import LoginPage from '../pageobjects/login.page';
import Run from '../pageobjects/run.page';
import createRun from '../pageobjects/create.run.page';
import experimentOfProcess from '../pageobjects/create.experiment.page';
import ResourceToolbar from '../pageobjects/resource.toolbar.page';
import getRandomName from '../helpers/get_random_name';
import getRandomNum from '../helpers/get_random_num';
import waitForElement from '../helpers/wait_for_element';

const config = require('config');
const testName = 'Fill down a run test';
const randomName = getRandomName();
const randomNumber = getRandomNum();
const errMsg = 'element was not loaded';


describe(testName, () => {

	it('should copy value of the property to runs down below', () => {

		LoginPage.login(config.app.admin.username, config.app.admin.password);
		experimentOfProcess.createConnectedSteps(randomName);
		Run.createRunsAndFillPHValue('automation ', 5, randomNumber);
		expect(Run.run2ndProperty8thCol.getValue()).to.equal(randomNumber.toString());

	});
});
