import LoginPage from '../pageobjects/login.page';
import Comment from '../pageobjects/comment.page';
import Run from '../pageobjects/run.page';
import experimentOfProcess from '../pageobjects/create.experiment.page';
import testProcessAndExperiment from '../pageobjects/testdata.delete';
import getRandomName from '../helpers/get_random_name';
import addComment from '../pageobjects/add.comment.page';
import waitForElement from '../helpers/wait_for_element';

const config = require('config');
const expectedComment = getRandomName();
const errMsg = 'element was not loaded';


describe('Edit Existing Experiment Observation Comment Test', () => {

	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
		experimentOfProcess.create(expectedComment);
	});

	it('should update the comment with the new content', () => {

		browser.waitForElement(Run.runTypeDropDown, config.app.waitTime,
			`Run Type DropDown ${errMsg}`);
		Comment.observationsTab.click();
		browser.pause(config.app.waitTime);
		addComment.add(expectedComment);
		browser.waitForElement(Comment.editComment, config.app.waitTime,
			`Edit Comment Icon ${errMsg}`);
		Comment.editComment.click();
		browser.waitForElement(Comment.editCommentArea, config.app.waitTime,
			`Edit Comment Input Area ${errMsg}`);
		Comment.editCommentArea.setValue(expectedComment);
		browser.pause(config.app.waitTime);
		Comment.updateComment.click();
		browser.pause(config.app.waitTime);
		let actualComment = Comment.firstCommentView.getText();
		expect(actualComment).equals(expectedComment);
		// testProcessAndExperiment.delete(expectedComment);

	});

});