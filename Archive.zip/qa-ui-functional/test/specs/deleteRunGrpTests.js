import LoginPage from '../pageobjects/login.page';
import Home from '../pageobjects/home.page';
import Experiment from '../pageobjects/experiment.page';
import RunGroup from '../pageobjects/run.group.page';
import getRandomName from '../helpers/get_random_name';
import experimentOfProcess from '../pageobjects/create.experiment.page';
import testProcessAndExperiment from '../pageobjects/testdata.delete';
import ResourceToolbar from '../pageobjects/resource.toolbar.page';
import waitForElement from '../helpers/wait_for_element';

const config = require('config');
const testName = 'Delete Run Group Test';
const randomName = getRandomName();
const errMsg = 'element was not loaded';


describe(testName, () => {

	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
		experimentOfProcess.create(randomName);
		ResourceToolbar.createNewRunPlus.waitForExist();
		ResourceToolbar.createNewRunPlus.click();
		browser.waitForElement(ResourceToolbar.runCounter, config.app.waitTime,
			`runCounter ${errMsg}`);
		ResourceToolbar.runCounter.setValue('2');
		ResourceToolbar.runPrefixName.setValue(randomName);
		ResourceToolbar.createRunBtn.click();
	});

	it('should delete the new group that was created and back to default group', () => {

		browser.waitForElement(Experiment.runTableRow(1, 2), config.app.waitTime,
			`Run Name Column ${errMsg}`);
		RunGroup.runGroupDropDown.click();
		RunGroup.newRunGroup.click();
		browser.waitForElement(RunGroup.groupName, config.app.waitTime,
			`Group Name Input Field ${errMsg}`);
		RunGroup.groupName.setValue(randomName);
		RunGroup.confirmBtn.click();
		browser.pause(config.app.waitTime);
		RunGroup.newRunGroupDropDown.click();
		browser.waitForElement(RunGroup.deleteCurrentCollection, config.app.waitTime,
			`delete Current Collection Menu ${errMsg}`);
		RunGroup.deleteCurrentCollection.click();
		browser.waitForElement(RunGroup.confirmBtn, config.app.waitTime,
			`confirm Button ${errMsg}`);
		RunGroup.confirmBtn.click();
		browser.pause(config.app.waitTime);
		let isBackToDefault = RunGroup.runGroupDropDown.getText().includes('default');
		expect(isBackToDefault).to.be.true;

	});

});