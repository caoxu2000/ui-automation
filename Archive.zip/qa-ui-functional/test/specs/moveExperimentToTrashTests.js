import LoginPage from '../pageobjects/login.page';
import Experiment from '../pageobjects/experiment.page';
import getRandomName from '../helpers/get_random_name';
import experimentOfProcess from '../pageobjects/create.experiment.page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const randomName = getRandomName();
const testsuite = 'Move Experiment to trash Test';
const testcase = 'Should move experiment to trash';
const expectedDeletionMsg = 'Items in the trash will be permanently ' + 
	'deleted after 7 days.';
const errMsg = 'element was not loaded';


describe(testsuite, () => {

	it(testcase, () => {

		LoginPage.login(config.app.admin.username, config.app.admin.password);
		experimentOfProcess.create(randomName);
		Experiment.measureTopNav.click();
		browser.waitForElement(Experiment.moveToTrash,
			config.app.waitTime, `MoveToTrash Menu ${errMsg}`);
		Experiment.moveToTrash.click();
		browser.waitForElement(Experiment.confirmDeleteMsg,
			config.app.waitTime, `Confirm Delete Message ${errMsg}`);
		let actualDeletionMsg = Experiment.confirmDeleteMsg.getText();
		expect(actualDeletionMsg).equals(expectedDeletionMsg);
		browser.pause(config.app.waitTime);
		Experiment.confirmDeletion.click();
		browser.pause(config.app.waitTime);
		browser.url('library/experiments');
		browser.waitForExist('.layer.spinner-overlay',
			config.app.waitTime, true);
		browser.waitForElement(Experiment.trashLeftNav,
			config.app.waitTime, `Trash Menu In LeftNav ${errMsg}`);
		Experiment.trashLeftNav.click();
		browser.waitForElement($(`td*=${randomName}`),
			config.app.waitTime, `Experiment Entry in Trash ${errMsg}`);
		let isExperimentInTrash = $(`td*=${randomName}`).isExisting();
		expect(isExperimentInTrash).to.be.true;

	});

});
