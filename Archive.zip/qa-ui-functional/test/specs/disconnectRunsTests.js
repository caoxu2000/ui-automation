import LoginPage from '../pageobjects/login.page';
import getRandomName from '../helpers/get_random_name';
import Run from '../pageobjects/run.page';
import Step from '../pageobjects/step.page';
import CreateRun from '../pageobjects/create.run.page';
import experimentOfProcess from '../pageobjects/create.experiment.page';
import waitForElement from '../helpers/wait_for_element';
import testProcessAndExperiment from '../pageobjects/testdata.delete';
const config = require('config');
const randomName = getRandomName();
const errMsg = 'element was not loaded';


describe('Disconnect connected Runs between connected Steps Test', () => {

	before(() => {

		LoginPage.login(config.app.admin.username, config.app.admin.password);

	});

	it('should disconnect runs between steps', () => {

		experimentOfProcess.createConnectedSteps(randomName);
		browser.waitForElement(Run.createNewRunInput,
			config.app.waitTime, `create Run Input Field ${errMsg}`);
		CreateRun.create1RunAtATime(randomName);
		Step.nextStepBox.click();
		CreateRun.create1RunAtATime(randomName);
		browser.pause(config.app.waitTime);
		Run.anchorOfFirstStep.click();
		browser.waitForElement(Run.firstStepFirstRunLabel,
			config.app.waitTime, `firstStepFirstRunLabel ${errMsg}`);
		Run.firstStepFirstRunLabel.click();
		browser.waitForElement(Run.nextStepFirstRunLabel,
			config.app.waitTime, `nextStepFirstRunLabel ${errMsg}`);
		Run.nextStepFirstRunLabel.click();
		browser.waitForElement(Run.connectionActionBtn,
			config.app.waitTime, `The GO button to connect runs ${errMsg}`);
		Run.connectionActionBtn.click();
		browser.waitForVisible('.busy-cover',
			config.app.waitTime, true);
		browser.waitForElement(Run.firstStepFirstRunLabel,
			config.app.waitTime, `firstStepFirstRunLabel ${errMsg}`);
		Run.firstStepFirstRunLabel.click();
		browser.waitForElement(Run.nextStepFirstRunLabel,
			config.app.waitTime, `nextStepFirstRunLabel ${errMsg}`);
		Run.nextStepFirstRunLabel.click();
		browser.waitForElement(Run.disconnectRuns,
			config.app.waitTime, `Disconnect Run Button ${errMsg}`);
		Run.disconnectRuns.click();
		browser.pause(config.app.waitTime);
		browser.waitForElement(Run.confirmation,
			config.app.waitTime, `Confirmation Button ${errMsg}`);
		Run.confirmation.click();
		browser.waitForVisible('.modal-overlay',
			config.app.waitTime, true);
		browser.waitForVisible('.busy-cover',
			config.app.waitTime, true);
		browser.waitForElement(Run.firstStepFirstRunLabel,
			config.app.waitTime, `firstStepFirstRunLabel ${errMsg}`);
		Run.firstStepFirstRunLabel.click();
		browser.waitForElement(Run.nextStepFirstRunLabel,
			config.app.waitTime, `nextStepFirstRunLabel ${errMsg}`);
		Run.nextStepFirstRunLabel.click();
		browser.pause(config.app.waitTime);
		let bg_color = Run.firstRunRows.getCssProperty('background-color');
		// rgba(255,247,225,1) is blue green color means runs are disconnected
		expect(bg_color.value).equals('rgba(236,248,246,0.5)');
		// testProcessAndExperiment.delete(randomName);

	});

});