import LoginPage from '../pageobjects/login.page';
import Home from '../pageobjects/home.page';
import Process from '../pageobjects/process.page';
import Experiment from '../pageobjects/experiment.page';
import getRandomName from '../helpers/get_random_name';
import waitForElement from '../helpers/wait_for_element';
import MainMenu from '../pageobjects/main.menu.page';
import Team from '../pageobjects/team.page';
import Role from '../pageobjects/role.page';
const config = require('config');
const processName = getRandomName();
const experimentName = getRandomName();
const team1 = 'Team1 ' + getRandomName();
const team2 = 'Team2 ' + getRandomName();
const test2 = 'riffyn.test.2';
const test4 = 'riffyn.test.4';
const role1 = 'designer';
const role2 = 'viewer';
const role3 = 'operator';
const errMsg = 'element was not loaded';
const testCase = 'test2 should be designer ' + 
	'and test4 should be operator of the shared experiment';


describe('User Role on Shared Experiment', () => {

	it(testCase, () => {

		LoginPage.login(config.app.admin.username,
			config.app.admin.password);
		browser.waitForElement(Home.openLeftNav,
			config.app.waitTime, `openLeftNav ${errMsg}`);
		Home.openLeftNav.click();
		browser.waitForElement(Team.teamsLeftNavLink, config.app.waitTime,
			`Teams LeftNav Menu Link ${errMsg}`);
		Team.teamsLeftNavLink.click();
		Team.create(team1, test2);
		browser.pause(config.app.waitTime);
		Team.create(team2, test4);
		browser.url('library/processes');
		Process.create(processName);
		MainMenu.shareWithRole(test2, role1, false);
		MainMenu.shareWithRole(test4, role2, false);
		MainMenu.shareWithRole(team1, role3, false);
		MainMenu.shareWithRole(team2, role3, false);
		Experiment.create(experimentName);
		browser.switchTab(browser.getTabIds()[2]);
		browser.pause(config.app.waitTime);
		LoginPage.logout();
		LoginPage.login(config.app.test2.username,
			config.app.test2.password);
		browser.url('library/experiments');
		Home.searchAndAssertUserRole(experimentName, 'Designer');
		LoginPage.logout();
		LoginPage.login(config.app.test4.username,
			config.app.test4.password);
		browser.url('library/experiments');
		Home.searchAndAssertUserRole(experimentName, 'Operator');

	});

});
