import LoginPage from '../pageobjects/login.page';
import getRandomName from '../helpers/get_random_name';
import Run from '../pageobjects/run.page';
import Step from '../pageobjects/step.page';
import ResourceToolbar from '../pageobjects/resource.toolbar.page';
import CreateRun from '../pageobjects/create.run.page';
import experimentOfProcess from '../pageobjects/create.experiment.page';
import waitForElement from '../helpers/wait_for_element';
import testProcessAndExperiment from '../pageobjects/testdata.delete';
const config = require('config');
const randomName = getRandomName();
const errMsg = 'element was not loaded';
const runRowCSS = '.data-table.rf-frozen-run-table .data-table-row';
let runRowCount;


describe('Copy Run Plans Test', () => {

	before(() => {

		LoginPage.login(config.app.admin.username, config.app.admin.password);

	});

	it('should copy run plans within the connected steps', () => {

		experimentOfProcess.createConnectedSteps(randomName);
		CreateRun.createMultipleRuns(randomName, 3);
		Step.nextStepBox.click();
		browser.pause(config.app.waitTime);
		CreateRun.createMultipleRuns(randomName, 3);
		Run.anchorOfFirstStep.click();
		browser.waitForElement(Run.firstStepFirstRunLabel,
			config.app.waitTime, `firstStepFirstRunLabel ${errMsg}`);
		Run.firstStepFirstRunLabel.click();
		browser.waitForElement(Run.nextStepFirstRunLabel,
			config.app.waitTime, `nextStepFirstRunLabel ${errMsg}`);
		Run.nextStepFirstRunLabel.click();
		browser.pause(config.app.waitTime);
		browser.waitForElement(Run.copyRunPlans,
			config.app.waitTime, `Copy Run Plans Icon ${errMsg}`);
		Run.copyRunPlans.click();
		browser.pause(config.app.waitTime);
		runRowCount = browser.selectorExecute(runRowCSS,
			(rows) => {
				return rows.length;
		});
		expect(runRowCount).to.equal(8);
		// testProcessAndExperiment.delete(randomName);

	});

});