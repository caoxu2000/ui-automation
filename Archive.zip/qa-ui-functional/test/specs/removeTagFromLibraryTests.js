import LoginPage from '../pageobjects/login.page';
import getRandomName from '../helpers/get_random_name';
import Home from '../pageobjects/home.page';
import Tag from '../pageobjects/tag.page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const randomName = getRandomName();
const errMsg = 'element was not loaded';


describe('Remove Tag From My Library Test', () => {

	it('should remove the Tag in riffyn.test.2\'s Tag library', () => {

		LoginPage.login(config.app.admin.username, config.app.admin.password);
		Tag.create(randomName);
		Home.searchInputField.setValue(randomName);
		browser.keys(['Enter']);
		browser.pause(config.app.waitTime);
		browser.waitForElement($(`td*=${randomName}`),
			config.app.waitTime, `Newly Created Tag Row ${errMsg}`);
		$(`td*=${randomName}`).rightClick();
		browser.pause(config.app.waitTime);
		browser.waitForElement(Home.share,
			config.app.waitTime, `Share Context Menu ${errMsg}`);
		Home.shareTag.click();
		browser.waitForElement(Home.searchUserBox,
			config.app.waitTime, `Search User Box ${errMsg}`);
		Home.searchUserBox.setValue('riffyn.test.2');
		browser.waitForElement(Home.selectFirstUser,
			config.app.waitTime, `First User In Search Results ${errMsg}`);
		Home.selectFirstUser.click();
		browser.waitForElement(Home.userRoleDropDown,
			config.app.waitTime, `User Role DropDown ${errMsg}`);
		Home.userRoleDropDown.selectByValue('viewer');
		browser.waitForElement(Home.shareBtn,
			config.app.waitTime, `Share Button ${errMsg}`);
		Home.shareBtn.click();
		browser.pause(config.app.waitTime);
		Home.confirm.click();
		browser.pause(config.app.waitTime);

		LoginPage.logout();
		LoginPage.login(config.app.test2.username,
			config.app.test2.password);
		browser.waitForElement(Home.openLeftNav,
			config.app.waitTime, `Open in LeftNav ${errMsg}`);
		Home.openLeftNav.click();
		browser.waitForElement(Tag.tagLibraryLink,
			config.app.waitTime, `Tag Library Link ${errMsg}`);
		Tag.tagLibraryLink.click();
		browser.waitForElement(Home.searchInputField,
			config.app.waitTime, `Search Input in Tag Library ${errMsg}`);
		Home.searchInputField.setValue(randomName);
		browser.keys(['Enter']);
		browser.pause(config.app.waitTime);
		$(`td*=${randomName}`).rightClick();
		browser.waitForElement(Home.removeFromMyLibrary,
			config.app.waitTime, `Remove From My Library Menu ${errMsg}`);
		Home.removeFromMyLibrary.click();
		browser.waitForElement(Home.confirm,
			config.app.waitTime, `Remove Tag Confirm Button ${errMsg}`);
		Home.confirm.click();
		browser.pause(config.app.waitTime);
		expect($(`td*=${randomName}`).isExisting()).to.be.false;
		expect(Home.noSearchResults.isExisting()).to.be.true;
    expect(Home.noSearchResults.getText()).to.equal('No search results found.');

	});

});
