import LoginPage from '../pageobjects/login.page';
import getRandomName from '../helpers/get_random_name';
import Home from '../pageobjects/home.page';
import Team from '../pageobjects/team.page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const team1 = 'Team ' + getRandomName();
const admin = config.app.admin.username;
const adminPwd = config.app.admin.password;
const test2 = config.app.test2.username;
const test4 = config.app.test4.username;
const test4Pwd = config.app.test2.password
const errMsg = 'element was not loaded';


describe('Remove Shared Team With Me From My Team Library Test', () => {

	it('should remove the team in riffyn.test.2\'s team library', () => {

		LoginPage.login(admin, adminPwd);
		browser.url('library/teams');
		browser.waitForElement(Team.createTeamPlus, config.app.longerWait,
			`Create Team Plus ${errMsg}`);
		Team.create(team1, test2);
		browser.waitForElement(Home.searchInputField, config.app.waitTime,
			`Search box ${errMsg}`);
		Home.searchInputField.setValue(team1);
		browser.keys(['Enter']);
		browser.pause(config.app.waitTime);
		browser.waitForElement($(`td*=${team1}`),
			config.app.waitTime, `Newly Created Team Row ${errMsg}`);
		$(`td*=${team1}`).rightClick();
		browser.pause(config.app.waitTime);
		browser.waitForElement(Home.shareContextMenu,
			config.app.waitTime, `Share Context Menu ${errMsg}`);
		Home.shareContextMenu.click();
		browser.waitForElement(Home.inactiveTab,
			config.app.waitTime, `Collaborator Tab which is inactive ${errMsg}`);
		Home.inactiveTab.click();
		Home.removeCollaborator();
		Home.inactiveTab.click();
		browser.waitForElement(Home.searchUserBox,
			config.app.waitTime, `Search User Box ${errMsg}`);
		Home.searchUserBox.setValue(test4);
		browser.waitForElement(Home.selectFirstUser,
			config.app.waitTime, `First User In Search Results ${errMsg}`);
		Home.selectFirstUser.click();
		browser.waitForElement(Home.userRoleDropDown,
			config.app.waitTime, `User Role DropDown ${errMsg}`);
		Home.userRoleDropDown.selectByValue('viewer');
		browser.waitForElement(Home.shareBtn,
			config.app.waitTime, `Share Button ${errMsg}`);
		Home.shareBtn.click();
		browser.pause(config.app.waitTime);
		Home.confirm.click();
		browser.pause(config.app.waitTime);

		LoginPage.logout();
		LoginPage.login(test4, test4Pwd);
		browser.url('library/teams');
		browser.waitForElement(Team.teamSharedWithMe,
			config.app.waitTime, `Shared With Me leftnav ${errMsg}`);
		Team.teamSharedWithMe.click();
		browser.waitForElement(Home.searchInputField,
			config.app.waitTime, `Search Input in Team Library ${errMsg}`);
		Home.searchInputField.setValue(team1);
		browser.keys(['Enter']);
		browser.pause(config.app.waitTime);
		$(`td*=${team1}`).rightClick();
		browser.waitForElement(Home.removeFromMyLibrary,
			config.app.waitTime, `Remove From My Library Menu ${errMsg}`);
		Home.removeFromMyLibrary.click();
		browser.waitForElement(Home.confirm,
			config.app.waitTime, `Remove Team Confirm Button ${errMsg}`);
		Home.confirm.click();
		browser.pause(config.app.waitTime);
		expect($(`td*=${team1}`).isExisting()).to.be.false;
		expect(Home.noSearchResults.isExisting()).to.be.true;
    expect(Home.noSearchResults.getText()).to.equal('No search results found.');

	});

});
