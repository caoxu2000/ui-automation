import LoginPage from '../pageobjects/login.page';
import Home from '../pageobjects/home.page';
import Process from '../pageobjects/process.page';
import getRandomName from '../helpers/get_random_name';
import waitForElement from '../helpers/wait_for_element';
import MainMenu from '../pageobjects/main.menu.page';
import Team from '../pageobjects/team.page';
import Role from '../pageobjects/role.page';
const config = require('config');
const processName = getRandomName();
const team1 = 'Team1 ' + getRandomName();
const team2 = 'Team2 ' + getRandomName();
const test2 = 'riffyn.test.2';
const test4 = 'riffyn.test.4';
const role1 = 'designer';
const role2 = 'viewer';
const role3 = 'operator';
const errMsg = 'element was not loaded';
const testCase = 'test2 and test4 should be able to ' +
	'share and duplicate of the shared process. test2 ' +
	'should have designer role and test4 should have viewer role' +
	' of the shared process';


describe('User Role on Shared Process', () => {

	it(testCase, () => {

		LoginPage.login(config.app.admin.username,
			config.app.admin.password);
		browser.waitForElement(Home.openLeftNav,
			config.app.waitTime, `openLeftNav ${errMsg}`);
		Home.openLeftNav.click();
		browser.waitForElement(Team.teamsLeftNavLink, config.app.waitTime,
			`Teams LeftNav Menu Link ${errMsg}`);
		Team.teamsLeftNavLink.click();
		Team.create(team1, test2);
		Team.create(team2, test4);
		browser.url('library/processes');
		Process.create(processName);
		MainMenu.shareWithRole(test2, role1);
		MainMenu.shareWithRole(test4, role2);
		MainMenu.shareWithRole(team1, role3);
		MainMenu.shareWithRole(team2, role3);
		LoginPage.logout();
		LoginPage.login(config.app.test2.username,
			config.app.test2.password);
		$(`td*=${processName}`).doubleClick();
		browser.switchTab(browser.getTabIds()[2]);
		browser.waitForElement(Role.role,
			config.app.waitTime, `User Role Label Upper Right Corner ${errMsg}`);
		expect(Role.role.getText().toUpperCase()).to.equal(`(${role1.toUpperCase()})`);
		browser.waitForElement(MainMenu.dropdown,
			config.app.waitTime, `Design Upper Left Menu ${errMsg}`);
		MainMenu.dropdown.click();
		browser.waitForElement(MainMenu.shareLnk,
			config.app.waitTime, `Share Process Menu ${errMsg}`);
		MainMenu.shareLnk.click();
		browser.pause(config.app.waitTime);
		expect(Process.searchUserBox.isExisting()).to.be.true;
		browser.waitForElement(Process.cancelX,
			config.app.waitTime, `Close/Cancel X On Share Modal ${errMsg}`);
		Process.cancelX.click();
		browser.pause(config.app.waitTime);
		MainMenu.dropdown.click();
		browser.waitForElement(MainMenu.duplicateLnk,
			config.app.waitTime, `Duplicate Process Menu ${errMsg}`);
		MainMenu.duplicateLnk.click();
		browser.pause(config.app.waitTime);
		expect(Process.processName.isExisting()).to.be.true;
		Process.cancelX.click();
		browser.pause(config.app.waitTime);
		LoginPage.logout();
		LoginPage.login(config.app.test4.username,
			config.app.test4.password);
		$(`td*=${processName}`).doubleClick();
		browser.switchTab(browser.getTabIds()[3]);
		browser.waitForElement(Role.role,
			config.app.waitTime, `User Role Label Upper Right Corner ${errMsg}`);
		expect(Role.role.getText().toUpperCase()).to.equal(`(${role3.toUpperCase()})`);
		browser.waitForElement(MainMenu.dropdown,
			config.app.waitTime, `Design Upper Left Menu ${errMsg}`);
		MainMenu.dropdown.click();
		browser.waitForElement(MainMenu.shareLnk,
			config.app.waitTime, `Share Process Menu ${errMsg}`);
		MainMenu.shareLnk.click();
		browser.pause(config.app.waitTime);
		expect(Process.searchUserBox.isExisting()).to.be.true;
		browser.waitForElement(Process.cancelX,
			config.app.waitTime, `Close/Cancel X On Share Modal ${errMsg}`);
		Process.cancelX.click();
		browser.pause(config.app.waitTime);
		MainMenu.dropdown.click();
		browser.waitForElement(MainMenu.duplicateLnk,
			config.app.waitTime, `Duplicate Process Menu ${errMsg}`);
		MainMenu.duplicateLnk.click();
		browser.pause(config.app.waitTime);
		expect(Process.processName.isVisible(), 'Process Name in Operator Design mode').to.be.true;
		Process.cancelX.click();
		browser.pause(config.app.waitTime);

	});

});
