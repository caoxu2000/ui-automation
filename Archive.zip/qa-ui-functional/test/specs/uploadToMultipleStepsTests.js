import LoginPage from '../pageobjects/login.page';
import Home from '../pageobjects/home.page';
import experimentOfProcess from '../pageobjects/create.experiment.page';
import fileUpload from '../pageobjects/fileupload.config';
import getRandomName from '../helpers/get_random_name';
import Run from '../pageobjects/run.page';
import Step from '../pageobjects/step.page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const path = require('path');
const filePath = path.join(__dirname, config.app.uploadFile);
const randomName = getRandomName();
const testSuiteName = `should upload a file, config, and add it to 
a new collection for 2 steps and then apply the collection to 2 steps`;
const errMsg = 'element was not loaded';


describe('Upload File to Multiple Steps Test', () => {

	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it(testSuiteName, () => {

		experimentOfProcess.createConnectedSteps(randomName);
		// Upload file to First Step and configure it and delete runs after
		browser.waitForElement(Run.fileUploadIcon, config.app.waitTime,
			`fileUploadIcon ${errMsg}`);
		fileUpload.config(filePath, 'output');
		browser.waitForElement(Run.fileUploadIcon, config.app.waitTime,
			`fileUploadIcon ${errMsg}`);
		Run.deleteTestRuns();
		browser.pause(config.app.waitTime);

		// While at First Step is highlighted, add above config to create a new collection
		browser.waitForElement(Run.fileUploadIcon, config.app.waitTime,
			`fileUploadIcon ${errMsg}`);
		fileUpload.addToNewCollection(randomName, filePath);
		fileUpload.closeButton.click();
		browser.pause(config.app.waitTime);
		
		// Upload file to Next Step and configure it and delete runs after
		browser.waitForElement(Step.nextStepBox, config.app.waitTime,
			`Next Step Box ${errMsg}`);
		Step.nextStepBox.click();
		browser.pause(config.app.waitTime);
		browser.debug();
		fileUpload.config(filePath, 'input');
		browser.waitForElement(Run.fileUploadIcon, config.app.waitTime,
			`fileUploadIcon ${errMsg}`);
		Run.deleteTestRuns();
		browser.pause(config.app.waitTime);

		// Add Config in Next Step to the Collection
		browser.waitForElement(Run.fileUploadIcon, config.app.waitTime,
			`fileUploadIcon ${errMsg}`);
		fileUpload.clickFileUpload(filePath);
		browser.waitForElement(fileUpload.addToCollectionDropdown,
			config.app.waitTime, `Add To Collection Dropdown ${errMsg}`);
		fileUpload.addToCollectionDropdown.click();
		browser.pause(config.app.waitTime);
		fileUpload.firstExistingCollection.click();
		browser.waitForElement(fileUpload.confirmButton, config.app.waitTime,
			`Confirm Button ${errMsg}`);
		fileUpload.confirmButton.click();
		browser.pause(config.app.waitTime);
		// Click on Colleciton tab to apply uploaded data to both Steps
		browser.waitForElement(fileUpload.collecitonsTab,config.app.waitTime,
			`Collecitons Tab ${errMsg}`);
		fileUpload.applyNewCollection();
		browser.pause(config.app.dbConfigLoadTime);

		// Assertions
		browser.waitForElement(Run.run1stProperty8thCol,config.app.waitTime, 'run1stProperty8thCol');
		let pHFirstStep = Run.run1stProperty8thCol.getValue();
		let runResourceFirstStep = Run.resourceName.getValue();
		let runNameFirstStep = Run.runName.getValue();
		expect([pHFirstStep, runNameFirstStep, runResourceFirstStep])
			.to.deep.equal(['6.96', 'SA-1', 'SA-1']);
		Step.firstStepBox.click();
		browser.waitForElement(Run.run1stProperty7thCol,config.app.waitTime, 'run1stProperty7thCol');
		let pHNextStep = Run.run1stProperty7thCol.getValue();
		let runNameNextStep = Run.runName.getValue();
		let runResourceNextStep = Run.resourceName.getValue();
		expect([pHNextStep, runNameNextStep, runResourceNextStep])
			.to.deep.equal(['6.96', 'SA-1', 'SA-1']);

	});

});