import LoginPage from '../pageobjects/login.page';
import Experiment from '../pageobjects/experiment.page';
import ResourceToolbar from '../pageobjects/resource.toolbar.page';
import getRandomName from '../helpers/get_random_name';
import Run from '../pageobjects/run.page';
import experimentOfProcess from '../pageobjects/create.experiment.page';
import testProcessAndExperiment from '../pageobjects/testdata.delete';
import waitForElement from '../helpers/wait_for_element';

const config = require('config');
const testName = 'Delete Run Test';
const randomName = getRandomName();
const errMsg = 'element was not loaded';


describe(testName, () => {

	before(() => {

		LoginPage.login(config.app.admin.username, config.app.admin.password);
		experimentOfProcess.create(randomName);

	});

	it('should delete newly created runs under the actual', () => {

		browser.waitForElement(ResourceToolbar.createNewRunPlus, config.app.downloadWaitTime,
			`createNewRunPlus ${errMsg}`);
		ResourceToolbar.createNewRunPlus.click();
		browser.waitForElement(ResourceToolbar.runCounter, config.app.waitTime,
			`runCounter ${errMsg}`);
		ResourceToolbar.runCounter.setValue('5');
		ResourceToolbar.runPrefixName.setValue(randomName);
		ResourceToolbar.createRunBtn.click();
		browser.pause(config.app.downloadWaitTime);
		browser.waitForElement(Run.fileUploadIcon, config.app.waitTime,
			`fileUploadIcon ${errMsg}`);
		Run.deleteTestRuns();
		expect(Run.allRunTRs.isExisting()).to.be.false;
		// testProcessAndExperiment.delete(randomName);

	});

});