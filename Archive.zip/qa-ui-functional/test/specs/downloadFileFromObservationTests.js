import LoginPage from '../pageobjects/login.page';
import Comment from '../pageobjects/comment.page';
import experimentOfProcess from '../pageobjects/create.experiment.page';
import getRandomName from '../helpers/get_random_name';
import waitForElement from '../helpers/wait_for_element';


const fs = require('fs-extra');
const config = require('config');
const path = require('path');
const expected = path.join(__dirname, config.app.ObservationsExpected);
const actual = path.join(__dirname, config.app.ObservationsActual);
const randomName = getRandomName();
const errMsg = 'element was not loaded';


describe('Download File Attachment of Observation Test', () => {

	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it('should download the file attachment that was uploaded', () => {

		experimentOfProcess.create(randomName);
		browser.waitForElement(Comment.observationsTab, config.app.waitTime,
			`Observations Tab ${errMsg}`);
		Comment.observationsTab.click();
		browser.waitForElement(Comment.uploadClip, config.app.waitTime,
			`Upload File Clipper Icon ${errMsg}`);
		Comment.uploadClip.click();
		browser.pause(config.app.waitTime);
		browser.chooseFile('.add-media-files', expected);
		browser.pause(config.app.downloadWaitTime);
		browser.waitForElement(Comment.mediaImage, config.app.waitTime,
			`Media Image ${errMsg}`);
		Comment.saveComment.click();
		browser.waitForElement(Comment.downloadMedia, config.app.waitTime,
			`Download Icon on upper right corner of the Image ${errMsg}`);
		Comment.downloadMedia.click();
		browser.pause(config.app.downloadWaitTime);

		let match = null;
		let expectedFile = fs.readFileSync(expected);
    let actualFile = fs.readFileSync(actual);
    match = expectedFile.toString('binary') === actualFile.toString('binary');
    console.log(`Expected image ${expected}`);
    console.log(`Actual image ${actual}`);
    expect(match).to.be.true;
    fs.removeSync(actual);

	});

});