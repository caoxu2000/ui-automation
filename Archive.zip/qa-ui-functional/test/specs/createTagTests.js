import LoginPage from '../pageobjects/login.page';
import getRandomName from '../helpers/get_random_name';
import Home from '../pageobjects/home.page';
import Tag from '../pageobjects/tag.page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const randomName = getRandomName();
const errMsg = 'element was not loaded';


describe('Create Tags Test', () => {

	it('should create a new Tag in library', () => {

		LoginPage.login(config.app.admin.username,
			config.app.admin.password);
		Tag.create(randomName);
		$(`td*=${randomName}`).rightClick();
		browser.waitForElement(Home.open,
			config.app.waitTime, `open menu ${errMsg}`);
		Home.open.click();
		browser.pause(config.app.waitTime);
		expect(Tag.tagName.getValue()).to.equal(randomName);

	});

});
