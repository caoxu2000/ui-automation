import LoginPage from '../pageobjects/login.page';
import getRandomName from '../helpers/get_random_name';
import Home from '../pageobjects/home.page';
import Tag from '../pageobjects/tag.page';
import ContextMenu from '../pageobjects/context.menu.page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const randomName = getRandomName();
const errMsg = 'element was not loaded';


describe('Add and Remove a Tag of a Tag Test', () => {

	it('should add and remove tag of a tag', () => {

		LoginPage.login(config.app.admin.username,
			config.app.admin.password);
		Tag.create(randomName);
		Home.searchInputField.setValue(randomName);
		browser.keys(['Enter']);
		browser.pause(config.app.waitTime);
		$(`td*=${randomName}`).rightClick();
		browser.waitForElement(ContextMenu.addOrRemove,
			config.app.waitTime, `add Or Remove Tag ${errMsg}`);
		ContextMenu.addOrRemove.click();
		browser.waitForElement(ContextMenu.tagName,
			config.app.waitTime, `Tag Name Input Field ${errMsg}`);
		ContextMenu.tagName.setValue('Tag A');
		browser.pause(config.app.waitTime);
		Home.autoComplete1stListItem.click();
		browser.waitForElement(Tag.tagInAddRemoveTagPopup,
			config.app.waitTime, `Tag in Add Remove Tag popup ${errMsg}`);
		ContextMenu.tagUpdateBtn.click();
		browser.pause(config.app.waitTime);
		ContextMenu.tagPill.click();
		browser.pause(config.app.waitTime);
		expect($(`td*=${randomName}`).isExisting()).to.be.true;
		$(`td*=${randomName}`).rightClick();
		browser.waitForElement(ContextMenu.addOrRemove,
			config.app.waitTime, `add Or Remove Tag ${errMsg}`);
		ContextMenu.addOrRemove.click();
		browser.pause(config.app.waitTime);
		browser.waitForElement(ContextMenu.removeTag,
			config.app.waitTime, `X Remove icon ${errMsg}`);
		ContextMenu.removeTag.click();
		browser.pause(config.app.waitTime);
		browser.waitForElement(ContextMenu.tagUpdateBtn,
			config.app.waitTime, `Update Tag Enabled ${errMsg}`);
		ContextMenu.tagUpdateBtn.click();
		browser.pause(config.app.waitTime);
		expect($(`td*=${randomName}`).isExisting()).to.be.false;
    expect(Home.noSearchResults.isExisting()).to.be.true;
    expect(Home.noSearchResults.getText()).to.equal('No search results found.');

	});

});
