import LoginPage from '../pageobjects/login.page';
import Comment from '../pageobjects/comment.page';
import experimentOfProcess from '../pageobjects/create.experiment.page';
import testProcessAndExperiment from '../pageobjects/testdata.delete';
import getRandomName from '../helpers/get_random_name';
import addComment from '../pageobjects/add.comment.page';
import waitForElement from '../helpers/wait_for_element';

const config = require('config');
const expectedComment = getRandomName();
const errMsg = 'element was not loaded';


describe('Reply to Experiment Observation Comment Test', () => {

	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
		experimentOfProcess.create(expectedComment);
	});

	it('should generate a new comment below the existing and indent to the right', () => {

		browser.waitForElement(Comment.observationsTab, config.app.waitTime,
			`Observations Tab ${errMsg}`);
		Comment.observationsTab.click();
		browser.pause(config.app.waitTime);
		addComment.add(expectedComment);
		browser.waitForElement(Comment.replyToComment, config.app.waitTime,
			`ReplyTo Observation Note Icon ${errMsg}`);
		Comment.replyToComment.click();
		browser.waitForElement(Comment.replyToArea, config.app.waitTime,
			`ReplyTo Input Area ${errMsg}`);
		Comment.replyToArea.setValue(expectedComment);
		browser.waitForElement(Comment.saveReplyToComment, config.app.waitTime,
			`Save Button ${errMsg}`);
		Comment.saveReplyToComment.click();
		browser.pause(config.app.waitTime);
		let actualComment = Comment.replyToCommentView.getText();
		expect(actualComment).equals(expectedComment);
		// testProcessAndExperiment.delete(expectedComment);

	});

});