import LoginPage from '../pageobjects/login.page';
import getRandomName from '../helpers/get_random_name';
import Home from '../pageobjects/home.page';
import Property from '../pageobjects/property.page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const name = getRandomName();
const updatedName = getRandomName();
const errMsg = 'element was not loaded';


describe('Edit Property Test', () => {

	it('should update the existing property', () => {

		LoginPage.login(config.app.admin.username, config.app.admin.password);
		Property.create(name);
		Home.searchInputField.setValue(name);
		browser.keys(['Enter']);
		browser.pause(config.app.waitTime);
		browser.waitForElement($(`td*=${name}`),
			config.app.waitTime, `1st new property ${errMsg}`);
		$(`td*=${name}`).doubleClick();
		browser.waitForElement(Property.propertyNameInput,
			config.app.waitTime, `propertyNameInput ${errMsg}`);
		Property.propertyNameInput.setValue(updatedName);
		browser.waitForElement(Property.addUnitSearchBox,
			config.app.waitTime, `addUnitSearchBox ${errMsg}`);
		Property.addUnitSearchBox.setValue('ml');
		browser.waitForElement(Property.property1stOption,
			config.app.waitTime, `property1stOption ${errMsg}`);
		Property.property1stOption.click();
		browser.pause(config.app.waitTime);
		Property.done.click();
		browser.pause(config.app.waitTime);
		Home.clearSearch.click();
		browser.waitForElement($(`td*=${updatedName}`),
			config.app.waitTime, `updated property ${errMsg}`);
		$(`td*=${updatedName}`).doubleClick();
		browser.waitForElement(Property.permitted1stUnit,
			config.app.waitTime, `newly added unit ${errMsg}`);
		expect(Property.propertyNameInput.getValue()).to.equal(updatedName);
		expect(Property.permitted1stUnit.getText()).to.equal('milliliter');
		Property.cancelPropertyButton.click();
		browser.pause(config.app.waitTime);
		$(`td*=${updatedName}`).rightClick();
		browser.pause(config.app.waitTime);
		Home.deleteTestRow(updatedName);

	});

});
