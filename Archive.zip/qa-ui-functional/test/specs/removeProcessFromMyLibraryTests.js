import LoginPage from '../pageobjects/login.page';
import Home from '../pageobjects/home.page';
import Step from '../pageobjects/step.page';
import Process from '../pageobjects/process.page';
import getRandomName from '../helpers/get_random_name';
import waitForElement from '../helpers/wait_for_element';
import MainMenu from '../pageobjects/main.menu.page';
import Role from '../pageobjects/role.page';
const config = require('config');
const randomName = getRandomName();
const msg = 'No search results found.';
const errMsg = 'element was not loaded';


describe('Remove a Process from My Library Test', () => {

	it('should be able to remove if another uesr is admin of it', () => {

		LoginPage.login(config.app.admin.username,
			config.app.admin.password);
		Process.create(randomName);
		MainMenu.dropdown.click();
		browser.waitForElement(Process.shareProcessMnu,
			config.app.waitTime, `Share Process Menu ${errMsg}`);
		MainMenu.shareLnk.click();
		browser.waitForElement(Process.searchUserBox,
			config.app.waitTime, `Search User Input Field ${errMsg}`);
		Process.searchUserBox.setValue('riffyn.test.2');
		browser.waitForElement(Process.selectFirstUser,
			config.app.waitTime, `First User In Search Results ${errMsg}`);
		Process.selectFirstUser.click();
		browser.waitForElement(Process.shareBtn,
			config.app.waitTime, `Share Button ${errMsg}`);
		Process.shareBtn.click();
		browser.waitForElement(Process.confirmationBtn,
			config.app.waitTime, `Confirmation Button ${errMsg}`);
		Process.confirmationBtn.click();
		browser.pause(config.app.waitTime);
		LoginPage.logout();
		LoginPage.login(config.app.test2.username,
			config.app.test2.password);
		browser.waitForElement(Home.searchInputField,
			config.app.waitTime, `Search Input in Process Library ${errMsg}`);
		Home.searchInputField.setValue(randomName);
		browser.keys(['Enter']);
		browser.pause(config.app.waitTime);
		$(`td*=${randomName}`).rightClick();
		browser.waitForElement(Process.removeFromMyLibrary,
			config.app.waitTime, `Remove From My Library Menu ${errMsg}`);
		Process.removeFromMyLibrary.click();
		browser.waitForElement(Process.updateProcessNameBtn,
			config.app.waitTime, `Update Process Name Button ${errMsg}`);
		Process.updateProcessNameBtn.click();
		browser.pause(config.app.waitTime);
		expect($(`td*=${randomName}`).isExisting()).to.be.false;
		expect(Home.noSearchResults.isExisting()).to.be.true;
    expect(Home.noSearchResults.getText()).to.equal('No search results found.');

	});

});
