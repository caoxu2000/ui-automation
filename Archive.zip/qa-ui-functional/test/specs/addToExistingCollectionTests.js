import LoginPage from '../pageobjects/login.page';
import testProcessAndExperiment from '../pageobjects/testdata.delete';
import experimentOfProcess from '../pageobjects/create.experiment.page';
import fileUpload from '../pageobjects/fileupload.config';
import getRandomName from '../helpers/get_random_name';
import Run from '../pageobjects/run.page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const path = require('path');
const filePath = path.join(__dirname, config.app.uploadFile);
const randomName = getRandomName();
const testSuiteName = 'should add a config to existing collection';
const errMsg = 'element was not loaded';


describe('Add to Existing Collection', () => {

	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it(testSuiteName, () => {

		experimentOfProcess.createConnectedSteps(randomName);
		browser.waitForElement(Run.fileUploadIcon, config.app.downloadWaitTime,
			`fileUploadIcon ${errMsg}`);
		fileUpload.addToExistingCollection(randomName, filePath);
		fileUpload.collecitonsTab.click();
		browser.waitForElement(fileUpload.collectionExpand, config.app.downloadWaitTime,
			`Collection Expand Arrow ${errMsg}`);
		fileUpload.collectionExpand.click();
		browser.pause(config.app.waitTime);
		expect(Run.collectionItemName.getText()).to.equal('8runs.xlsx');
		let itemCounter = browser.selectorExecute('.item.hide-btn', (item) => {
			return item.length;
		});
		expect(itemCounter).to.equal(2);
		// testProcessAndExperiment.delete(randomName);

	});

});