import LoginPage from '../pageobjects/login.page';
import getRandomName from '../helpers/get_random_name';
import Home from '../pageobjects/home.page';
import ResourceType from '../pageobjects/resourcetype.page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const randomName = getRandomName();
const errMsg = 'element was not loaded';
const testProperty = 'pH';
const testComponent = 'WATER';


describe('Delete Resource Type Test', () => {

	it('should remove the resource type in library', () => {

		LoginPage.login(config.app.admin.username, config.app.admin.password);
		ResourceType.create(randomName, testProperty, testComponent);
		Home.searchInputField.setValue(randomName);
		browser.keys(['Enter']);
		browser.pause(config.app.waitTime);
		browser.waitForElement($(`td*=${randomName}`),
			config.app.waitTime, `resource type row ${randomName} ${errMsg}`);
		$(`td*=${randomName}`).rightClick();
		browser.waitForElement(Home.delete,
			config.app.waitTime, `Delete in Context menu ${errMsg}`);
    Home.delete.click();
    browser.waitForElement(Home.confirm,
			config.app.waitTime, `Delete button in popup ${errMsg}`);
		Home.confirm.click();
		browser.pause(config.app.waitTime);
    expect($(`td*=${randomName}`).isExisting()).to.be.false;
    expect(Home.noSearchResults.isExisting()).to.be.true;
    expect(Home.noSearchResults.getText()).to.equal('No search results found.');

	});

});
