import LoginPage from '../pageobjects/login.page';
import Process from '../pageobjects/process.page';
import Experiment from '../pageobjects/experiment.page';
import Step from '../pageobjects/step.page';
import getRandomName from '../helpers/get_random_name';
import testProcessAndExperiment from '../pageobjects/testdata.delete';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const testsuite = 'Require Upload Data From a DB Query at Experiment Step level Test';
const testcase = 'Should add Database icon to the Step in the Experiment';
const errMsg = 'element was not loaded';
const randomName = getRandomName();


describe(testsuite, () => {

	it(testcase, () => {

		LoginPage.login(config.app.admin.username, config.app.admin.password);
		Process.create(randomName);
		browser.switchTab(browser.getTabIds()[1]);
		Experiment.create(randomName);
		browser.switchTab(browser.getTabIds()[2]);
		Step.requireFromDBQuery();
		browser.waitForElement(Step.confirmation,
			config.app.waitTime, `Yes Button ${errMsg} on line 26`);
		Step.confirmation.click();
		browser.pause(config.app.waitTime);
		browser.waitForElement(Step.dbIconOnStep,
			config.app.waitTime, `DB icon ${errMsg} on line 30`);
		expect(Step.dbIconOnStep.isExisting()).to.be.true;
		browser.switchTab(browser.getTabIds()[1]);
		browser.waitForElement(Step.dbIconOnStep,
			config.app.waitTime, `DB icon ${errMsg} on line 34`);
		expect(Step.dbIconOnStep.isExisting()).to.be.true;
		browser.switchTab(browser.getTabIds()[2]);
		Step.unRequireFromDBQuery();
		browser.waitForElement(Step.confirmation,
			config.app.waitTime, `Yes Button ${errMsg} on line 40`);
		Step.confirmation.click();
		browser.pause(config.app.waitTime);
		expect(Step.dbIconOnStep.isExisting()).to.be.false;
		browser.switchTab(browser.getTabIds()[1]);
		browser.pause(config.app.waitTime);
		expect(Step.dbIconOnStep.isExisting()).to.be.false;
		// testProcessAndExperiment.delete(randomName);

	});

});
