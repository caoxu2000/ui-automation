import LoginPage from '../pageobjects/login.page';
import experimentOfProcess from '../pageobjects/create.experiment.page';
import CreateRun from '../pageobjects/create.run.page';
import Run from '../pageobjects/run.page';
import getRandomName from '../helpers/get_random_name';
import waitForElement from '../helpers/wait_for_element';

const config = require('config');
const testName = 'Plan tab in Run table Test';
const randomName = getRandomName();
const errMsg = 'element was not loaded';


describe(testName, () => {

	before(() => {

		LoginPage.login(config.app.admin.username, config.app.admin.password);
		experimentOfProcess.createConnectedSteps(randomName);

	});

	it('should generate the Run Name under the plan tab', () => {

		CreateRun.createMultipleRuns(randomName, '5');
    browser.pause(config.app.downloadWaitTime);
    Run.plan.click();
    browser.waitForElement(Run.run5thRunName, config.app.waitTime,
			`5th Run Name input field ${errMsg}`);
    expect(Run.run1stProperty7thCol.getAttribute('placeholder')).to.equal('12');
    expect(Run.run2ndProperty7thCol.getAttribute('placeholder')).to.equal('12');
    expect(Run.run3rdProperty7thCol.getAttribute('placeholder')).to.equal('12');
    expect(Run.run4thProperty7thCol.getAttribute('placeholder')).to.equal('12');
    expect(Run.run5thProperty7thCol.getAttribute('placeholder')).to.equal('12');
		expect(Run.run1stRunName.getValue()).to.equal(`${randomName} 1`);
		expect(Run.run2ndRunName.getValue()).to.equal(`${randomName} 2`);
		expect(Run.run3rdRunName.getValue()).to.equal(`${randomName} 3`);
		expect(Run.run4thRunName.getValue()).to.equal(`${randomName} 4`);
		expect(Run.run5thRunName.getValue()).to.equal(`${randomName} 5`);

	});

});