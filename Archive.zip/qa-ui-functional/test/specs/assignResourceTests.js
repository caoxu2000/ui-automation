import LoginPage from '../pageobjects/login.page';
import Resource from '../pageobjects/resource.page';
import Run from '../pageobjects/run.page';
import getRandomName from '../helpers/get_random_name';
import experimentOfProcess from '../pageobjects/create.experiment.page';
import CreateRun from '../pageobjects/create.run.page';
import waitForElement from '../helpers/wait_for_element';

const config = require('config');
const testName = 'Experiment Assign Resource Test';
const name = getRandomName();
const errMsg = 'element was not loaded';


describe(testName, () => {

	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
		experimentOfProcess.create(name);
		CreateRun.create1RunAtATime(name);
	});

	it('should assign a new resource to an experiment', () => {

		browser.waitForElement(Resource.assignResourceLnk, config.app.waitTime,
			`assignResourceLink ${errMsg}`);
		Resource.assignResourceLnk.click();
		browser.waitForElement(Resource.createNewResource, config.app.waitTime,
			`createNewResourceMenu ${errMsg}`);
		Resource.createNewResource.click();
		browser.waitForElement(Resource.resourceName, config.app.waitTime,
			`resourceNameInputField ${errMsg}`);
		Resource.resourceName.waitForEnabled();
		Resource.resourceName.setValue(name);
		Resource.createResourceBtn.click();
		browser.pause(config.app.waitTime);
		Run.checkAllRuns.click();
		browser.pause(config.app.waitTime);
		Resource.assignResourceBtn.click();
		browser.pause(config.app.longWait);
		let actualResourceName = Resource.resourceValue.getValue();
		expect(actualResourceName).equals(name);

	});

});