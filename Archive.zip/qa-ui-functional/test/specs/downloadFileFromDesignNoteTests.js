import LoginPage from '../pageobjects/login.page';
import getRandomName from '../helpers/get_random_name';
import Comment from '../pageobjects/comment.page';
import waitForElement from '../helpers/wait_for_element';
import Process from '../pageobjects/process.page';

const fs = require('fs-extra');
const config = require('config');
const path = require('path');
const expected = path.join(__dirname, config.app.DesignNotesExpected);
const actual = path.join(__dirname, config.app.DesignNotesActual);
const randomName = getRandomName();
const errMsg = 'element was not loaded';


describe('Download attached file of design note Test', () => {

	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it('should download the file to local drive', () => {

		Process.create(randomName);
		browser.waitForElement(Comment.designNotesTab, config.app.waitTime,
			`designNotesTab ${errMsg}`);
		Comment.designNotesTab.click();
		browser.waitForElement(Comment.uploadClip, config.app.waitTime,
			`uploadClip ${errMsg}`);
		Comment.uploadClip.click();
		browser.pause(config.app.waitTime);
		browser.chooseFile('.add-media-files', expected);
		browser.pause(config.app.downloadWaitTime);
		Comment.saveComment.click();
		browser.waitForElement(Comment.mediaImage, config.app.waitTime,
			`mediaImage ${errMsg}`);
		expect(Comment.mediaImage.isExisting()).to.be.true;
		Comment.downloadMedia.click();
		browser.pause(config.app.downloadWaitTime);
		let match = null;
		let expectedFile = fs.readFileSync(expected);
    let actualFile = fs.readFileSync(actual);
    match = expectedFile.toString('binary') === actualFile.toString('binary');
    console.log(`Expected image ${expected}`);
    console.log(`Actual image ${actual}`);
    expect(match).to.be.true;
    fs.removeSync(actual);

	});

});