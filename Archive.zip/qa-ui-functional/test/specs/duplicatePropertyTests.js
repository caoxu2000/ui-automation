import LoginPage from '../pageobjects/login.page';
import getRandomName from '../helpers/get_random_name';
import Home from '../pageobjects/home.page';
import Property from '../pageobjects/property.page';
import waitForElement from '../helpers/wait_for_element';


const config = require('config');
const name1 = getRandomName();
const name2 = getRandomName();
const errMsg = 'element was not loaded';


describe('Duplicate Property Test', () => {

	it('should duplicate the existing property in property library', () => {

		LoginPage.login(config.app.admin.username, config.app.admin.password);
		Property.create(name1);
		Home.searchInputField.setValue(name1);
		browser.keys(['Enter']);
		browser.pause(config.app.waitTime);
		browser.waitForElement($(`td*=${name1}`),
			config.app.waitTime, `Newly Created Property Row ${errMsg}`);
		$(`td*=${name1}`).rightClick();
		browser.waitForElement(Home.duplicate,
			config.app.waitTime, `Duplicate in Context menu ${errMsg}`);
		Home.duplicate.click();
		browser.waitForElement(Property.nameFieldInDuplicate,
			config.app.waitTime, `Property Name Input field ${errMsg}`);
		Property.nameFieldInDuplicate.setValue(name2);
		browser.pause(config.app.waitTime);
		Property.duplicatePropertyConfirm.click();
		Home.clearSearch.click();
		Home.searchInputField.setValue(name2);
		browser.keys(['Enter']);
		browser.waitForElement($(`td*=${name2}`),
			config.app.waitTime, `Duplicated Property Row ${errMsg}`);
		$(`td*=${name2}`).doubleClick();
		browser.waitForElement(Property.propertyNameInput,
			config.app.waitTime, `Duplicated Property Name ${errMsg}`);
		expect(Property.propertyNameInput.getValue()).to.equal(name2);
		Property.cancelPropertyButton.click();
		browser.pause(config.app.waitTime);
		$(`td*=${name2}`).rightClick();
		browser.pause(config.app.waitTime);
		Home.deleteTestRow(name2);

	});

});
