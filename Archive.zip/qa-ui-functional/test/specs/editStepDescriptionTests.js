import LoginPage from '../pageobjects/login.page';
import Step from '../pageobjects/step.page';
import Resource from '../pageobjects/resource.page';
import Process from '../pageobjects/process.page';
import deleteProcess from '../pageobjects/delete.process.page';
import waitForElement from '../helpers/wait_for_element';
import getRandomName from '../helpers/get_random_name';

const config = require('config');
const randomDesc = getRandomName();
const errMsg = 'element was not loaded';


describe('Update to Step Description Test', () => {

 	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it('should update step description', () => {

		Process.create(randomDesc);
		browser.waitForElement(Step.stepDescription, config.app.waitTime,
			`Step Description Input Field ${errMsg}`);
		Step.stepDescription.setValue(randomDesc);
		Process.processNavBar.click();
		browser.pause(config.app.waitTime);
		expect(Step.stepDescription.getValue()).to.equal(randomDesc);
		// deleteProcess.delete(randomDesc);

	});

});