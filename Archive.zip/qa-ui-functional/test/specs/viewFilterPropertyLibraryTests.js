import LoginPage from '../pageobjects/login.page';
import Home from '../pageobjects/home.page';

const config = require('config');
const column = 'Column';
const sweetness = 'sweetness';
const plateID = 'Plate ID';
const tims = 'Tim\'s Special';
const transmittance = '% transmittance';


describe('View Filter In Property Library Test', () => {

	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it('should display property in their respective left panel filters', () => {

		browser.url('library/properties');
		Home.searchAndAssert(column);
		Home.createdByMe.click();
		Home.searchAndAssert(sweetness);
		Home.sharedWithMe.click();
		Home.searchAndAssert(plateID);
		Home.sharedWithRiffyn.click();
		Home.searchAndAssert(tims);
		Home.public.click();
		Home.searchAndAssert(transmittance);

	});

})