import LoginPage from '../pageobjects/login.page';
import Home from '../pageobjects/home.page';
import Experiment from '../pageobjects/experiment.page';
import getRandomName from '../helpers/get_random_name';
import Run from '../pageobjects/run.page';
import experimentOfProcess from '../pageobjects/create.experiment.page';
import testProcessAndExperiment from '../pageobjects/testdata.delete';
import Property from '../pageobjects/property.page';
import waitForElement from '../helpers/wait_for_element';

const moment = require('moment');
const config = require('config');
const expected_date = require(config.app.date);
const testName = 'date test';
const propertyName = 'date/time';
const name = getRandomName();
const errMsg = 'element was not loaded';


describe('Date/Time Manipulation Test', () => {

	before(() => {

		const propertySelector = Run.property;
		LoginPage.login(config.app.admin.username, config.app.admin.password);
		experimentOfProcess.create(name);
		Run.createNewRunInput.setValue('test1');
		browser.keys(['Enter'])
		browser.waitForElement(Run.modifyRun, config.app.downloadWaitTime,
			`Modify Menu ${errMsg}`);
		Run.modifyRun.click();
		Property.addPropertyToOutput(propertyName);

	});

	it('should output date/time correctly', () => {

		Run.actualRun.click();
		browser.waitForElement(Experiment.runTableRow(1, 2), config.app.downloadWaitTime,
			`Run Name Column ${errMsg}`);
		// test resource column that is date data type
		expected_date.forEach(each => {
			for (let i = 1; i <= 5; i++) {
				browser.keys(['ArrowRight']);
			}
			Run.dateResource.rightClick();
			browser.waitForElement(Run.formulaEditor, config.app.downloadWaitTime,
				`formulaEditor Menu ${errMsg}`);
			Run.formulaEditor.click();
			browser.waitForElement(Run.formulaInput, config.app.downloadWaitTime,
				`formulaInputField ${errMsg}`);
			Run.formulaInput.setValue(each.formula);
			browser.pause(config.app.downloadWaitTime);
			Run.updateFormulaBtn.click();
			browser.waitForElement(Run.calculationBtn, config.app.downloadWaitTime,
				`calculationBtn ${errMsg}`);
			Run.calculationBtn.click();
			browser.pause(config.app.downloadWaitTime);
			let actual = Run.calculatedResultCell.getText();
			let expected = moment().format('YYYY-MM-DD kk:');
			let hasValue = actual.includes(expected);
			if (!hasValue) {
				console.log(`formula is ${each.formula}`);
				console.log(`expected: ${expected}`);
				console.log(`actual: ${actual}`);
			}
			expect(hasValue).to.be.true;
		});
		// testProcessAndExperiment.delete(name);

	});

});