import LoginPage from '../pageobjects/login.page';
import Home from '../pageobjects/home.page';
import experimentOfProcess from '../pageobjects/create.experiment.page';
import testProcessAndExperiment from '../pageobjects/testdata.delete';
import Property from '../pageobjects/property.page';
import fileUpload from '../pageobjects/fileupload.config';
import getRandomName from '../helpers/get_random_name';
import Run from '../pageobjects/run.page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const randomName = getRandomName();
const path = require('path');
const filePath = path.join(__dirname, config.app.uploadFile);
const expectedBlankConfigText1 = 'Select or create a configuration file to help'; 
const expectedBlankConfigText2 = 'you map the data from your file to your designs' + 
	' in Riffyn.';
const expectedBlankConfigText3 = 'To create your first configuration file ' + 
	'click \'New Config\' above.';
const errMsg = 'element was not loaded';


describe('Delete Import Config', () => {

	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it('should delete the config', () => {

		experimentOfProcess.createConnectedSteps(randomName);
		browser.waitForElement(Run.fileUploadIcon, config.app.waitTime,
			`fileUploadIcon ${errMsg}`);
		fileUpload.config(filePath, 'output');
		fileUpload.delete(filePath);
		browser.pause(config.app.downloadWaitTime);
		let actualConfigText = fileUpload.firstConfigName.getText();
		expect(actualConfigText).to.includes(expectedBlankConfigText1);
		expect(actualConfigText).to.includes(expectedBlankConfigText2);
		expect(actualConfigText).to.includes(expectedBlankConfigText3);
		// testProcessAndExperiment.delete(randomName);

	});

});