import LoginPage from '../pageobjects/login.page';
import Home from '../pageobjects/home.page';
import Tag from '../pageobjects/tag.page';
import getRandomName from '../helpers/get_random_name';

const config = require('config');
const name = getRandomName();


describe('View Filter In Tag Library Test', () => {

	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it('should display tags according to their respective left panel filters', () => {

		Tag.create(name);
		Home.shareToRiffynAndPublic(name);
		browser.refresh();
		Home.searchAndAssert(name);
		Home.createdByMe.click();
		Home.searchAndAssert(name);
		// Home.sharedWithMe.click();
		// Home.searchAndAssert(sharedWithMeName);
		Home.sharedWithRiffyn.click();
		Home.searchAndAssert(name);
		Home.public.click();
		Home.searchAndAssert(name);

	});

})