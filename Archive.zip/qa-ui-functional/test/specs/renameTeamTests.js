import LoginPage from '../pageobjects/login.page';
import Home from '../pageobjects/home.page';
import getRandomName from '../helpers/get_random_name';
import waitForElement from '../helpers/wait_for_element';
import Team from '../pageobjects/team.page';
const config = require('config');
const team1 = 'Team1 ' + getRandomName();
const team2 = 'Team2 ' + getRandomName();
const test2 = 'riffyn.test.2';
const errMsg = 'element was not loaded';


describe('Rename Team Test', () => {

	it('should rename the team', () => {

		LoginPage.login(config.app.admin.username,
			config.app.admin.password);
		browser.url('library/teams');
		browser.waitForElement(Team.createTeamPlus, config.app.longerWait,
			`Create Team Plus ${errMsg}`);
		Team.create(team1, test2);
		browser.waitForElement(Home.searchInputField, config.app.waitTime,
			`Search box ${errMsg}`);
		Home.searchInputField.setValue(team1);
		browser.keys(['Enter']);
		browser.waitForElement($(`td*=${team1}`), config.app.waitTime,
			`Team1 ${errMsg}`);
		$(`td*=${team1}`).rightClick();
		browser.waitForElement(Home.rename, config.app.waitTime,
			`Rename context menu  ${errMsg}`);
		Home.rename.click();
		browser.waitForElement(Team.nameOnRename, config.app.waitTime,
			`Name input field on Rename modal ${errMsg}`);
		Team.nameOnRename.setValue(team2);
		browser.pause(config.app.waitTime);
		Home.confirm.click();
		browser.waitForVisible('.modal-overlay.library-modal',
			config.app.waitTime, true);
		browser.waitForElement(Home.clearSearch, config.app.waitTime,
			`Clear Search X button ${errMsg}`);
		Home.clearSearch.click();
		Home.searchInputField.setValue(team2);
		browser.keys(['Enter']);
		browser.waitForElement($(`td*=${team2}`), config.app.waitTime,
			`Team2 ${errMsg}`);
		$(`td*=${team2}`).doubleClick();
		browser.waitForElement(Team.teamName, config.app.waitTime,
			`Team Name label ${errMsg}`);
		expect(Team.teamName.getText()).to.equal(team2);

	});

});
