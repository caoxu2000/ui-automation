import LoginPage from '../pageobjects/login.page';
import Home from '../pageobjects/home.page';
import Process from '../pageobjects/process.page';
import deleteProcess from '../pageobjects/delete.process.page';
import getRandomName from '../helpers/get_random_name';
import Task from '../pageobjects/task.page';
import Comment from '../pageobjects/comment.page';
import waitForElement from '../helpers/wait_for_element';

const config = require('config');
const expectedText = getRandomName();
const errMsg = 'element was not loaded';


describe('Add New Task/Task Notes Test', () => {

	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it('should add a new Task note under Info tab', () => {

		Process.create(expectedText);
		browser.waitForElement(Comment.infoTab, config.app.waitTime,
			`infoTab ${errMsg}`);
		Task.addTask(expectedText);
		browser.waitForElement(Comment.secondTaskStepText, config.app.waitTime,
			`secondTaskStepText ${errMsg}`);
		let actualText = Comment.secondTaskStepText.getText();
		expect(actualText).contains(expectedText);
		Task.delete2ndTask();
		expect(Comment.secondStep.isExisting()).to.be.false;
		// deleteProcess.delete(expectedText);

	});

});