import LoginPage from '../pageobjects/login.page';
import Process from '../pageobjects/process.page';
import deleteProcess from '../pageobjects/delete.process.page';
import getRandomName from '../helpers/get_random_name';
import Note from '../pageobjects/comment.page';
import waitForElement from '../helpers/wait_for_element';

const config = require('config');
const path = require('path');
const filePath = path.join(__dirname, config.app.DesignNotesExpected);
const randomName = getRandomName();
const errMsg = 'element was not loaded';


describe('Attach file as Design Note Test', () => {

	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it('should upload the file as attachment to the Design Note', () => {

		Process.create(randomName);
		browser.waitForElement(Note.designNotesTab, config.app.waitTime,
			`Design Notes Tab ${errMsg}`);
		Note.designNotesTab.click();
		browser.waitForElement(Note.uploadClip, config.app.waitTime,
			`Upload File Clip Icon ${errMsg}`);
		Note.uploadClip.click();
		browser.pause(config.app.waitTime);
		browser.chooseFile('.add-media-files', filePath);
		browser.waitForElement(Note.mediaImage, config.app.waitTime,
			`Media Image ${errMsg}`);
		Note.saveComment.click();
		browser.pause(config.app.downloadWaitTime);
		expect(Note.mediaImage.isExisting()).to.be.true;
		// deleteProcess.delete(randomName);

	});

});