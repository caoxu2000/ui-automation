import LoginPage from '../pageobjects/login.page';
import Experiment from '../pageobjects/experiment.page';
import getRandomName from '../helpers/get_random_name';
import experimentOfProcess from '../pageobjects/create.experiment.page';
import Home from '../pageobjects/home.page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const randomName = getRandomName();
const testsuite = 'Restore Experiment from Trash Test';
const testcase = 'Should restore the Experiment back to library';
const errMsg = 'element was not loaded';


describe(testsuite, () => {

	it(testcase, () => {

		LoginPage.login(config.app.admin.username,
			config.app.admin.password);
		experimentOfProcess.create(randomName);
		Experiment.measureTopNav.click();
		browser.waitForElement(Experiment.moveToTrash,
			config.app.waitTime, `MoveToTrash Menu ${errMsg}`);
		Experiment.moveToTrash.click();
		browser.pause(config.app.waitTime);
		Experiment.confirmDeletion.click();
		browser.pause(config.app.waitTime);
		browser.url('library/experiments');
		browser.waitForExist('.layer.spinner-overlay',
			config.app.waitTime, true);
		browser.waitForElement(Experiment.trashLeftNav,
			config.app.waitTime, `Trash Menu In LeftNav ${errMsg}`);
		Experiment.trashLeftNav.click();
		browser.waitForElement(Home.searchInputField,
			config.app.waitTime, `Search input field ${errMsg}`);
		Home.searchInputField.setValue(randomName);
		browser.keys(['Enter']);
		browser.pause(config.app.waitTime);
		$(`td*=${randomName}`).rightClick();
		browser.waitForElement(Experiment.restoreContextMenu,
			config.app.waitTime, `Restore Menu ${errMsg}`);
		Experiment.restoreContextMenu.click();
		browser.pause(config.app.waitTime);
		Experiment.confirmRestoreBtn.click();
		browser.pause(config.app.waitTime);
		Experiment.allLeftNav.click();
		browser.waitForElement(Home.searchInputField,
			config.app.waitTime, `Search input field ${errMsg}`);
		Home.searchInputField.setValue(randomName);
		browser.keys(['Enter']);
		browser.pause(config.app.waitTime);
		expect($(`td*=${randomName}`).isExisting()).to.be.true;

	});

});
