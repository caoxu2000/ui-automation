import LoginPage from '../pageobjects/login.page';
import Home from '../pageobjects/home.page';
import experimentOfProcess from '../pageobjects/create.experiment.page';
import testProcessAndExperiment from '../pageobjects/testdata.delete';
import Property from '../pageobjects/property.page';
import fileUpload from '../pageobjects/fileupload.config';
import getRandomName from '../helpers/get_random_name';
import Run from '../pageobjects/run.page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const randomName = getRandomName();
const path = require('path');
const filePath = path.join(__dirname, config.app.uploadFile);
const errMsg = 'element was not loaded';


describe('Duplicate Config of File Test', () => {

	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it('should duplicate the config', () => {

		experimentOfProcess.createConnectedSteps(randomName);
		browser.waitForElement(Run.fileUploadIcon, config.app.waitTime,
			`fileUploadIcon ${errMsg}`);
		fileUpload.config(filePath, 'output');
		fileUpload.duplicate(filePath);
		browser.pause(config.app.downloadWaitTime);
		let newConfigName = fileUpload.duplicateConfigName.getText();
		expect(newConfigName).to.equals('8runs.xlsx (1)');

	});

});