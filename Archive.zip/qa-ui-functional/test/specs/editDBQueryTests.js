import LoginPage from '../pageobjects/login.page';
import experimentOfProcess from '../pageobjects/create.experiment.page';
import testProcessAndExperiment from '../pageobjects/testdata.delete';
import fileUpload from '../pageobjects/fileupload.config';
import dbUpload from '../pageobjects/dbupload.config';
import getRandomName from '../helpers/get_random_name';
import Run from '../pageobjects/run.page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const randomName = getRandomName();
const path = require('path');
const filePath = path.join(__dirname, config.app.uploadFile);
const errMsg = 'element was not loaded';
const tc = 'should update the DB query and execute with no error';


describe('Edit DB Query Test', () => {

	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it(tc, () => {

		experimentOfProcess.createConnectedSteps(randomName);
		dbUpload.requireFromDB();
		browser.waitForElement(dbUpload.addQuery, config.app.waitTime,
			`Add Query Plus ${errMsg}`);
		dbUpload.addQuery.click();
		dbUpload.clickDBUpload(randomName, 'sample_runs', 'run_name');
		dbUpload.editQuery();
		dbUpload.clickDBUpload(`test ${randomName}`, 'compression_data', 'run');
		dbUpload.executeQuery();
		dbUpload.config('runOption', 'topMaxFNewtons');
		browser.pause(config.app.downloadWaitTime);
		expect(Run.run1stProperty8thCol.getValue()).to.equal('10.65');
		// testProcessAndExperiment.delete(randomName);

	});

});