import LoginPage from '../pageobjects/login.page';
import Step from '../pageobjects/step.page';
import Process from '../pageobjects/process.page';
import deleteProcess from '../pageobjects/delete.process.page';
import waitForElement from '../helpers/wait_for_element';
import getRandomName from '../helpers/get_random_name';

const config = require('config');
const randomDesc = getRandomName();
const errMsg = 'element was not loaded';


describe('Modify Group Description Test', () => {

 	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it('should add group description', () => {

		Process.create(randomDesc);
		browser.pause(config.app.waitTime);
		Step.firstStepBox.leftClick(100, 100);
		browser.pause(config.app.waitTime);
		Process.groupDescription.click();
		Process.groupDescription.setValue(randomDesc);
		browser.pause(config.app.waitTime);
		Step.firstStepBox.click();
		browser.pause(config.app.waitTime);
		Step.firstStepBox.leftClick(100, 100);
		browser.pause(config.app.waitTime);
		expect(Process.groupDescription.getValue()).to.equal(randomDesc);
		// deleteProcess.delete(randomDesc);

	});

});