import LoginPage from '../pageobjects/login.page';
import experimentOfProcess from '../pageobjects/create.experiment.page';
import testProcessAndExperiment from '../pageobjects/testdata.delete';
import Property from '../pageobjects/property.page';
import fileUpload from '../pageobjects/fileupload.config';
import getRandomName from '../helpers/get_random_name';
import Run from '../pageobjects/run.page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const path = require('path');
const filePath = path.join(__dirname, config.app.uploadFile);
const randomName = getRandomName();
const testSuiteName = `should upload a file, config, upload 
another file and add it to new collection`;
const expectedArr = ['6.96', 'SA-1', 'SA-1'];
const errMsg = 'element was not loaded';


describe('Add to New Collection Test', () => {

	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it(testSuiteName, () => {

		experimentOfProcess.createConnectedSteps(randomName);
		browser.waitForElement(Run.fileUploadIcon, config.app.waitTime,
			`fileUploadIcon ${errMsg}`);
		fileUpload.config(filePath, 'output');
		browser.waitForElement(Run.fileUploadIcon, config.app.waitTime,
			`fileUploadIcon ${errMsg}`);
		Run.deleteTestRuns();
		fileUpload.addToNewCollection(randomName, filePath);
		fileUpload.applyNewCollection();
		let firstRunPH = Run.firstRunPH.getValue();
		let firstRunName = Run.firstRunName.getValue();
		let firstRunResource = Run.firstRunResource.getValue();
		let actualArr = [firstRunPH, firstRunName, firstRunResource];
		expect(actualArr).to.deep.equal(expectedArr);
		// testProcessAndExperiment.delete(randomName);

	});

});