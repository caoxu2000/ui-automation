import LoginPage from '../pageobjects/login.page';
import Process from '../pageobjects/process.page';
import Experiment from '../pageobjects/experiment.page';
import Step from '../pageobjects/step.page';
import getRandomName from '../helpers/get_random_name';
import testProcessAndExperiment from '../pageobjects/testdata.delete';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const testsuite = 'Require Upload Data From a DB query at Process Step level Test';
const testcase = 'Should add Database icon to the Process and its Experiments created from it';
const errMsg = 'element was not loaded';
const randomName = getRandomName();


describe(testsuite, () => {

	it(testcase, () => {

		LoginPage.login(config.app.admin.username, config.app.admin.password);
		Process.create(randomName);
		browser.switchTab(browser.getTabIds()[1]);
		Step.requireFromDBQuery();
		browser.pause(config.app.waitTime);
		browser.waitForElement(Step.dbIconOnStep,
			config.app.waitTime, `line 24 DB icon ${errMsg}`);
		expect(Step.dbIconOnStep.isExisting()).to.be.true;
		Experiment.create(randomName);
		browser.switchTab(browser.getTabIds()[2]);
		browser.waitForElement(Step.dbIconOnStep,
			config.app.waitTime, `line 29 DB icon ${errMsg}`);
		expect(Step.dbIconOnStep.isExisting()).to.be.true;
		browser.switchTab(browser.getTabIds()[1]);
		Step.unRequireFromDBQuery();
		browser.pause(config.app.waitTime);
		expect(Step.dbIconOnStep.isExisting()).to.be.false;
		Experiment.create(`${randomName} autotest`);
		browser.switchTab(browser.getTabIds()[3]);
		browser.pause(config.app.waitTime);
		expect(Step.dbIconOnStep.isExisting()).to.be.false;
		// testProcessAndExperiment.delete(randomName);

	});

});
