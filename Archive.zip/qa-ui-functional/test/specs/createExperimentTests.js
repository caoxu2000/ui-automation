import LoginPage from '../pageobjects/login.page';
import Experiment from '../pageobjects/experiment.page';
import getRandomName from '../helpers/get_random_name';
import experimentOfProcess from '../pageobjects/create.experiment.page';
import testProcessAndExperiment from '../pageobjects/testdata.delete';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const testsuite = 'Create Experiment Test';
const testcase = 'Should create a new Experiment';
const randomName = getRandomName();
const errMsg = 'element was not loaded';


describe(testsuite, () => {

	it(testcase, () => {

		LoginPage.login(config.app.admin.username, config.app.admin.password);
		experimentOfProcess.create(randomName);		
		expect(browser.getTitle()).to.equal(`E1 | ${randomName}`);
		Experiment.appTitle.click();
		browser.waitForElement(Experiment.experimentName,
			config.app.waitTime, `experimentNameInputField ${errMsg}`);
		expect(Experiment.experimentName.getValue()).to.equal(randomName);
		// testProcessAndExperiment.delete(randomName);

	});

});
