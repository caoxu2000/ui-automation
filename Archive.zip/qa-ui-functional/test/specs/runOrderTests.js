import LoginPage from '../pageobjects/login.page';
import Process from '../pageobjects/process.page';
import Experiment from '../pageobjects/experiment.page';
import Step from '../pageobjects/step.page';
import Run from '../pageobjects/run.page';
import getRandomName from '../helpers/get_random_name';
import waitForElement from '../helpers/wait_for_element';

const config = require('config');
const testName = 'Order tab in Run table Test';
const randomName = getRandomName();
const errMsg = 'element was not loaded';


describe(testName, () => {

	before(() => {

		LoginPage.login(config.app.admin.username, config.app.admin.password);

	});

	it('should generate the step order correctly under Order tab', () => {

		Process.create(randomName);
		browser.switchTab(browser.getTabIds()[1]);
		Step.addStepAfter1st();
		Step.activeStepActivityLabel.waitForEnabled();
		Step.activeStepActivityLabel.doubleClick();
		Step.activeStepActivityLabel.setValue('2nd Step');
		Step.addStepAfter2nd(); // this is the 3rd Step
		Step.activeStepActivityLabel.waitForEnabled();
		Step.activeStepActivityLabel.doubleClick();
		Step.activeStepActivityLabel.setValue('3rd Step');
		Step.addStepAfter1st(); // this is the 4th Step
		Step.activeStepActivityLabel.waitForEnabled();
		Step.activeStepActivityLabel.doubleClick();
		Step.activeStepActivityLabel.setValue('4th Step');
		Step.addStepAfter3rd(); // this is the 5th Step
		Step.activeStepActivityLabel.waitForEnabled();
		Step.activeStepActivityLabel.doubleClick();
		Step.activeStepActivityLabel.setValue('5th Step');
    Experiment.create(randomName);
    browser.switchTab(browser.getTabIds()[2]);
    browser.waitForElement(Run.uploadIcon, config.app.waitTime,
			`File Upload Icon at bottom toolbar ${errMsg}`);
    Run.order.click();
    browser.waitForElement(Run.permanentID[4], config.app.waitTime,
			`5th Permanent ID Column cell ${errMsg}`);
    let id = '';
		for (let i = 0; i < Run.permanentID.length; i++) {
			id += Run.permanentID[i].getText() ;
		}
		let num = '';
		for (let i = 0; i < Run.orderNumBubble.length; i++) {
			num += Run.orderNumBubble[i].getText() ;
		}
		let name = '';
		for (let i = 0; i < Run.stepOrderName.length; i++) {
			name += Run.stepOrderName[i].getText() ;
		}
    expect(num).to.equal('12345');
    expect(name).to.equal('First Step2nd Step3rd Step4th Step5th Step');
    expect(id).to.equal('S1S2S3S4S5');

	});

});