import LoginPage from '../pageobjects/login.page';
import getRandomName from '../helpers/get_random_name';
import Home from '../pageobjects/home.page';
import ResourceType from '../pageobjects/resourcetype.page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const name1 = getRandomName();
const name2 = getRandomName();
const errMsg = 'element was not loaded';
const testProperty1 = 'pH';
const testProperty2 = 'volume';
const testComponent = 'water';


describe('Edit Resource Type Test', () => {

	it('should update resource type with new name and property', () => {

		LoginPage.login(config.app.admin.username, config.app.admin.password);
		ResourceType.create(name1, testProperty1, testComponent);
		Home.searchInputField.setValue(name1);
		browser.keys(['Enter']);
		browser.pause(config.app.waitTime);
		browser.waitForElement($(`td*=${name1}`),
			config.app.waitTime, `resource type row ${name1} ${errMsg}`);
		$(`td*=${name1}`).doubleClick();
		browser.waitForElement(ResourceType.resourceTypeNameInput,
			config.app.waitTime, `resourceTypeNameInput ${errMsg}`);
		ResourceType.resourceTypeNameInput.setValue(name2);
		browser.waitForElement(ResourceType.removePropertyDropdown,
			config.app.waitTime, `Remove Property Dropdown ${errMsg}`);
		ResourceType.removePropertyDropdown.click();
		browser.waitForElement(ResourceType.removePropertyContextMenu,
			config.app.waitTime, `Remove Property Context Menu ${errMsg}`);
		ResourceType.removePropertyContextMenu.click();
		ResourceType.addPropertyToResource(testProperty2);
		browser.pause(config.app.waitTime);
		ResourceType.save.click();
		Home.clearSearch.click();
		Home.searchInputField.setValue(name2);
		browser.keys(['Enter']);
		browser.pause(config.app.waitTime);
		browser.waitForElement($(`td*=${name2}`),
			config.app.waitTime, `resource type row ${name2} ${errMsg}`);
		$(`td*=${name2}`).doubleClick();
		browser.waitForElement(ResourceType.componentContainerElmt,
			config.app.waitTime, `Water Component ${errMsg}`);
		expect(ResourceType.resourceTypeNameInput.getValue()).to.equal(name2);
		expect(ResourceType.propertyContainerElmt.getText()).to.equal(testProperty2);
		expect(ResourceType.componentContainerElmt.getText()).to.equal(testComponent);
		browser.pause(config.app.waitTime);
		Home.closeModal.click();
		browser.pause(config.app.waitTime);
		$(`td*=${name2}`).rightClick();
		Home.deleteTestRow(name2);

	});

});
