import LoginPage from '../pageobjects/login.page';
import Resource from '../pageobjects/resource.page';
import Property from '../pageobjects/property.page';
import Run from '../pageobjects/run.page';
import experimentOfProcess from '../pageobjects/create.experiment.page';
import waitForElement from '../helpers/wait_for_element';
import getRandomName from '../helpers/get_random_name';
const config = require('config');
const propertyName = 'volume';
const resourceName = 'salt';
const randomName = getRandomName();
const errMsg = 'element was not loaded';
const testName = 'should add a new property to ' +
	'existing resource type and a new resource type to the output of first step';
let actualResourceTypes = '';
let actualProperties = '';


describe('Ad Hoc Process Changes in Experiment Test', () => {

 	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it(testName, () => {

		experimentOfProcess.createConnectedSteps(randomName);
		browser.waitForElement(Run.modifyRun, config.app.waitTime,
			`Bottom Panel Modify Menu ${errMsg}`);
		Run.modifyRun.click();
		browser.pause(config.app.waitTime);
		Property.addPropertyToOutput(propertyName);
		browser.pause(config.app.waitTime);
		Property.cancelPropertyCreate.click();
		Resource.addOutput.click();
		Resource.addResource(resourceName);
		browser.pause(config.app.waitTime);
		Run.actualRun.click();
		browser.pause(config.app.waitTime);
		actualResourceTypes = Run.resourcesInRunTable[0].getText() +
			Run.resourcesInRunTable[1].getText() + Run.resourcesInRunTable[2].getText();
		actualProperties = Run.propertiesInRunTable[0].getText() + Run.propertiesInRunTable[1].getText();
		expect(actualResourceTypes).to.equal('UnassignedWaterSalt');
		expect(actualProperties).to.equal('pHvolume');

	});

});