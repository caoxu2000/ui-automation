import LoginPage from '../pageobjects/login.page';
import getRandomName from '../helpers/get_random_name';
import Home from '../pageobjects/home.page';
import ResourceInventory from '../pageobjects/resource.inventory.page';
import Resource from '../pageobjects/resource.page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const randomName = getRandomName();
const errMsg = 'element was not loaded';
const testCaseLabel = 'should remove the resource in ' + 
	'riffyn.test.2\'s Resource Inventory library';


describe('Remove a Resource From My Resource Inventory Library Test', () => {

	it(testCaseLabel, () => {

		LoginPage.login(config.app.admin.username, config.app.admin.password);
		Resource.create(randomName);
		ResourceInventory.findResource.setValue(randomName);
		browser.keys(['Enter']);
		browser.waitForElement($(`td*=${randomName}`),
			config.app.waitTime, `resource row ${errMsg}`);
		$(`td*=${randomName}`).rightClick();
		browser.waitForElement(Home.share,
			config.app.waitTime, `Share Context Menu ${errMsg}`);
		Home.share.click();
		browser.waitForElement(Home.inactiveTab,
			config.app.waitTime, `Collaborator Tab which is inactive ${errMsg}`);
		Home.inactiveTab.click();
		Home.removeCollaborator();
		Home.inactiveTab.click();
		browser.waitForElement(Home.searchUserBox,
			config.app.waitTime, `Search User Box ${errMsg}`);
		Home.searchUserBox.setValue('riffyn.test.2');
		browser.waitForElement(Home.selectFirstUser,
			config.app.waitTime, `First User In Search Results ${errMsg}`);
		Home.selectFirstUser.click();
		browser.waitForElement(Home.userRoleDropDown,
			config.app.waitTime, `User Role DropDown ${errMsg}`);
		Home.userRoleDropDown.selectByValue('viewer');
		browser.waitForElement(Home.shareBtn,
			config.app.waitTime, `Share Button ${errMsg}`);
		Home.shareBtn.click();
		browser.pause(config.app.waitTime);
		Home.confirm.click();
		browser.pause(config.app.waitTime);

		LoginPage.logout();
		LoginPage.login(config.app.test2.username,
			config.app.test2.password);
		Home.openLeftNav.click();
		browser.waitForElement(ResourceInventory.resourceInventoryLibraryLink,
			config.app.waitTime, `Resource Inventory Library in left nav ${errMsg}`);
		ResourceInventory.resourceInventoryLibraryLink.click();
		browser.waitForElement(ResourceInventory.findResource,
			config.app.waitTime, `Find Resource Search Input Field ${errMsg}`);
		ResourceInventory.findResource.setValue(randomName);
		browser.keys(['Enter']);
		browser.waitForElement($(`td*=${randomName}`),
			config.app.waitTime, `resource row ${errMsg}`);
		$(`td*=${randomName}`).rightClick();
		browser.waitForElement(Home.removeFromMyLibrary,
			config.app.waitTime, `Remove From My Library Menu ${errMsg}`);
		Home.removeFromMyLibrary.click();
		browser.waitForElement(Home.confirm,
			config.app.waitTime, `Remove Resource Confirm Button ${errMsg}`);
		Home.confirm.click();
		browser.pause(config.app.waitTime);
    expect($(`td*=${randomName}`).isExisting()).to.be.false;
    expect(Home.noSearchResults.isExisting()).to.be.true;
    expect(Home.noSearchResults.getText()).to.equal('No search results found.');

	});

});
