import LoginPage from '../pageobjects/login.page';
import getRandomName from '../helpers/get_random_name';
import Home from '../pageobjects/home.page';
import Unit from '../pageobjects/unit.page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const errMsg = 'element was not loaded';
const name1 = getRandomName();
const name2 = getRandomName();


describe('Edit Units Test', () => {

	it('should update the unit name', () => {

		LoginPage.login(config.app.admin.username, config.app.admin.password);
		Unit.create(name1);
		Home.searchInputField.setValue(name1);
		browser.keys(['Enter']);
		browser.pause(config.app.waitTime);
		$(`td*=${name1}`).doubleClick();
		browser.waitForElement(Unit.unitName,
			config.app.waitTime, `Unit Name Input 1st ${errMsg}`);
		Unit.unitName.setValue(name2);
		browser.pause(config.app.waitTime);
		Home.confirm.click();
		browser.pause(config.app.waitTime);
		Home.clearSearch.click();
		Home.searchInputField.setValue(name2);
		browser.keys(['Enter']);
		browser.pause(config.app.waitTime);
		$(`td*=${name2}`).doubleClick();
		browser.waitForElement(Unit.unitName,
			config.app.waitTime, `Unit Name Input 2nd ${errMsg}`);
		expect(Unit.unitName.getValue()).to.equal(name2);
		browser.waitForElement(Home.confirm,
			config.app.waitTime, `Update button ${errMsg}`);
		Home.confirm.click();
		browser.pause(config.app.waitTime);
		$(`td*=${name2}`).rightClick();
		browser.pause(config.app.waitTime);
		Home.deleteTestRow(name2);

	});

});
