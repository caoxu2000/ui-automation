import LoginPage from '../pageobjects/login.page';
import Step from '../pageobjects/step.page';
import getRandomName from '../helpers/get_random_name';
import Process from '../pageobjects/process.page';
import deleteProcess from '../pageobjects/delete.process.page';
import waitForElement from '../helpers/wait_for_element';

const config = require('config');
const randomName = getRandomName();
const errMsg = 'element was not loaded';


describe('Duplicate Step Test', () => {

	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it('should duplicate the step in Process Flow Chart', () => {

		Process.create(randomName);
		browser.waitForElement(Step.firstStepBox, config.app.waitTime,
			`firstStepBox ${errMsg}`);
		Step.firstStepBox.rightClick();
		Step.duplicateMenu.click();
		browser.pause(config.app.waitTime);
		let isDupStepCreated = Step.firstStepCopy.isExisting();
		expect(isDupStepCreated).to.be.true;
		// deleteProcess.delete(randomName);

	});

});