import LoginPage from '../pageobjects/login.page';
import Step from '../pageobjects/step.page';
import Process from '../pageobjects/process.page';
import waitForElement from '../helpers/wait_for_element';
import getRandomName from '../helpers/get_random_name';

const config = require('config');
const name = getRandomName();
const errMsg = 'element was not loaded';


describe('Link Process Test', () => {

 	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it('should create a step with link to the current process', () => {

		Process.create(name);
		browser.pause(config.app.waitTime);
		Step.firstStepBox.rightClick(200, 200);
		browser.waitForElement(Step.linkExistingProcessMenu,
			config.app.waitTime, `Link Existing Process Context Menu ${errMsg}`);
		Step.linkExistingProcessMenu.click();
		browser.pause(config.app.waitTime);
		browser.waitForElement(Step.firstProcessCheckbox,
			config.app.waitTime, `Checkbox left to 1st Process ${errMsg}`);
		Step.firstProcessCheckbox.click();
		browser.pause(config.app.waitTime);
		Step.confirmation.click();
		browser.pause(config.app.waitTime);
		expect(Step.linkedProcessEntity.isExisting()).to.be.true;

	});

});