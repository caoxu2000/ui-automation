import LoginPage from '../pageobjects/login.page';
import experimentOfProcess from '../pageobjects/create.experiment.page';
import testProcessAndExperiment from '../pageobjects/testdata.delete';
import Property from '../pageobjects/property.page';
import fileUpload from '../pageobjects/fileupload.config';
import getRandomName from '../helpers/get_random_name';
import Run from '../pageobjects/run.page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const path = require('path');
const filePath = path.join(__dirname, config.app.uploadFile);
const randomName = getRandomName();
const testSuiteName = 'should upload a file, config, upload ' + 
'another file and add it to new collection';
const errMsg = 'element was not loaded';


describe('Delete a Collection Test', () => {

	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it(testSuiteName, () => {

		experimentOfProcess.createConnectedSteps(randomName);
		// browser.pause(config.app.waitTime);
		// Run.modifyRun.click();
		// Property.addPropertyToOutput('pH');
		// browser.pause(config.app.waitTime);
		// Run.actualRun.click();
		// browser.pause(config.app.downloadWaitTime);
		browser.waitForElement(Run.fileUploadIcon, config.app.waitTime,
			`fileUploadIcon ${errMsg}`);
		fileUpload.config(filePath, 'output');
		browser.waitForElement(Run.fileUploadIcon, config.app.waitTime,
			`fileUploadIcon ${errMsg}`);
		Run.deleteTestRuns();
		fileUpload.addToNewCollection(randomName, filePath);
		fileUpload.deleteTestCollection(filePath);
		expect(fileUpload.collectionRow.isExisting()).to.be.false;
		expect(fileUpload.emptyAreaContainer.isExisting()).to.be.true;
		// testProcessAndExperiment.delete(randomName);

	});

});