import LoginPage from '../pageobjects/login.page';
import getRandomName from '../helpers/get_random_name';
import Home from '../pageobjects/home.page';
import ResourceType from '../pageobjects/resourcetype.page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const name1 = getRandomName();
const name2 = getRandomName();
const errMsg = 'element was not loaded';
const testProperty = 'pH';
const testComponent = 'WATER';


describe('Duplicate Resource Type Test', () => {

	it('should duplicate the existing resource type', () => {

		LoginPage.login(config.app.admin.username, config.app.admin.password);
		ResourceType.create(name1, testProperty, testComponent);
		Home.searchInputField.setValue(name1);
		browser.keys(['Enter']);
		browser.pause(config.app.waitTime);
		browser.waitForElement($(`td*=${name1}`),
			config.app.waitTime, `resource type row ${name1} ${errMsg}`);
		$(`td*=${name1}`).rightClick();
		browser.waitForElement(Home.duplicate,
			config.app.waitTime, `Duplicate in Context menu ${errMsg}`);
		Home.duplicate.click();
		browser.waitForElement(ResourceType.resourceTypeNameUpdateInput,
			config.app.waitTime, `Water Component ${errMsg}`);
		ResourceType.resourceTypeNameUpdateInput.setValue(name2);
		Home.duplicateConfirmButton.click();
		Home.clearSearch.click();
		Home.searchInputField.setValue(name2);
		browser.keys(['Enter']);
		browser.waitForElement($(`td*=${name2}`),
			config.app.waitTime, `Duplicated Resource Type Row ${errMsg}`);
		$(`td*=${name2}`).doubleClick();
		browser.waitForElement(ResourceType.resourceTypeNameInput,
			config.app.waitTime, `Resource Type Name Input ${errMsg}`);
		expect(ResourceType.resourceTypeNameInput.getValue()).to.equal(name2);
		browser.pause(config.app.waitTime);
		Home.closeModal.click();
		browser.pause(config.app.waitTime);
		$(`td*=${name2}`).rightClick();
		Home.deleteTestRow(name2);

	});

});
