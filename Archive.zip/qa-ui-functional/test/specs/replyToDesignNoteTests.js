import LoginPage from '../pageobjects/login.page';
import Note from '../pageobjects/comment.page';
import Process from '../pageobjects/process.page';
import deleteProcess from '../pageobjects/delete.process.page';
import getRandomName from '../helpers/get_random_name';
import addNote from '../pageobjects/add.note.page';
import waitForElement from '../helpers/wait_for_element';

const config = require('config');
const expectedNote = getRandomName();
const errMsg = 'element was not loaded';


describe('Reply to Design Note Test', () => {

	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it('should add a new note below the existing original notes', () => {

		Process.create(expectedNote);
		browser.waitForElement(Note.sideBar, config.app.waitTime,
			`SideBar ${errMsg}`);
		addNote.add('Original Design Note');
		browser.waitForElement(Note.replyToComment, config.app.waitTime,
			`Reply To Comment Icon ${errMsg}`);
		Note.replyToComment.click();
		browser.waitForElement(Note.replyToArea, config.app.waitTime,
			`ReplyTo Input Area ${errMsg}`);
		Note.replyToArea.setValue(expectedNote);
		browser.waitForElement(Note.saveReplyToComment, config.app.waitTime,
			`Save ReplyTo Comment Button ${errMsg}`);
		Note.saveReplyToComment.click();
		browser.pause(config.app.waitTime);
		let actualNote = Note.replyToCommentView.getText();
		expect(actualNote).equals(expectedNote);
		// deleteProcess.delete(expectedNote);

	});

});