import LoginPage from '../pageobjects/login.page';
import Home from '../pageobjects/home.page';
import getRandomName from '../helpers/get_random_name';
import waitForElement from '../helpers/wait_for_element';
import Team from '../pageobjects/team.page';
const config = require('config');
const team1 = 'Team ' + getRandomName();
const test2 = 'riffyn.test.2';
const errMsg = 'element was not loaded';
const testCase = 'should delete the newly created team';


describe('Delete Team Test', () => {

	it(testCase, () => {

		LoginPage.login(config.app.admin.username,
			config.app.admin.password);
		browser.url('library/teams');
		browser.waitForElement(Team.createTeamPlus, config.app.longerWait,
			`Create Team Plus ${errMsg}`);
		Team.create(team1, test2);
		browser.waitForElement(Home.searchInputField, config.app.waitTime,
			`Search box ${errMsg}`);
		Home.searchInputField.setValue(team1);
		browser.keys(['Enter']);
		browser.waitForElement($(`td*=${team1}`), config.app.waitTime,
			`Newly Created Team ${errMsg}`);
		$(`td*=${team1}`).rightClick();
		browser.waitForElement(Home.delete, config.app.waitTime,
			`Delete Context Menu  ${errMsg}`);
		Home.delete.click();
		browser.waitForElement(Home.confirm, config.app.waitTime,
			`Confirm Button in popup ${errMsg}`);
		Home.confirm.click();
		browser.pause(config.app.waitTime);
		expect($(`td*=${team1}`).isExisting()).to.be.false;
    expect(Home.noSearchResults.isExisting()).to.be.true;
    expect(Home.noSearchResults.getText()).to.equal('No search results found.');

	});

});
