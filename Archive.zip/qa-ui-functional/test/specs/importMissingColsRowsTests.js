import LoginPage from '../pageobjects/login.page';
import experimentOfProcess from '../pageobjects/create.experiment.page';
import testProcessAndExperiment from '../pageobjects/testdata.delete';
import fileUpload from '../pageobjects/fileupload.config';
import getRandomName from '../helpers/get_random_name';
import Run from '../pageobjects/run.page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const randomName = getRandomName();
const path = require('path');
const filePath = path.join(__dirname, config.app.missingColumnRow);
const errMsg = 'element was not loaded';


describe('Import File with empty columns, rows, and extra header rows Test', () => {

	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it('should import the file correctly with no error', () => {

		experimentOfProcess.createConnectedSteps(randomName);
		browser.waitForElement(Run.fileUploadIcon, config.app.waitTime,
			`fileUploadIcon ${errMsg}`);
		fileUpload.configMissingCells(filePath);
		browser.pause(config.app.downloadWaitTime);
		let eleventhRunName = Run.run11thRunName.getValue();
		let eleventhInputResource = Run.run11thInputsUnassignedResource.getValue();
		let eleventhRunPH = Run.run11thProperty8thCol.getValue();
		expect(eleventhRunName).to.equal('7.0');
		expect(eleventhInputResource).to.equal('7.0');
		expect(eleventhRunPH).to.equal('10.6873');

	});

});