import LoginPage from '../pageobjects/login.page';
import Experiment from '../pageobjects/experiment.page';
import getRandomName from '../helpers/get_random_name';
import experimentOfProcess from '../pageobjects/create.experiment.page';
import testProcessAndExperiment from '../pageobjects/testdata.delete';
import waitForElement from '../helpers/wait_for_element';

const config = require('config');
const testName = 'duplicate test';
const randomName = getRandomName();
const errMsg = 'element was not loaded';


describe('Duplicate Experiment test', () => {

	it('should duplicate the Experiment', () => {

		LoginPage.login(config.app.admin.username,
			config.app.admin.password);
		experimentOfProcess.create(randomName);
		browser.waitForElement(Experiment.measureTopNav,
			config.app.downloadWaitTime, `Measure Upperleft Menu ${errMsg}`);
		Experiment.measureTopNav.click();
		browser.waitForElement(Experiment.duplicateExperimentLink,
			config.app.downloadWaitTime, `Duplicate Experiment Link ${errMsg}`);
		Experiment.duplicateExperimentLink.click();
		browser.pause(config.app.waitTime);
		browser.waitForElement(Experiment.exptName,
			config.app.downloadWaitTime, 'exptName');
		Experiment.exptName.setValue(`duplicate ${randomName}`);
		Experiment.confirmButton.click();
		browser.pause(config.app.downloadWaitTime);
		Experiment.appTitle.click();
		browser.waitForElement(Experiment.experimentName,
			config.app.downloadWaitTime, `Experiment Name Input Field ${errMsg}`);
		expect(Experiment.experimentName.getValue()).to.equal(`duplicate ${randomName}`);
		// testProcessAndExperiment.delete(randomName);

	});
});
