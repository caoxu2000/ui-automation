import LoginPage from '../pageobjects/login.page';
import Comment from '../pageobjects/comment.page';
import Task from '../pageobjects/task.page';
import waitForElement from '../helpers/wait_for_element';
import Process from '../pageobjects/process.page';
import deleteProcess from '../pageobjects/delete.process.page';
import getRandomName from '../helpers/get_random_name';
const config = require('config');
const path = require('path');
const filePath = path.join(__dirname, config.app.TasksExpected);
const randomName = getRandomName();
const errMsg = 'element was not loaded';


describe('Delete file attachment of a Task/Task Test', () => {

	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it('should delete the attached file of the Task/Task', () => {

		Process.create(randomName);
		browser.waitForElement(Comment.addTaskBtn, config.app.waitTime,
			`addTaskButton ${errMsg}`);
		Task.addTask('Static Text for Task Note');
		Comment.taskMain.doubleClick();
		browser.waitForElement(Comment.uploadButton, config.app.waitTime,
			`uploadButton ${errMsg}`);
		browser.chooseFile('.procedure-step.edit .add-media-files', filePath);
		browser.waitForElement(Comment.mediaImage, config.app.waitTime,
			`mediaImage ${errMsg}`);
		expect(Comment.mediaImage.isExisting()).to.be.true;
		browser.pause(config.app.downloadWaitTime);
		Comment.updateButton.click();
		browser.pause(config.app.downloadWaitTime);
		Task.removeMedia();
		browser.pause(config.app.downloadWaitTime);
		expect(Comment.mediaImage.isExisting()).to.be.false;
		// deleteProcess.delete(randomName);

	});

});