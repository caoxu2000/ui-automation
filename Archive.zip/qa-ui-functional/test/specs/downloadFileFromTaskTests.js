import LoginPage from '../pageobjects/login.page';
import Home from '../pageobjects/home.page';
import Process from '../pageobjects/process.page';
import deleteProcess from '../pageobjects/delete.process.page';
import getRandomName from '../helpers/get_random_name';
import Task from '../pageobjects/task.page';
import Comment from '../pageobjects/comment.page';
import waitForElement from '../helpers/wait_for_element';

const fs = require('fs-extra');
const config = require('config');
const path = require('path');
const expectedText = getRandomName();
const errMsg = 'element was not loaded';
const expected = path.join(__dirname, config.app.TasksExpected);
const actual = path.join(__dirname, config.app.TasksActual);


describe('Upload File to Task Notes Test', () => {

	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it('should attach a file to task/procedure', () => {

		Process.create(expectedText);
		browser.waitForElement(Comment.addTaskBtn, config.app.waitTime,
			`Add Task Button ${errMsg}`);
		Comment.taskMain.doubleClick();
		browser.waitForElement(Comment.uploadButton, config.app.waitTime,
			`Upload File Icon ${errMsg}`);
		browser.chooseFile('.add-media-files', expected);
		browser.waitForElement(Comment.mediaImage, config.app.waitTime,
			`mediaImage ${errMsg}`);
		expect(Comment.mediaImage.isExisting()).to.be.true;
		browser.pause(config.app.waitTime);
		Comment.updateTaskButton.click();
		browser.pause(config.app.waitTime);
		Task.downloadMedia();
		
		let match = null;
		let expectedFile = fs.readFileSync(expected);
    let actualFile = fs.readFileSync(actual);
    match = expectedFile.toString('binary') === actualFile.toString('binary');
    console.log(`Expected image ${expected}`);
    console.log(`Actual image ${actual}`);
    expect(match).to.be.true;
    fs.removeSync(actual);

	});

});