import LoginPage from '../pageobjects/login.page';
import Property from '../pageobjects/property.page';
import Process from '../pageobjects/process.page';
import deleteProcess from '../pageobjects/delete.process.page';
import getRandomName from '../helpers/get_random_name';
import Step from '../pageobjects/step.page';
import Resource from '../pageobjects/resource.page';
import waitForElement from '../helpers/wait_for_element';

const config = require('config');
const propertyName = 'pH';
const testProcessName = getRandomName();
const errMsg = 'element was not loaded';


describe('Propagate a Property to Downstream Step Test', () => {

 	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it('should add property to the downstream next step default resource type', () => {

		Process.create(testProcessName);
		Step.addStepAfter1st();
		browser.waitForElement(Step.firstStepBox, config.app.waitTime,
			`First Step Box ${errMsg}`);
		Step.firstStepBox.click();
		browser.pause(config.app.waitTime);
		Property.addPropertyToOutput(propertyName);
		browser.pause(config.app.waitTime);
		Property.propagateFirstProperty();
		browser.pause(config.app.waitTime);
		Step.nextStepBox.click();
		browser.pause(config.app.waitTime);
		expect(Resource.propertyName.getText()).to.equal('pH');
		let propertyCounter = 
			browser.selectorExecute('.resource-input-summary div.property-name',
				(properties) => {
					return properties.length;
				});
		expect(propertyCounter).to.equal(1);
		// deleteProcess.delete(testProcessName);

	});

});