import LoginPage from '../pageobjects/login.page';
import Note from '../pageobjects/comment.page';
import Process from '../pageobjects/process.page';
import deleteProcess from '../pageobjects/delete.process.page';
import getRandomName from '../helpers/get_random_name';
import addNote from '../pageobjects/add.note.page';
import waitForElement from '../helpers/wait_for_element';

const config = require('config');
const expectedNote = getRandomName();
const errMsg = 'element was not loaded';


describe('Edit Existing Design Note Test', () => {

	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it('should update the design notes with the new content', () => {

		Process.create(expectedNote);
		browser.waitForElement(Note.sideBar, config.app.waitTime,
			`sideBar ${errMsg}`);
		addNote.add('Original Design Notes');
		browser.waitForElement(Note.editComment, config.app.waitTime,
			`Edit Comment Icon ${errMsg}`);
		Note.editComment.click();
		browser.waitForElement(Note.editCommentArea, config.app.waitTime,
			`Edit Comment Input Area ${errMsg}`);
		Note.editCommentArea.setValue(expectedNote);
		browser.pause(config.app.waitTime);
		Note.updateComment.click();
		browser.pause(config.app.waitTime);
		let actualnote = Note.firstCommentView.getText();
		expect(actualnote).equals(expectedNote);
		// deleteProcess.delete(expectedNote);

	});

});