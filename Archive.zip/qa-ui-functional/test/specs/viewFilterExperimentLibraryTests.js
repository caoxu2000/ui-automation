import LoginPage from '../pageobjects/login.page';
import Home from '../pageobjects/home.page';
import experimentOfProcess from '../pageobjects/create.experiment.page';
import MainMenu from '../pageobjects/main.menu.page';
import Experiment from '../pageobjects/experiment.page';
import waitForElement from '../helpers/wait_for_element';
import getRandomName from '../helpers/get_random_name';
const randomName = getRandomName();
const config = require('config');
const errMsg = 'element was not loaded';
const oneStep8x1000 = '4 - One step 8x1000 uploaded cleaned';
const runWithBlankProperty = '3x1 run - 3x1 run with blank property';
const twoConnectedStepsFilledDown = '2- Two connected steps filled down';
const cleanAndJoin = '4 - Clean & Join';


describe('View Filter In Experiment Library Test', () => {

	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it('should display experiments in their respective left panel filters', () => {

		browser.url('library/experiments');
		Home.searchAndAssert(oneStep8x1000);
		Home.createdByMe.click();
		Home.searchAndAssert(runWithBlankProperty);
		Home.sharedWithMe.click();
		Home.searchAndAssert(twoConnectedStepsFilledDown);
		Home.public.click();
		Home.searchAndAssert(cleanAndJoin);
		browser.url('library/processes');
		experimentOfProcess.create(randomName);
		browser.waitForElement(MainMenu.dropdown, config.app.waitTime,
			`Design Upper Left Menu ${errMsg}`);
		MainMenu.dropdown.click();
		browser.waitForElement(Experiment.moveToTrash, config.app.waitTime,
			`Move To Trash Menu Item ${errMsg}`);
		Experiment.moveToTrash.click();
		browser.pause(config.app.waitTime);
		browser.waitForElement(Experiment.confirmDeletion, config.app.waitTime,
			`Confirm button ${errMsg}`);
		Experiment.confirmDeletion.click();
		browser.pause(config.app.waitTime);
		browser.url('library/experiments');
		browser.pause(config.app.longerWait);
		browser.waitForExist('.layer.spinner-overlay',
			config.app.waitTime, true);
		browser.waitForElement(Home.trash, config.app.waitTime,
			`Trash link on left nav ${errMsg}`);
		Home.trash.click();
		Home.searchAndAssert(randomName);

	});

})