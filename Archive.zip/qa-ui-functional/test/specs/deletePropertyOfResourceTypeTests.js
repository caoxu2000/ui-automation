import LoginPage from '../pageobjects/login.page';
import Property from '../pageobjects/property.page';
import Resource from '../pageobjects/resource.page';
import Process from '../pageobjects/process.page';
import deleteProcess from '../pageobjects/delete.process.page';
import getRandomName from '../helpers/get_random_name';
const config = require('config');
const propertyName = 'pH';
const randomName = getRandomName();


describe('Delete a property under a Resource Type Test', () => {

 	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it('should delete the property under the resource type', () => {

		Process.create(randomName);
		Property.addPropertyToOutput(propertyName);
		browser.pause(config.app.waitTime);
		Property.deleteFirstProperty();
		browser.pause(config.app.waitTime);
		expect(Resource.propertyName.isExisting()).to.be.false;
		// deleteProcess.delete(randomName);

	});

});