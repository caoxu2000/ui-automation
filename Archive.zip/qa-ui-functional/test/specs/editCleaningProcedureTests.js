import LoginPage from '../pageobjects/login.page';
import Run from '../pageobjects/run.page';
import createRun from '../pageobjects/create.run.page';
import experimentOfProcess from '../pageobjects/create.experiment.page';
import getRandomName from '../helpers/get_random_name';
import getRandomNum from '../helpers/get_random_num';
import waitForElement from '../helpers/wait_for_element';

const config = require('config');
const testName = 'Edit Cleaning Procedure Test';
const randomName = getRandomName();
const randomNumber = getRandomNum();
const errMsg = 'element was not loaded';


describe(testName, () => {

	it('should update cleaning procedure and apply to a run', () => {

		LoginPage.login(config.app.admin.username, config.app.admin.password);
		experimentOfProcess.createConnectedSteps(randomName);
		createRun.create1RunAtATime(randomName);
		Run.run1stProperty8thCol.click();
		browser.pause(config.app.waitTime);
		Run.run1stProperty8thCol.setValue(1);
		browser.pause(config.app.waitTime);
		Run.run1stProperty8thCol.click();
		browser.pause(config.app.waitTime);
		Run.run1stProperty8thCol.rightClick();
		browser.waitForElement(Run.editDataContextMenu, config.app.waitTime,
			`Edit Data Context Menu Option ${errMsg}`);
		Run.editDataContextMenu.click();
		browser.pause(config.app.waitTime);
		Run.addDataRowButton.click();
		browser.pause(config.app.waitTime);
		Run.editMultiValuedTD.click();
		browser.keys(['2']);
		browser.pause(config.app.waitTime);
		Run.addDataRowButton.click();
		browser.pause(config.app.waitTime);
		Run.editMultiValuedTD.click();
		browser.keys(['3']);
		browser.pause(config.app.waitTime);
		Run.addDataRowButton.click();
		browser.pause(config.app.waitTime);
		Run.editMultiValuedTD.click();
		browser.keys(['4']);
		browser.pause(config.app.waitTime);
		Run.addDataRowButton.click();
		browser.pause(config.app.waitTime);
		Run.editMultiValuedTD.click();
		browser.keys(['5']);
		browser.pause(config.app.waitTime);
		Run.addDataRowButton.click();
		browser.pause(config.app.waitTime);
		Run.editMultiValuedTD.click();
		browser.keys(['6']);
		browser.pause(config.app.waitTime);
		Run.saveAllEdits.click();
		browser.pause(config.app.downloadWaitTime);
		Run.createNewCleaningProcedure(randomName);
		Run.closeCleaningProcedureModal.click();
		Run.editAppliedProcedure();
		let val = '';
		for (let i = 0; i <= 4; i++) {
			val += Run.cleaningRule8thCol[i].getText() ;
		}
		console.log(val);
		expect(val == '66633' || val == '33366').to.be.true;

	});
});
