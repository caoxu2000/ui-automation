import LoginPage from '../pageobjects/login.page';
import Process from '../pageobjects/process.page';
import deleteProcess from '../pageobjects/delete.process.page';
import getRandomName from '../helpers/get_random_name';
import addNote from '../pageobjects/add.note.page';
import Note from '../pageobjects/comment.page';
import waitForElement from '../helpers/wait_for_element';

const config = require('config');
const expectedNote = getRandomName();
const errMsg = 'element was not loaded';


describe('Add Design Notes to a Step Test', () => {

	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it('should add text as design notes to the step in Process', () => {

		Process.create(expectedNote);
		browser.switchTab(browser.getTabIds()[1]);
		browser.waitForElement(Note.sideBar, config.app.waitTime,
			`sideBar ${errMsg}`);
		addNote.add(expectedNote);
		browser.waitForElement(Note.firstCommentView, config.app.waitTime,
			`firstNoteView ${errMsg}`);
		expect(Note.firstCommentView.getText()).equals(expectedNote);
		expect(Note.contentAuthor.getText()).to.equals('posted by: riffyn.test.1');
		browser.pause(config.app.waitTime);
		// deleteProcess.delete(expectedNote);

	});

});