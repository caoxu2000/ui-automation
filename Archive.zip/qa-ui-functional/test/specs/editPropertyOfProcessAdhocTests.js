import LoginPage from '../pageobjects/login.page';
import Property from '../pageobjects/property.page';
import Process from '../pageobjects/process.page';
import deleteProcess from '../pageobjects/delete.process.page';
import getRandomName from '../helpers/get_random_name';
import Resource from '../pageobjects/resource.page';

const config = require('config');
const propertyName = 'pH';
const randomName1 = getRandomName();
const randomName2 = getRandomName();


describe('Edit a Property of a Process Test', () => {

 	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it('should update/change property name of the Process', () => {

		Property.create(randomName1);
		browser.url('library/processes');
		Process.create(randomName1);
		Property.addPropertyToOutputForCustomizedProp(randomName1);
		Property.editPropertyToOutput(randomName2);
		expect(Property.propName.getText()).to.equal(randomName2);
		// deleteProcess.delete(randomName1);

	});

});