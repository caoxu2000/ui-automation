import LoginPage from '../pageobjects/login.page';
import getRandomName from '../helpers/get_random_name';
import Home from '../pageobjects/home.page';
import Unit from '../pageobjects/unit.page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const randomName = getRandomName();
const errMsg = 'element was not loaded';


describe('Create Units Test', () => {

	it('should create a new unit in library', () => {

		LoginPage.login(config.app.admin.username, config.app.admin.password);
		Unit.create(randomName);
		Home.searchInputField.setValue(randomName);
		browser.keys(['Enter']);
		browser.pause(config.app.waitTime);
		$(`td*=${randomName}`).rightClick();
		browser.waitForElement(Home.open,
			config.app.waitTime, `open menu ${errMsg}`);
		Home.open.click();
		browser.pause(config.app.waitTime);
		expect(Unit.unitName.getValue()).to.equal(randomName);
		expect(Unit.symbol.getValue()).to.equal(randomName);
		expect(Unit.definition.getValue()).to.equal(randomName);
		Home.closeModal.click();
		browser.pause(config.app.waitTime);
		$(`td*=${randomName}`).rightClick();
		browser.pause(config.app.waitTime);
		Home.deleteTestRow(randomName);

	});

});
