import LoginPage from '../pageobjects/login.page';
import getRandomName from '../helpers/get_random_name';
import Home from '../pageobjects/home.page';
import Property from '../pageobjects/property.page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const randomName = getRandomName();
const errMsg = 'element was not loaded';


describe('Create Property Test', () => {

	it('should create a new property in property library', () => {

		LoginPage.login(config.app.admin.username, config.app.admin.password);
		Property.create(randomName);
		Home.searchInputField.setValue(randomName);
		browser.keys(['Enter']);
		browser.pause(config.app.waitTime);
		browser.waitForElement($(`td*=${randomName}`),
			config.app.waitTime, `Newly Created Property Row ${errMsg}`);
		$(`td*=${randomName}`).doubleClick();
		browser.waitForElement(Property.propertyNameInput,
			config.app.waitTime, `Property Name Input field ${errMsg}`);
		expect(Property.propertyNameInput.getValue()).to.equal(randomName);
		browser.waitForElement(Property.permitted1stUnit,
			config.app.waitTime, `The degree unit entry ${errMsg}`);
		expect(Property.permitted1stUnit.getText()).to.equal('degree');
		Property.cancelPropertyButton.click();
		browser.pause(config.app.waitTime);
		$(`td*=${randomName}`).rightClick();
		browser.pause(config.app.waitTime);
		Home.deleteTestRow(randomName);

	});

});
