import LoginPage from '../pageobjects/login.page';
import Run from '../pageobjects/run.page';
import createRun from '../pageobjects/create.run.page';
import experimentOfProcess from '../pageobjects/create.experiment.page';
import getRandomName from '../helpers/get_random_name';
import getRandomNum from '../helpers/get_random_num';
import waitForElement from '../helpers/wait_for_element';

const config = require('config');
const testName = 'View Cleaning Procedure Test';
const randomName = getRandomName();
const randomNumber = getRandomNum();
const errMsg = 'element was not loaded';


describe(testName, () => {

	it('should be able to view what was saved for cleaning procedure', () => {

		LoginPage.login(config.app.admin.username, config.app.admin.password);
		experimentOfProcess.createConnectedSteps(randomName);
		createRun.create1RunAtATime(randomName);
		Run.addMultiValueRuns();
		Run.createNewCleaningProcedure(randomName);
		Run.viewAppliedProcedure();
		let val = '';
		for (let i = 0; i <= 2; i++) {
			val += Run.cleaningMethod[i].getText() ;
		}
		console.log(val);
		expect(val).to.equal('K-means ClusteringK2');

	});
});
