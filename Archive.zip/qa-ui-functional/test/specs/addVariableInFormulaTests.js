import LoginPage from '../pageobjects/login.page';
import Experiment from '../pageobjects/experiment.page';
import getRandomName from '../helpers/get_random_name';
import Run from '../pageobjects/run.page';
import experimentOfProcess from '../pageobjects/create.experiment.page';
import Property from '../pageobjects/property.page';
import CreateRun from '../pageobjects/create.run.page';
import waitForElement from '../helpers/wait_for_element';


const config = require('config');
const name = getRandomName();
const propertyName = 'pH';
const errMsg = 'element was not loaded';


describe('Add Variable In Formula Editor Test', () => {

	before(() => {

		const propertySelector = Run.property;
		LoginPage.login(config.app.admin.username, config.app.admin.password);
		experimentOfProcess.create(name);
		CreateRun.create1RunAtATime(name);
		Run.modifyRun.click();
		Property.addPropertyToOutput(propertyName);

	});

	it('should add a variable entry in formula', () => {

		Run.actualRun.click();

		browser.waitForElement(Experiment.runTableRow(1, 2), config.app.waitTime,
			`Run Table Row Run Name TD ${errMsg}`);
		Run.numericResource.rightClick();
		browser.waitForElement(Run.formulaEditor, config.app.waitTime,
			`formulaEditor ${errMsg}`);
		Run.formulaEditor.click();
		browser.pause(config.app.waitTime);
		browser.waitForElement(Run.addVariable, config.app.waitTime,
			`Add Variable + ${errMsg}`);
		Run.addVariable.click();
		browser.pause(config.app.waitTime);
		expect(Run.variableNameDivEntry.isExisting()).to.be.true;

	});

});