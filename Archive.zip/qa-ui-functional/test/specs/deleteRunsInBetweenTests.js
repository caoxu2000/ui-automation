import LoginPage from '../pageobjects/login.page';
import getRandomName from '../helpers/get_random_name';
import Run from '../pageobjects/run.page';
import Step from '../pageobjects/step.page';
import CreateRun from '../pageobjects/create.run.page';
import experimentOfProcess from '../pageobjects/create.experiment.page';
import waitForElement from '../helpers/wait_for_element';
import testProcessAndExperiment from '../pageobjects/testdata.delete';
const config = require('config');
const randomName = getRandomName();
const errMsg = 'element was not loaded';


describe('Delete Runs In Between Test', () => {

	before(() => {

		LoginPage.login(config.app.admin.username, config.app.admin.password);

	});

	it('should delete S1R1, S2R1, S3R1, S4R1, keep S2R2 and S5R1', () => {

		experimentOfProcess.create5ConnectedSteps(randomName);
		browser.waitForElement(Run.createNewRunInput,
			config.app.waitTime, `create Run Input Field ${errMsg}`);
		CreateRun.create1RunAtATime(randomName);
		Run.anchorOf3rdStep.click();
		browser.waitForElement(Run.firstStepFirstRunLabel,
			config.app.waitTime, `First Step First Run checkbox ${errMsg}`);
		Run.firstStepFirstRunLabel.click();
		browser.waitForElement(Run.connectionActionBtn,
			config.app.waitTime, `The GO button to connect runs ${errMsg}`);
		Run.connectionActionBtn.click();
		browser.pause(config.app.waitTime);
		Run.nextStepFirstRunLabel.click();
		browser.pause(config.app.waitTime);
		Run.viaDropdown.click();
		browser.pause(config.app.waitTime);
		Run.via4thStep.click();
		browser.waitForElement(Run.connectionActionBtn,
			config.app.waitTime, `The GO button to connect runs ${errMsg}`);
		Run.connectionActionBtn.click();
		browser.pause(config.app.waitTime);
		Run.anchorOf2ndStep.click();
		browser.waitForElement(Run.connectionActionBtn,
			config.app.waitTime, `The GO button to connect runs ${errMsg}`);
		Run.connectionActionBtn.click();
		browser.pause(config.app.waitTime);
		Step.thirdStepBox.click();
		browser.pause(config.app.waitTime);
		Run.anchorOf5thStep.click();
		browser.waitForElement(Run.firstStepFirstRunLabel,
			config.app.waitTime, `First Step First Run checkbox ${errMsg}`);
		Run.firstStepFirstRunLabel.click();
		browser.waitForElement(Run.connectionActionBtn,
			config.app.waitTime, `The GO button to connect runs ${errMsg}`);
		Run.connectionActionBtn.click();
		browser.pause(config.app.waitTime);
		Step.firstStepBox.click();
		browser.pause(config.app.waitTime);
		Run.anchorOf3rdStep.click();
		browser.pause(config.app.waitTime);
		Run.firstStepFirstRunLabel.click();
		browser.pause(config.app.waitTime);
		Run.nextStepFirstRunLabel.click();
		browser.pause(config.app.waitTime);
		Run.deleteRunsIcon.click();
		browser.pause(config.app.waitTime);
		Run.confirmation.click();
		browser.pause(config.app.waitTime);
		Step.firstStepBox.click();
		browser.pause(config.app.waitTime);
		expect(Run.firstRunRows.isExisting()).to.be.false;
		Step.secondStepBox.click();
		browser.pause(config.app.waitTime);
		expect(Run.firstRunRows.isExisting()).to.be.true;
		Step.thirdStepBox.click();
		browser.pause(config.app.waitTime);
		expect(Run.firstRunRows.isExisting()).to.be.false;
		Step.fourthStepBox.click();
		browser.pause(config.app.waitTime);
		expect(Run.firstRunRows.isExisting()).to.be.false;
		Step.fifthStepBox.click();
		browser.pause(config.app.waitTime);
		expect(Run.firstRunRows.isExisting()).to.be.true;
		// testProcessAndExperiment.delete(randomName);

	});

});