import LoginPage from '../pageobjects/login.page';
import getRandomName from '../helpers/get_random_name';
import Home from '../pageobjects/home.page';
import ResourceInventory from '../pageobjects/resource.inventory.page';
import Resource from '../pageobjects/resource.page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const randomName = getRandomName();
const errMsg = 'element was not loaded';


describe('Create Resource Test', () => {

	it('should create a new Resource and can be searched in Resource library', () => {

		LoginPage.login(config.app.admin.username,
			config.app.admin.password);
		Resource.create(randomName);
		ResourceInventory.findResource.setValue(randomName);
		browser.keys(['Enter']);
		browser.waitForElement($(`td*=${randomName}`),
			config.app.waitTime, `resource row ${errMsg}`);
		$(`td*=${randomName}`).rightClick();
		browser.waitForElement(Home.open,
			config.app.waitTime, `open menu ${errMsg}`);
		Home.open.click();
		browser.pause(config.app.waitTime);
		expect(ResourceInventory.resourceName.getValue()).to.equal(randomName);
		expect(ResourceInventory.resourceType.getText()).to.equal('air compressor');
		Home.closeModal.click();
		browser.pause(config.app.waitTime);
		$(`td*=${randomName}`).rightClick();
		browser.pause(config.app.waitTime);
		Home.deleteTestRow(randomName);

	});

});
