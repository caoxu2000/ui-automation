import LoginPage from '../pageobjects/login.page';
import Home from '../pageobjects/home.page';
import experimentOfProcess from '../pageobjects/create.experiment.page';
import testProcessAndExperiment from '../pageobjects/testdata.delete';
import Experiment from '../pageobjects/experiment.page';
import ContextMenu from '../pageobjects/context.menu.page';
import getRandomName from '../helpers/get_random_name';
import waitForElement from '../helpers/wait_for_element';

const config = require('config');
const randomName = getRandomName();
const errMsg = 'element was not loaded';
const noResults = 'No search results found.';


describe('Add/remove tag of an experiment test', function() {

	it('should add the tag only to the selected experiment', function() {

		LoginPage.login(config.app.admin.username, config.app.admin.password);
		experimentOfProcess.create(randomName);
		browser.waitForElement(Experiment.logo,
			config.app.waitTime, `Riffyn logo ${errMsg}`);
		Experiment.logo.click();
		browser.waitForElement($(`td*=${randomName}`),
			config.app.waitTime, randomName);
		$(`td*=${randomName}`).rightClick();
		browser.waitForElement(ContextMenu.addOrRemove,
			config.app.waitTime, `addOrRemoveMenu ${errMsg}`);
		ContextMenu.addOrRemove.click();
		browser.keys(['Clear']);
		browser.waitForElement(ContextMenu.tagName,
			config.app.waitTime, `tagNameInputField ${errMsg}`);
		ContextMenu.tagName.setValue(randomName);
		browser.keys(['Enter']);
		browser.pause(config.app.waitTime);
		ContextMenu.tagUpdateBtn.click();
		browser.pause(config.app.waitTime);
		expect(ContextMenu.tagPill.isExisting()).to.be.true;
		ContextMenu.tagPill.click();
		browser.pause(config.app.waitTime);
		let itemCounter1 = browser.selectorExecute('.library-table-row', (item) => {
			return item.length;
		});
		expect(itemCounter1).to.equal(1);
		Experiment.firstExperimentInLibrary.rightClick();
		browser.waitForElement(ContextMenu.addOrRemove,
			config.app.waitTime, `addOrRemoveMenu ${errMsg}`);
		ContextMenu.addOrRemove.click();
		browser.pause(config.app.waitTime);
		ContextMenu.removeTag.click();
		browser.pause(config.app.waitTime);
		ContextMenu.tagUpdateBtn.click();
		browser.pause(config.app.waitTime);
		let itemCounter2 = browser.selectorExecute('.library-table-empty-row', (item) => {
			return item.length;
		});
		expect(itemCounter2).to.equal(1);
		expect(Home.libraryEmptyRow.getText()).to.equals(noResults);
		expect(ContextMenu.tagPill.isExisting()).to.be.false;
		// testProcessAndExperiment.delete(randomName);

	});

});
