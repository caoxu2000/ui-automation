import LoginPage from '../pageobjects/login.page';
import Home from '../pageobjects/home.page';
import Unit from '../pageobjects/unit.page';
import getRandomName from '../helpers/get_random_name';

const config = require('config');
const name = getRandomName();
const transmittance = '% transmittance';


describe('View Filter In Unit Library Test', () => {

	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it('should display units according to their respective left panel filters', () => {

		Unit.create(name);
		Home.searchAndAssert(name);
		Home.createdByMe.click();
		Home.searchAndAssert(name);
		// Home.sharedWithMe.click();
		// Home.searchAndAssert(test);
		Home.sharedWithRiffyn.click();
		Home.searchAndAssert(name);
		Home.public.click();
		Home.searchAndAssert(transmittance);

	});

})