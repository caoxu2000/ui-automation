import LoginPage from '../pageobjects/login.page';
import Experiment from '../pageobjects/experiment.page';
import CreateRun from '../pageobjects/create.run.page';
import getRandomName from '../helpers/get_random_name';
import experimentOfProcess from '../pageobjects/create.experiment.page';
import testProcessAndExperiment from '../pageobjects/testdata.delete';
import waitForElement from '../helpers/wait_for_element';

const config = require('config');
const testName = 'Create Run Test';
const randomName = getRandomName();


describe(testName, () => {

	before(() => {

		LoginPage.login(config.app.admin.username, config.app.admin.password);
		experimentOfProcess.create(randomName);

	});

	it('should create a new run under the actual tab', () => {

		CreateRun.createMultipleRuns(randomName, '2');
		browser.pause(config.app.downloadWaitTime);
		expect(Experiment.runTableRow(2, 2).isExisting()).to.be.true;
		// testProcessAndExperiment.delete(randomName);

	});

});