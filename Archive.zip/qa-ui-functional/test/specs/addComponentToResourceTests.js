import LoginPage from '../pageobjects/login.page';
import crudComponent from '../pageobjects/crud.component.resource';
import Resource from '../pageobjects/resource.page';
import Process from '../pageobjects/process.page';
import deleteProcess from '../pageobjects/delete.process.page';
import waitForElement from '../helpers/wait_for_element';
import getRandomName from '../helpers/get_random_name';
const config = require('config');
const componentName = 'hydron';
const randomName = getRandomName();
const errMsg = 'element was not loaded';


describe('Add Component to Resource Test', () => {

 	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it('should add component to resource in bottom panel', () => {

		Process.create(randomName);
		browser.waitForElement(Resource.outputResourceNameUnassigned,
			config.app.waitTime, `outputResourceNameUnassigned ${errMsg}`);
		crudComponent.add(componentName);
		expect(Resource.componentName.getText()).to.equal(componentName.toUpperCase());
		// deleteProcess.delete(randomName);

	});

});