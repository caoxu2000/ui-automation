import LoginPage from '../pageobjects/login.page';
import Step from '../pageobjects/step.page';
import Process from '../pageobjects/process.page';
import deleteProcess from '../pageobjects/delete.process.page';
import VersionsTab from '../pageobjects/versions.tab.page';
import getRandomName from '../helpers/get_random_name';
import waitForElement from '../helpers/wait_for_element';

const config = require('config');
const randomDesc = getRandomName();
const errMsg = 'element was not loaded';


describe('Create New Version Test', function() {

	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it('should create a new version with new version number 1.00', function() {

		Process.create(randomDesc);
		browser.waitForElement(Step.addNewStepLnk, config.app.waitTime,
			`addNewStepLink ${errMsg}`);
		Step.addNewStepLnk.click();
		browser.pause(config.app.waitTime);
		VersionsTab.versionsTabLnk.click();
		browser.waitForElement(VersionsTab.createNewVersion, config.app.waitTime,
			`createNewVersionLink ${errMsg}`);
		VersionsTab.createNewVersion.click();
		browser.waitForElement(VersionsTab.versionDescription, config.app.waitTime,
			`versionDescriptionInputField ${errMsg}`);
		VersionsTab.versionDescription.setValue(randomDesc);
		browser.pause(config.app.waitTime);
		VersionsTab.createVersionBtn.click();
		browser.pause(config.app.waitTime);
		let newVersionNumber = VersionsTab.version100Lnk.getText();
		let newVersionDescription =  VersionsTab.actualVersionDesc.getText();
		expect(newVersionNumber).to.equal('1.00');
		expect(newVersionDescription).to.equal(randomDesc);
		// deleteProcess.delete(randomDesc);

	});

});