import LoginPage from '../pageobjects/login.page';
import crudComponent from '../pageobjects/crud.component.resource';
import Resource from '../pageobjects/resource.page';
import Process from '../pageobjects/process.page';
import deleteProcess from '../pageobjects/delete.process.page';
import getRandomName from '../helpers/get_random_name';
const config = require('config');
const componentName = 'dressing';
const randomName = getRandomName();


describe('Delete Component off of a Resource Type Test', () => {

 	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it('should delete component off of a resource type', () => {

		Process.create(randomName);
		crudComponent.add(componentName);
		crudComponent.delete();
		expect(Resource.inputSecondResource.isExisting()).to.be.false;
		// deleteProcess.delete(randomName);

	});

});