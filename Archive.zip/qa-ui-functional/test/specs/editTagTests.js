import LoginPage from '../pageobjects/login.page';
import getRandomName from '../helpers/get_random_name';
import Home from '../pageobjects/home.page';
import Tag from '../pageobjects/tag.page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const name1 = getRandomName();
const name2 = getRandomName();
const errMsg = 'element was not loaded';


describe('Edit Tag Test', () => {

	it('should update the tag with a new name', () => {

		LoginPage.login(config.app.admin.username,
			config.app.admin.password);
		Tag.create(name1);
		Home.searchInputField.setValue(name1);
		browser.keys(['Enter']);
		browser.pause(config.app.waitTime);
		$(`td*=${name1}`).doubleClick();
		browser.waitForElement(Tag.tagName,
			config.app.waitTime, `Tag Name Input Field 1st ${errMsg}`);
		Tag.tagName.setValue(name2);
		browser.pause(config.app.waitTime);
		Home.confirm.click();
		browser.pause(config.app.waitTime);
		Home.clearSearch.click();
		Home.searchInputField.setValue(name2);
		browser.keys(['Enter']);
		browser.pause(config.app.waitTime);
		$(`td*=${name2}`).doubleClick();
		browser.waitForElement(Tag.tagName,
			config.app.waitTime, `Tag Name Input Field 2nd ${errMsg}`);
		expect(Tag.tagName.getValue()).to.equal(name2);
		browser.waitForElement(Home.confirm,
			config.app.waitTime, `Update button ${errMsg}`);
		Home.confirm.click();
		browser.pause(config.app.waitTime);
		$(`td*=${name2}`).rightClick();
		browser.pause(config.app.waitTime);
		Home.deleteTestRow(name2);

	});

});
