import LoginPage from '../pageobjects/login.page';
import Home from '../pageobjects/home.page';
import Process from '../pageobjects/process.page';
import getRandomName from '../helpers/get_random_name';
import deleteProcess from '../pageobjects/delete.process.page';
import waitForElement from '../helpers/wait_for_element';

const config = require('config');
const randomName1 = getRandomName();
const randomName2 = getRandomName();
const errMsg = 'element was not loaded';


describe('Update process name test', () => {

	it('should update the process name', () => {

		LoginPage.login(config.app.admin.username,
			config.app.admin.password);
		Process.create(randomName1);
		Home.appTitleText.click();
		browser.waitForElement(Process.processName,
			config.app.waitTime, `Process Name Input Field ${errMsg}`);
		Process.processName.setValue(randomName2);
		browser.pause(config.app.waitTime);
		Process.updateProcessBtn.click();
		browser.pause(config.app.waitTime);
		expect(Home.appTitleText.getText()).to.equal(randomName2);
		// deleteProcess.delete(randomName2);

	});

});
