import LoginPage from '../pageobjects/login.page';
import Comment from '../pageobjects/comment.page';
import experimentOfProcess from '../pageobjects/create.experiment.page';
import testProcessAndExperiment from '../pageobjects/testdata.delete';
import getRandomName from '../helpers/get_random_name';
import waitForElement from '../helpers/wait_for_element';

const config = require('config');
const path = require('path');
const filePath = path.join(__dirname, config.app.ObservationsExpected);
const randomName = getRandomName();
const errMsg = 'element was not loaded';


describe('Upload file as Observation file attachment Test', () => {

	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it('should upload the file as attachment to the Observation', () => {

		experimentOfProcess.create(randomName);
		browser.waitForElement(Comment.observationsTab, config.app.waitTime,
			`Observations Tab ${errMsg}`);
		Comment.observationsTab.click();
		browser.waitForElement(Comment.uploadClip, config.app.waitTime,
			`Upload File Clipper Icon ${errMsg}`);
		Comment.uploadClip.click();
		browser.pause(config.app.waitTime);
		browser.chooseFile('.add-media-files', filePath);
		browser.waitForElement(Comment.mediaImage, config.app.waitTime,
			`Media Image ${errMsg}`);
		Comment.saveComment.click();
		browser.pause(config.app.downloadWaitTime);
		expect(Comment.mediaImage.isExisting()).to.be.true;
		// testProcessAndExperiment.delete(randomName);

	});

});