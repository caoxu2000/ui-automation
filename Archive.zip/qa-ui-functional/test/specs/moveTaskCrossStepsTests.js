import LoginPage from '../pageobjects/login.page';
import getRandomName from '../helpers/get_random_name';
import Task from '../pageobjects/task.page';
import Step from '../pageobjects/step.page';
import Comment from '../pageobjects/comment.page';
import waitForElement from '../helpers/wait_for_element';
import Process from '../pageobjects/process.page';
const randomName = getRandomName();
const config = require('config');
const errMsg = 'element was not loaded';


describe('Move Task cross all steps in a Process Test', () => {

	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it('should move the task to the last across all steps in the process', () => {

		Process.create(randomName);
		Step.addStepAfter1st();
		Step.firstStepBox.click();
		browser.waitForElement(Comment.infoTab, config.app.waitTime,
			`Info Tab ${errMsg}`);
		Task.addTask(`2nd Task with dynamic text ${randomName}`);
		Task.addTask('3rd Task with Static Text');
		Task.make2ndTaskLast();
		browser.pause(config.app.waitTime);
		let thirdTaskText = Comment.thirdTaskText.getText();
		let thirdTaskOrderText = Comment.thirdTaskOrder.getText();
		expect(thirdTaskText).to.equal(`2nd Task with dynamic text ${randomName}`);
		expect(thirdTaskOrderText).equals('4.');

	});

});