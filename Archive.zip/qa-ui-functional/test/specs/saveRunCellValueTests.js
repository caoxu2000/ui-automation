import LoginPage from '../pageobjects/login.page';
import Run from '../pageobjects/run.page';
import experimentOfProcess from '../pageobjects/create.experiment.page';
import ResourceToolbar from '../pageobjects/resource.toolbar.page';
import getRandomName from '../helpers/get_random_name';
import getRandomNum from '../helpers/get_random_num';
import waitForElement from '../helpers/wait_for_element';

const config = require('config');
const testName = 'Save Cell Value in Run Table';
const randomName = getRandomName();
const randomNumber = getRandomNum();
const errMsg = 'element was not loaded';


describe(testName, () => {

	it('should save the cell value after tabbed out or refresh whole page', () => {

		LoginPage.login(config.app.admin.username, config.app.admin.password);
		experimentOfProcess.createConnectedSteps(randomName);
		browser.waitForElement(ResourceToolbar.createNewRunPlus,
			config.app.waitTime, `CreateNewRunPlus Icon ${errMsg}`);
		ResourceToolbar.createNewRunPlus.click();
		browser.waitForElement(ResourceToolbar.runCounter,
			config.app.waitTime, `RunCounter ${errMsg}`);
		ResourceToolbar.runCounter.setValue('5');
		browser.waitForElement(ResourceToolbar.createRunBtn,
			config.app.waitTime, `Create Run Button ${errMsg}`);
		ResourceToolbar.createRunBtn.click();
		browser.pause(config.app.downloadWaitTime);
		browser.waitForElement(Run.run1stProperty8thCol,
			config.app.downloadWaitTime, `1st Run pH input cell ${errMsg}`);
		Run.run1stProperty8thCol.click();
		Run.run1stProperty8thCol.setValue(randomNumber);
		browser.pause(config.app.downloadWaitTime);
		browser.keys(['ArrowDown']);
		browser.pause(config.app.downloadWaitTime);
		expect(Run.run1stProperty8thCol.getValue()).to.equal(randomNumber.toString());
		browser.refresh();
		browser.waitForElement(Run.run1stProperty8thCol,
			config.app.downloadWaitTime, `1st Run Property Column Cell ${errMsg}`);
		expect(Run.run1stProperty8thCol.getValue()).to.equal(randomNumber.toString());

	});

});
