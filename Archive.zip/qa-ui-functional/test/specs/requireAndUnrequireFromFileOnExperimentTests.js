import LoginPage from '../pageobjects/login.page';
import Process from '../pageobjects/process.page';
import Experiment from '../pageobjects/experiment.page';
import Step from '../pageobjects/step.page';
import getRandomName from '../helpers/get_random_name';
import testProcessAndExperiment from '../pageobjects/testdata.delete';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const testsuite = 'Require Upload Data From File at Process Step level Test';
const testcase = 'Should add File icon to Process and all its Experiments created from it';
const errMsg = 'element was not loaded';
const randomName = getRandomName();


describe(testsuite, () => {

	it(testcase, () => {

		LoginPage.login(config.app.admin.username, config.app.admin.password);
		Process.create(randomName);
		browser.switchTab(browser.getTabIds()[1]);
		Experiment.create(randomName);
		browser.switchTab(browser.getTabIds()[2]);
		Step.requireFromFile();
		browser.pause(config.app.waitTime);
		Step.confirmation.click();
		browser.pause(config.app.waitTime);
		browser.waitForElement(Step.fileIconOnStep,
			config.app.waitTime, `File Upload icon ${errMsg} on line 28`);
		expect(Step.fileIconOnStep.isExisting()).to.be.true;
		browser.switchTab(browser.getTabIds()[1]);
		browser.waitForElement(Step.fileIconOnStep,
			config.app.waitTime, `File Upload icon ${errMsg} on line 32`);
		expect(Step.fileIconOnStep.isExisting()).to.be.true;
		browser.switchTab(browser.getTabIds()[2]);
		Step.unrequireFromFile();
		browser.pause(config.app.waitTime);
		Step.confirmation.click();
		browser.pause(config.app.waitTime);
		expect(Step.fileIconOnStep.isExisting()).to.be.false;
		browser.switchTab(browser.getTabIds()[1]);
		browser.pause(config.app.waitTime);
		expect(Step.fileIconOnStep.isExisting()).to.be.false;
		// testProcessAndExperiment.delete(randomName);

	});

});
