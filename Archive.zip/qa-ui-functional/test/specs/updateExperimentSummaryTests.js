import LoginPage from '../pageobjects/login.page';
import Experiment from '../pageobjects/experiment.page';
import experimentOfProcess from '../pageobjects/create.experiment.page';
import deleteProcess from '../pageobjects/delete.process.page';
import getRandomName from '../helpers/get_random_name';
import waitForElement from '../helpers/wait_for_element';
const expectedSummary = `This is test from automation ${randomName}`;
const config = require('config');
const randomName = getRandomName();
const errMsg = 'element was not loaded';


describe('Update Experiment Summary Test', () => {

	it('should add summary to experiment', () => {

		LoginPage.login(config.app.admin.username,
			config.app.admin.password);
		experimentOfProcess.create(randomName);
		browser.waitForElement(Experiment.summaryLink,
			config.app.waitTime, `Summary Link Top Center ${errMsg}`);
		Experiment.summaryLink.click();
		browser.waitForElement(Experiment.summaryInputField,
			config.app.waitTime, `Summary Input Field ${errMsg}`);
		Experiment.summaryInputField.setValue(expectedSummary);
		browser.pause(config.app.waitTime);
		Experiment.summaryUpdateBtn.click();
		browser.waitForElement(Experiment.summaryLink,
			config.app.waitTime, `Summary Link Top Center ${errMsg}`);
		Experiment.summaryLink.click();
		browser.pause(config.app.waitTime);
		let summary = Experiment.summaryInputField.getText();
		expect(summary).equals(expectedSummary);
		// deleteProcess.delete(randomName);

	});

});