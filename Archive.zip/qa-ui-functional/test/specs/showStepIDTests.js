import LoginPage from '../pageobjects/login.page';
import Step from '../pageobjects/step.page';
import waitForElement from '../helpers/wait_for_element';
import Process from '../pageobjects/process.page';
import deleteProcess from '../pageobjects/delete.process.page';
import getRandomName from '../helpers/get_random_name';
const randomName = getRandomName();
const config = require('config');
const errMsg = 'element was not loaded';


describe('Show Step ID Test', () => {

 	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it('should display Step ID in upper left corner of the step box', () => {

		Process.create(randomName);
		browser.waitForElement(Step.outputResourceToolbar,
			config.app.waitTime, `Output Resource Toolbar ${errMsg}`);
		Step.firstStepBox.rightClick();
		Step.showStepID.click();
		browser.waitForElement(Step.stepLabel, config.app.waitTime,
			`Step ID Circle on Upper Left Corner ${errMsg}`);
		expect(Step.stepLabel.getText()).to.equal('S1');
		// deleteProcess.delete(randomName);

	});

});