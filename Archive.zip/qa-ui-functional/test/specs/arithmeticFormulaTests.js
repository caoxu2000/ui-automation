import LoginPage from '../pageobjects/login.page';
import Experiment from '../pageobjects/experiment.page';
import ResourceToolbar from '../pageobjects/resource.toolbar.page';
import getRandomName from '../helpers/get_random_name';
import Run from '../pageobjects/run.page';
import experimentOfProcess from '../pageobjects/create.experiment.page';
import testProcessAndExperiment from '../pageobjects/testdata.delete';
import Property from '../pageobjects/property.page';
import CreateRun from '../pageobjects/create.run.page';
import waitForElement from '../helpers/wait_for_element';

const config = require('config');
const expected_num = require(config.app.numeric);
const testName = 'arithmetic test';
const name = getRandomName();
const propertyName = 'pH';
const errMsg = 'element was not loaded';


describe('Arithmetic Manipulation Test', () => {

	before(() => {

		const propertySelector = Run.property;
		LoginPage.login(config.app.admin.username, config.app.admin.password);
		experimentOfProcess.create(name);
		CreateRun.create1RunAtATime(name);
		Run.modifyRun.click();
		Property.addPropertyToOutput(propertyName);

	});

	it('should perform mathmatic calculation correctly', () => {

		Run.actualRun.click();

		browser.waitForElement(Experiment.runTableRow(1, 2), config.app.waitTime,
			`Run Name Column ${errMsg}`);
		// test resource column that is numeric data type
		expected_num.forEach(each => {

			browser.pause(750);
			Run.numericResource.rightClick();
			browser.waitForElement(Run.formulaEditor, config.app.waitTime,
				`formulaEditor ${errMsg}`);
			Run.formulaEditor.click();
			browser.waitForElement(Run.formulaInput, config.app.waitTime,
				`formulaInput ${errMsg}`);
			Run.formulaInput.setValue(each.formula);
			browser.pause(1000);
			Run.updateFormulaBtn.click();
			browser.waitForElement(Run.calculationBtn, config.app.waitTime,
				`calculationBtn ${errMsg}`);
			Run.calculationBtn.click();
			browser.waitForElement(Run.calculatedResultCell, config.app.waitTime,
				`calculatedResultCell ${errMsg}`);
			browser.pause(750); // the text takes time to show up in the td cell, that's why have to wait explicitly
			let actual = Run.calculatedResultCell.getText();
			let hasValue = each.expected.indexOf(actual) !== -1;
			if (!hasValue) {
				console.log(`formula is ${each.formula}`);
				console.log(`expected: ${each.expected}`);
				console.log(`actual: ${actual}`);
			}
			expect(hasValue).to.be.true;
		});
		// testProcessAndExperiment.delete(name);

	});

});