import LoginPage from '../pageobjects/login.page';
import Home from '../pageobjects/home.page';
import User from '../pageobjects/user.page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const suspendedUser = 'riffyn.test.3';
const errMsg = 'element was not loaded';
const suspendError = 'User is not assigned to the client application.';

describe('Suspend User Test', () => {

	it('test3 should not be able to login with error message', () => {

		LoginPage.login(config.app.admin.username, config.app.admin.password);
		browser.url('library/users');
		browser.waitForElement(Home.searchInputField,
			config.app.waitTime, `Search input ${errMsg}`);
		Home.searchInputField.setValue(suspendedUser);
		browser.keys(['Enter']);
		browser.pause(config.app.waitTime);
		$(`td*=${suspendedUser}`).rightClick();
		browser.waitForElement(User.suspend,
			config.app.waitTime, `Suspend menu ${errMsg}`);
		User.suspend.click();
		browser.waitForElement(Home.confirm,
			config.app.waitTime, `Suspend Confirm button ${errMsg}`);
		Home.confirm.click();
		browser.pause(config.app.waitTime);
		LoginPage.logout();
		LoginPage.login(config.app.test3.username, config.app.test3.password);
		browser.waitForElement(LoginPage.userSuspendError,
			config.app.waitTime, `User Suspend Error ${errMsg}`);
		expect(LoginPage.userSuspendError.getText()).to.equal(suspendError);
		LoginPage.login(config.app.admin.username, config.app.admin.password);
		browser.url('library/users');
		browser.waitForElement(Home.searchInputField,
			config.app.waitTime, `Search input ${errMsg}`);
		Home.searchInputField.setValue(suspendedUser);
		browser.keys(['Enter']);
		browser.pause(config.app.waitTime);
		$(`td*=${suspendedUser}`).rightClick();
		browser.waitForElement(User.enable,
			config.app.waitTime, `Enable menu ${errMsg}`);
		User.enable.click();
		browser.waitForElement(Home.confirm,
			config.app.waitTime, `Enable Confirm button ${errMsg}`);
		Home.confirm.click();
		browser.pause(config.app.waitTime);
		LoginPage.logout();
		LoginPage.login(config.app.test3.username, config.app.test3.password);
		browser.waitForElement(Home.loginUserName,
			config.app.waitTime, `Login User Upper Right Corner ${errMsg}`);
		expect(Home.loginUserName.getText()).to.equal('RIFFYN TEST 3');

	});

});
