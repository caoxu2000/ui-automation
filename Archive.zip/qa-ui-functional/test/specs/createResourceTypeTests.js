import LoginPage from '../pageobjects/login.page';
import getRandomName from '../helpers/get_random_name';
import Home from '../pageobjects/home.page';
import ResourceType from '../pageobjects/resourcetype.page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const randomName = getRandomName();
const errMsg = 'element was not loaded';
const testProperty = 'pH';
const testComponent = 'water';


describe('Create Resource Type Test', () => {

	it('should create a new resource type in library', () => {

		LoginPage.login(config.app.admin.username, config.app.admin.password);
		ResourceType.create(randomName, testProperty, testComponent);
		Home.searchInputField.setValue(randomName);
		browser.keys(['Enter']);
		browser.pause(config.app.waitTime);
		browser.waitForElement($(`td*=${randomName}`),
			config.app.waitTime, `resource type row ${randomName} ${errMsg}`);
		$(`td*=${randomName}`).doubleClick();
		browser.waitForElement(ResourceType.componentContainerElmt,
			config.app.waitTime, `Water Component ${errMsg}`);
		expect(ResourceType.resourceTypeNameInput.getValue()).to.equal(randomName);
		expect(ResourceType.propertyContainerElmt.getText()).to.equal(testProperty);
		expect(ResourceType.componentContainerElmt.getText()).to.equal(testComponent);
		browser.pause(config.app.waitTime);
		Home.closeModal.click();
		browser.pause(config.app.waitTime);
		$(`td*=${randomName}`).rightClick();
		Home.deleteTestRow(randomName);

	});

});
