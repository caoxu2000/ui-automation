import LoginPage from '../pageobjects/login.page';
import Step from '../pageobjects/step.page';
import Process from '../pageobjects/process.page';
import getRandomName from '../helpers/get_random_name';
import waitForElement from '../helpers/wait_for_element';
import MainMenu from '../pageobjects/main.menu.page';
import Role from '../pageobjects/role.page';
const config = require('config');
const randomName = getRandomName();
const alertMessage = 'You cannot edit this process. Either you have' +
	' view-only permission, this is an older process version, or a linked' + 
	' process. Please access linked processes from the library to make changes.';
const errMsg = 'element was not loaded';


describe('Share Process', () => {

	it('should share it and give admin role to another user', () => {

		LoginPage.login(config.app.admin.username,
			config.app.admin.password);
		Process.create(randomName);
		MainMenu.dropdown.click();
		browser.waitForElement(Process.shareProcessMnu,
			config.app.waitTime, `Share Process Menu ${errMsg}`);
		MainMenu.shareLnk.click();
		browser.waitForElement(Process.searchUserBox,
			config.app.waitTime, `Search User Box ${errMsg}`);
		Process.searchUserBox.setValue('riffyn.test.2');
		browser.waitForElement(Process.selectFirstUser,
			config.app.waitTime, `First User In Search Results ${errMsg}`);
		Process.selectFirstUser.click();
		browser.waitForElement(Process.userRoleDropDown,
			config.app.waitTime, `User Role DropDown ${errMsg}`);
		Process.userRoleDropDown.selectByValue('viewer');
		browser.waitForElement(Process.shareBtn,
			config.app.waitTime, `Share Button ${errMsg}`);
		Process.shareBtn.click();
		browser.pause(config.app.waitTime);
		Process.confirmationBtn.click();
		browser.pause(config.app.waitTime);
		LoginPage.logout();
		LoginPage.login(config.app.test2.username,
			config.app.test2.password);
		$(`td*=${randomName}`).doubleClick();
		browser.switchTab(browser.getTabIds()[2]);
		browser.pause(config.app.waitTime);
		let isViewer = Role.role.getText().includes('Viewer');
		expect(isViewer).to.be.true;
		Step.firstStepBox.rightClick();
		browser.pause(config.app.downloadWaitTime);
		let isPopupExisting = Step.noAccessPopup.isExisting();
		expect(isPopupExisting).to.be.true;
		expect(Step.noAccessPopup.getText()).to.equal(alertMessage);
		Step.confirmation.click();
		browser.pause(config.app.waitTime);

	});

});
