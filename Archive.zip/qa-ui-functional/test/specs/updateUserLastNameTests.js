import LoginPage from '../pageobjects/login.page';
import Home from '../pageobjects/home.page';
import User from '../pageobjects/user.page';
import getRandomName from '../helpers/get_random_name';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const name = getRandomName();
const testUser3 = 'riffyn.test.3';
const newLastName = `3 ${name}`;
const errMsg = 'element was not loaded';


describe('Update User Last Name Test', () => {

	it('test3\'s last name should be updated', () => {

		LoginPage.login(config.app.admin.username, config.app.admin.password);
		browser.url('library/users');
		browser.waitForElement(Home.searchInputField,
			config.app.waitTime, `Search input ${errMsg}`);
		Home.searchInputField.setValue(testUser3);
		browser.keys(['Enter']);
		browser.pause(config.app.waitTime);
		$(`td*=${testUser3}`).doubleClick();
		browser.waitForElement(User.lastname,
			config.app.waitTime, `Suspend menu ${errMsg}`);
		User.lastname.setValue(newLastName);
		browser.pause(config.app.waitTime);
		Home.confirm.click();
		browser.pause(config.app.waitTime);
		LoginPage.logout();
		LoginPage.login(config.app.test3.username, config.app.test3.password);
		browser.waitForElement(Home.loginUserName,
			config.app.waitTime, `Login User Upper Right Corner ${errMsg}`);
		expect(Home.loginUserName.getText()).to.equal(`RIFFYN TEST ${newLastName}`);
		browser.waitForElement(LoginPage.userIcon, config.app.waitTime,
			`User icon upper left corner ${errMsg}`);
		LoginPage.userIcon.click();
		browser.waitForElement(User.profile, config.app.waitTime,
			`User Profile ${errMsg}`);
		User.profile.click();
		browser.waitForElement(User.formLastName, config.app.waitTime,
			`User Last Name on Profile form ${errMsg}`);
		User.formLastName.setValue('3');
		browser.pause(config.app.waitTime);
		User.profileConfirm.click();
		browser.pause(config.app.waitTime);
		expect(Home.loginUserName.getText()).to.equal(`RIFFYN TEST 3`);

	});

});
