import LoginPage from '../pageobjects/login.page';
import Step from '../pageobjects/step.page';
import waitForElement from '../helpers/wait_for_element';
import Process from '../pageobjects/process.page';
import deleteProcess from '../pageobjects/delete.process.page';
import getRandomName from '../helpers/get_random_name';

const config = require('config');
const testCaseName = 'should add a step before and a step after the default	1st step';
const testProcessName = getRandomName();
const errMsg = 'element was not loaded';


describe('Add Step Before/After Test', () => {

 	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it(testCaseName, () => {

		Process.create(testProcessName);
		browser.waitForElement(Step.resourceOutputIcon, config.app.waitTime,
			`resourceOutputIcon ${errMsg}`);
		Step.addBeforeStep();
		expect(Step.prevStepBox.isExisting()).to.be.true;
		browser.waitForElement(Step.resourceInputIcon, config.app.waitTime,
			`resourceInputIcon ${errMsg}`);
		Step.addStepAfter1st();
		expect(Step.nextStepBox.isExisting()).to.be.true;
		// deleteProcess.delete(testProcessName);

	});

});