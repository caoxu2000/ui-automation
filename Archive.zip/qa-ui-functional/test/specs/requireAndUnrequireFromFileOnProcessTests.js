import LoginPage from '../pageobjects/login.page';
import Process from '../pageobjects/process.page';
import Experiment from '../pageobjects/experiment.page';
import Step from '../pageobjects/step.page';
import getRandomName from '../helpers/get_random_name';
import testProcessAndExperiment from '../pageobjects/testdata.delete';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const testsuite = 'Require Upload Data From File at Process Step level Test';
const testcase = 'Should add File icon to the Process and its Experiments';
const errMsg = 'element was not loaded';
const randomName = getRandomName();


describe(testsuite, () => {

	it(testcase, () => {

		LoginPage.login(config.app.admin.username, config.app.admin.password);
		Process.create(randomName);
		browser.switchTab(browser.getTabIds()[1]);
		Step.requireFromFile();
		browser.waitForElement(Step.fileIconOnStep,
			config.app.waitTime, `Line 24 File Upload icon ${errMsg}`);
		expect(Step.fileIconOnStep.isExisting()).to.be.true;
		Experiment.create(randomName);
		browser.switchTab(browser.getTabIds()[2]);
		browser.waitForElement(Step.fileIconOnStep,
			config.app.waitTime, `Line 29 File Upload icon ${errMsg}`);
		expect(Step.fileIconOnStep.isExisting()).to.be.true;
		browser.switchTab(browser.getTabIds()[1]);
		Step.unrequireFromFile();
		expect(Step.fileIconOnStep.isExisting()).to.be.false;
		Experiment.create(`${randomName} autotest`);
		browser.switchTab(browser.getTabIds()[3]);
		browser.pause(config.app.waitTime);
		expect(Step.fileIconOnStep.isExisting()).to.be.false;
		// testProcessAndExperiment.delete(randomName);

	});

});
