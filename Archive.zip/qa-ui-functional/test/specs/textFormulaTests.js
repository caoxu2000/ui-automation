import LoginPage from '../pageobjects/login.page';
import Home from '../pageobjects/home.page';
import Experiment from '../pageobjects/experiment.page';
import getRandomName from '../helpers/get_random_name';
import Run from '../pageobjects/run.page';
import experimentOfProcess from '../pageobjects/create.experiment.page';
import testProcessAndExperiment from '../pageobjects/testdata.delete';
import Property from '../pageobjects/property.page';
import waitForElement from '../helpers/wait_for_element';

const config = require('config');
const expected_txt = require(config.app.text);
const testName = 'text test';
const propertyName = 'tag';
const randomName = getRandomName();
const errMsg = 'element was not loaded';


describe('String Manipulation Test', () => {

	before(() => {

		const propertySelector = Run.property;
		LoginPage.login(config.app.admin.username, config.app.admin.password);
		experimentOfProcess.create(randomName);
		Run.createNewRunInput.setValue('test1');
		browser.keys(['Enter'])
		browser.pause(config.app.downloadWaitTime);
		Run.modifyRun.click();
		Property.addPropertyToOutput(propertyName);

	});

	it('should parse string correctly', () => {

		Run.actualRun.click();
		browser.waitForElement(Experiment.runTableRow(1, 2), config.app.downloadWaitTime,
			`1st Run Name ${errMsg}`);

		// test resource column that is text/string data type
		expected_txt.forEach(each => {
			for (let i = 1; i <= 5; i++) {
				browser.keys(['ArrowRight']);
			}
			browser.waitForElement(Run.textResource, config.app.downloadWaitTime,
				`Resource Table Cell ${errMsg}`);
			Run.textResource.rightClick();
			browser.waitForElement(Run.formulaEditor, config.app.downloadWaitTime,
				`Formula Editor Menu ${errMsg}`);
			Run.formulaEditor.click();
			browser.waitForElement(Run.formulaInput, config.app.downloadWaitTime,
				`Formula Input Field ${errMsg}`);
			Run.formulaInput.setValue(each.formula);
			browser.pause(config.app.downloadWaitTime);
			Run.updateFormulaBtn.click();
			browser.pause(config.app.downloadWaitTime);
			Run.calculationBtn.click();
			browser.pause(config.app.downloadWaitTime);
			let actual = Run.calculatedResultCell.getText();
			let hasValue = each.expected.indexOf(actual) !== -1;
			if (!hasValue) {
				console.log(`formula is ${each.formula}`);
				console.log(`expected: ${each.expected}`);
				console.log(`actual: ${actual}`);
			}
			expect(hasValue).to.be.true;
		});
		// testProcessAndExperiment.delete(randomName);

	});

});