import LoginPage from '../pageobjects/login.page';
import Step from '../pageobjects/step.page';
import waitForElement from '../helpers/wait_for_element';
import Process from '../pageobjects/process.page';
import deleteProcess from '../pageobjects/delete.process.page';
import getRandomName from '../helpers/get_random_name';
const randomName = getRandomName();
const config = require('config');
const errMsg = 'element was not loaded';


describe('View Step Order Test', () => {

 	before(() => {
		LoginPage.login(config.app.admin.username, config.app.admin.password);
	});

	it('should display the right step order in bottom panel under Design Process', () => {

		Process.create(randomName);
		browser.waitForElement(Step.outputResourceToolbar,
			config.app.waitTime, `Output Resource Toolbar ${errMsg}`);
		Step.firstStepBox.rightClick();
		Step.viewStepOrder.click();
		browser.waitForElement(Step.stepOrderBubble,
			config.app.waitTime, `In Bottom Panel Step Order Circle ${errMsg}`);
		expect(Step.stepOrderBubble.getText()).to.equal('1');
		// deleteProcess.delete(randomName);
	});

});