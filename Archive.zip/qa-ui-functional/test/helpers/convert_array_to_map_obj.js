export default function convertArrayToMapObject(arr) {
	let m = new Map();

	for (let i = 0; i < arr.length; i++) {

	  if (m.has(arr[i])) {
	    m[arr[i]] += 1;
	    
	  } else {
	    m.set(arr[i]);
	    m[arr[i]] = 0;
	  }
	}

	return m;

}
