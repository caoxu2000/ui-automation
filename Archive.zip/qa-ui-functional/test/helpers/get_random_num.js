export default function getRandomNum() {

	return Math.floor(Math.random() * 100000);

}
