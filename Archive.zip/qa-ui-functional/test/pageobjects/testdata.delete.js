import Experiment from '../pageobjects/experiment.page';
import deleteExperiment from '../pageobjects/delete.experiment.page';
import deleteProcess from '../pageobjects/delete.process.page';
const config = require('config');

class testProcessAndExperiment {

	delete(name) {

		browser.url('library/processes');
		deleteProcess.delete(name);
		// this.delExperiment(name); // comment this out for now to shorten test execution time
		browser.pause(config.app.waitTime);

	}

	delExperiment(name) {
		
		browser.url('library/experiments')
		browser.pause(config.app.waitTime);
		deleteExperiment.purgeFromTrash(name);

	}

}

export default new testProcessAndExperiment();