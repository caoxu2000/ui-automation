import Page from './page';

const config = require('config');
const tdSelector2 = '.resource-details-section ' + 
	'tr.table-fixed-row:nth-of-type(2) > td';
const tdSelector3 = '.resource-details-section ' + 
	'tr.table-fixed-row:nth-of-type(3) > td';


class ResourceInventory extends Page {

	get resourceInventoryLibraryLink() {
		return $('a*=Resource Inventory');
	}

	get createResourceLink() {
		return $('span*=Create Resource');
	}

	get resourceName() {
		return $('#resource-name-field');
	}

	get findResource() {
		return $('.search-input');
	}

	get defineNewResourceBtn() {
		return $('.define-resource-detail');
	}

	get resourceType() {
		return $('.resource-type-name');
	}

	get loadResourceUseDetailButton() {
		return $('.btn.load-resource-details');
	}

	get resourceUseDetailSection() {
		return $('.resource-details-section');
	}

	get resourceUseDetail2ndTRAllTDs() {
		return $$(tdSelector2);
	}

	get resourceUseDetail3rdTRAllTDs() {
		return $$(tdSelector3);
	}

}
export default new ResourceInventory();