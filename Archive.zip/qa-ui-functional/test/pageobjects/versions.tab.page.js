class VersionsTab {

	get versionsTabLnk() { return $('li*=Versions'); }
	get version001Lnk() { return $('p=0.01');	}
	get version100Lnk() {	return $('p=1.00');	}
	get version101Lnk() {	return $('p=1.01');	}

	get createNewVersion() { return $('div.version-marker.version-new'); }
	get versionDescription() { return $('textarea.process-description-text'); }
	get createVersionBtn() { return $('.btn.default-button.action-button'); }

	get actualVersionDesc() { return $('.version-description'); }
}

export default new VersionsTab();