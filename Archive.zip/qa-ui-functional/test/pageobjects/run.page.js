import Page from './page';
import CreateRun from './create.run.page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const errMsg = 'element was not loaded';


class Run extends Page {

	get addVariable() { return $('span.add-variable'); }
	get variableNameDivEntry() { return $('.variable.name-entry'); }

	get showDataDropdown() { return $('.form-control.filter-selection'); }
	get dbOption() { return $('optgroup > option:nth-child(1)'); }
	get fileOption() { return $('optgroup > option:nth-child(2)'); }
	get viaDropdown() { return $('.propagation-select.step-range-select'); }
	get via4thStep() { return $('.propagation-select.step-range-select > option[value="1"]'); }
	get disconnectRuns() { return $('[title="Disconnect Runs"]'); }
	get copyRunPlans() { return $('[title="Copy Run Plans"]'); }

	get plan() { return $('span*=Plan'); }
	get modifyRun() { return $('.rf-panel-option.ad-hoc'); }
	get actualRun() { return $('span*=Actual'); }
	get plate() { return $('span*=Plate'); }
	get order() { return $('span*=Order'); }

	get orderNumBubble() { return $$('.step-order-item-order-bubble'); }
	get stepOrderName() { return $$('.step-order-item-name'); }
	get permanentID() { return $$('.step-order-item.id-col'); }

	get attachments() { return $('.rf-panel-option.file-viewer'); }

	get designNotesTab() { return $('[data-tab-name="Design Notes"]'); }
	get observationsTab() { return $('.media-library [data-tab-name="Observations"]'); }

	get attachmentFileName() { return $('.library-table.name'); }

	get createNewRunInput() { return $('.run-name-field')}
	get collectionItem() {
		return $('.item.hide-btn');
	}
	get collectionItemName() {
		return $('.text.nameColumn');
	}
	get collectionExpansionToggle() {
		return $('.expansion-toggle');
	}
	get deleteRunsIcon() {
		return $('.fa-trash');
	}
	get headerRowToggleBox() {
		return $('.header-row .run-label');
	}
	
	get resourceEditHeader() {
		return $('.resource-summary-set header edit');
	}
	get editToolbar() { return $('.property-edit-tools'); }
	get runTable() { return $('.data-table'); }
	get unitPH() { return $('option[value="ph"]'); }
	get unitML() { return $('option[value="milliliter"]'); }
	get unitDropDown() {
		return $('.unit-item');
	}
	get numericResource() {
		return $('div[title="pH"]');
	}
	get textResource() {
		return $('div[title="tag"]');
	}
	get dateResource() {
		return $('div[title="date/time"]');
	}
	get formulaEditor() {
		return $('span*=Formula Editor');
	}

	get formulaInput() {
		return $('.calculated-formula');
	}

	get updateFormulaBtn() {
		return $('.formula-editor-footer > .action-button');
	}

	get calculationBtn() { return $('.calculation-button'); }
	get calculatedResultCell() { return $('.calculated.has-single-value'); }

	get run1stRunName() {
		return $('.data-table.rf-frozen-run-table .data-table-row:nth-of-type(1) td.run-name input');
	}
	get run2ndRunName() {
		return $('.data-table.rf-frozen-run-table .data-table-row:nth-of-type(2) td.run-name input');
	}
	get run3rdRunName() {
		return $('.data-table.rf-frozen-run-table .data-table-row:nth-of-type(3) td.run-name input');
	}
	get run4thRunName() {
		return $('.data-table.rf-frozen-run-table .data-table-row:nth-of-type(4) td.run-name input');
	}
	get run5thRunName() {
		return $('.data-table.rf-frozen-run-table .data-table-row:nth-of-type(5) td.run-name input');
	}
	get run9thRunName() {
		return $('.data-table.rf-frozen-run-table .data-table-row:nth-of-type(6) td.run-name input');
	}
	get run11thRunName() {
		return $('.data-table.rf-frozen-run-table .data-table-row:nth-of-type(11) td.run-name input');
	}
	get run1stInputsUnassignedResource() {
		return $('tr.data-table-row:nth-child(1) td:nth-child(6) input.rf-resource-put');
	}
	get run9thInputsUnassignedResource() {
		return $('tr.data-table-row:nth-child(9) td:nth-child(6) input.rf-resource-put');
	}
	get run11thInputsUnassignedResource() {
		return $('.data-table .data-table-row:nth-of-type(11) td.resource-assignment.varied.input input');
	}
	get run1stOutputsUnassignedResource() {
		return $('.data-table tr.data-table-row:nth-child(1) td.property-cell:nth-child(2) input');
	}
	get run2ndOutputsUnassignedResource() {
		return $('.data-table tr.data-table-row:nth-child(2) td.property-cell:nth-child(2) input');
	}
	get run3rdOutputsUnassignedResource() {
		return $('.data-table tr.data-table-row:nth-child(3) td.property-cell:nth-child(2) input');
	}
	get run4thOutputsUnassignedResource() {
		return $('.data-table tr.data-table-row:nth-child(4) td.property-cell:nth-child(2) input');
	}
	get run5thOutputsUnassignedResource() {
		return $('.data-table tr.data-table-row:nth-child(5) td.property-cell:nth-child(2) input');
	}
	get run6thOutputsUnassignedResource() {
		return $('.data-table tr.data-table-row:nth-child(6) td.property-cell:nth-child(2) input');
	}
	get run9thOutputsUnassignedResource() {
		return $('.data-table tr.data-table-row:nth-child(9) td.property-cell:nth-child(2) input');
	}
	get run1stProperty8thCol() {
		return $('.data-table tr.data-table-row:nth-child(1) td.property-cell input');
	}
	get run2ndProperty8thCol() {
		return $('.data-table tr.data-table-row:nth-child(2) td.property-cell:nth-child(3) input');
	}
	get run3rdProperty8thCol() {
		return $('.data-table tr.data-table-row:nth-child(3) td.property-cell:nth-child(3) input');
	}
	get run4thProperty8thCol() {
		return $('.data-table tr.data-table-row:nth-child(4) td.property-cell:nth-child(3) input');
	}
	get run5thProperty8thCol() {
		return $('.data-table tr.data-table-row:nth-child(5) td.property-cell:nth-child(3) input');
	}
	get run6thProperty8thCol() {
		return $('.data-table tr.data-table-row:nth-child(6) td.property-cell:nth-child(3) input');
	}
	get run9thProperty8thCol() {
		return $('.data-table tr.data-table-row:nth-child(9) td.property-cell:nth-child(3) input');
	}
	get run11thProperty8thCol() {
		return $('.data-table tr.data-table-row:nth-child(11) td.property-cell:nth-child(3) input');
	}

	get run1stProperty7thCol() {
		return $('.data-table tr.data-table-row:nth-child(1) td.property-col input');
	}
	get run2ndProperty7thCol() {
		return $('.data-table tr.data-table-row:nth-child(2) td.property-col.run-override input');
	}
	get run3rdProperty7thCol() {
		return $('.data-table tr.data-table-row:nth-child(3) td.property-col.run-override input');
	}
	get run4thProperty7thCol() {
		return $('.data-table tr.data-table-row:nth-child(4) td.property-col.run-override input');
	}
	get run5thProperty7thCol() {
		return $('.data-table tr.data-table-row:nth-child(5) td.property-col.run-override input');
	}
	get run1stProperty9thCol() {
		return $('.data-table tr.data-table-row:nth-child(1) td.property-cell:nth-child(4) input');
	}
	get run2ndProperty9thCol() {
		return $('.data-table tr.data-table-row:nth-child(2) td.property-cell:nth-child(4) input');
	}
	get run3rdProperty9thCol() {
		return $('.data-table tr.data-table-row:nth-child(3) td.property-cell:nth-child(4) input');
	}
	get run4thProperty9thCol() {
		return $('.data-table tr.data-table-row:nth-child(4) td.property-cell:nth-child(4) input');
	}
	get run5thProperty9thCol() {
		return $('.data-table tr.data-table-row:nth-child(5) td.property-cell:nth-child(4) input');
	}
	get run6thProperty9thCol() {
		return $('.data-table tr.data-table-row:nth-child(6) td.property-cell:nth-child(4) input');
	}
	get run1stProperty10thCol() {
		return $('tr.data-table-row:nth-child(1) td:nth-child(10) input');
	}
	get run2ndProperty10thCol() {
		return $('tr.data-table-row:nth-child(2) td:nth-child(10) input');
	}
	get run3rdProperty10thCol() {
		return $('tr.data-table-row:nth-child(3) td:nth-child(10) input');
	}
	get run4thProperty10thCol() {
		return $('tr.data-table-row:nth-child(4) td:nth-child(10) input');
	}
	get run5thProperty10thCol() {
		return $('tr.data-table-row:nth-child(5) td:nth-child(10) input');
	}
	get run6thProperty10thCol() {
		return $('tr.data-table-row:nth-child(6) td:nth-child(10) input');
	}
	get run1stProperty11thCol() {
		return $('.data-table tr.data-table-row:nth-child(1) td.property-cell:nth-child(6) input');
	}
	get run2ndProperty11thCol() {
		return $('.data-table tr.data-table-row:nth-child(2) td.property-cell:nth-child(6) input');
	}
	get run3rdProperty11thCol() {
		return $('.data-table tr.data-table-row:nth-child(3) td.property-cell:nth-child(6) input');
	}
	get run4thProperty11thCol() {
		return $('.data-table tr.data-table-row:nth-child(4) td.property-cell:nth-child(6) input');
	}
	get run5thProperty11thCol() {
		return $('.data-table tr.data-table-row:nth-child(5) td.property-cell:nth-child(6) input');
	}
	get run6thProperty11thCol() {
		return $('.data-table tr.data-table-row:nth-child(6) td.property-cell:nth-child(6) input');
	}
	get run1stProperty12thCol() {
		return $('.data-table tr.data-table-row:nth-child(1) td.property-cell:nth-child(7) input');
	}
	get run2ndProperty12thCol() {
		return $('.data-table tr.data-table-row:nth-child(2) td.property-cell:nth-child(7) input');
	}
	get run3rdProperty12thCol() {
		return $('.data-table tr.data-table-row:nth-child(3) td.property-cell:nth-child(7) input');
	}
	get run4thProperty12thCol() {
		return $('.data-table tr.data-table-row:nth-child(4) td.property-cell:nth-child(7) input');
	}
	get run5thProperty12thCol() {
		return $('.data-table tr.data-table-row:nth-child(5) td.property-cell:nth-child(7) input');
	}
	get run6thProperty12thCol() {
		return $('.data-table tr.data-table-row:nth-child(6) td.property-cell:nth-child(7) input');
	}
	get run1stProperty13thCol() {
		return $('.data-table tr.data-table-row:nth-child(1) td.property-cell:nth-child(8) input');
	}
	get run2ndProperty13thCol() {
		return $('.data-table tr.data-table-row:nth-child(2) td.property-cell:nth-child(8) input');
	}
	get run3rdProperty13thCol() {
		return $('.data-table tr.data-table-row:nth-child(3) td.property-cell:nth-child(8) input');
	}
	get run4thProperty13thCol() {
		return $('.data-table tr.data-table-row:nth-child(4) td.property-cell:nth-child(8) input');
	}
	get run5thProperty13thCol() {
		return $('.data-table tr.data-table-row:nth-child(5) td.property-cell:nth-child(8) input');
	}
	get run6thProperty13thCol() {
		return $('.data-table tr.data-table-row:nth-child(6) td.property-cell:nth-child(8) input');
	}
	get resourceName() {
		return $('.data-table tr.data-table-row:nth-child(1) td.resource-assignment:nth-child(1) input.rf-resource-put');
	}
	get runName() {
		return $('.data-table.rf-frozen-run-table tr.data-table-row:nth-child(1) td.run-name:nth-child(2) input');
	}
	get multiValueCell() {
		return $('.data-table tr.data-table-row:nth-child(1) td.property-cell input');
	}
	get firstMultiValuePH() {
		return $('.htCore tr:nth-of-type(1) td.isOutput');
	}
	get secondMultiValuePH() {
		return $('.htCore tr:nth-of-type(2) td.isOutput');
	}
	
	get firstRunPH() {
		return $('.data-table tr.data-table-row:nth-child(1) td.property-cell input');
	}
	get firstRunName() {
		return $('.data-table.rf-frozen-run-table tr.data-table-row:nth-child(1) td.run-name:nth-child(2) input');
	}
	get firstRunResource() {
		return $('.data-table tr.data-table-row:nth-child(1) td.resource-assignment:nth-child(1) input.rf-resource-put');
	}
	get resourcesInRunTable() {
		return $$('.rf-resource-group.resource-title');
	}
	get propertiesInRunTable() {
		return $$('.property-col .property-summary .property-name');
	}
	get runFillDownBtn() {
		// return $('button[data-original-title="Fill Down"]');
		return $('.action-button-strip > button.update-run-status:nth-child(2)');
	}
	get checkAllCheckbox() { return $('.header-row .run-label'); }
	get checkAllRuns() {
		return $('.header-row .run-label');
	}
	get checkBoxesForAllRuns() { return $('.header-row .run-label'); }
	get trash() { return $('.fa-trash'); }
	get confirmBtn() { return $('.footer-buttons > button:nth-of-type(2)'); }
	get uploadIcon() { return $('button.upload-data-file'); }
	get fileUploadIcon() { return $('.btn.action-button.query-data-source'); }
	
	get addPropertyToOutput() {
		return $('.resource-output-summary .resource-header .toolbar-actions .add-property');
	}
	get editPropertyToOutput() {
		return $('.resource-output-summary .toolbar-actions .change-property');
	}
	get editPropertyToInput() {
		return $('.resource-input-summary .toolbar-actions .change-property');
	}
	get addPropertyToInput() {
		return $('.resource-input-summary .resource-header .toolbar-actions .add-property');
	}
	get removeProperty() {
		return $('.resource-output-summary .resource-property .toolbar-actions .remove-property');
	}
	get propertyOption() {
		return $('ul.-autocomplete-list > li');
	}
	get findPropertySearchBox() { return $('.search-properties #search'); }
	get addPropertyApply1() { return $('.save-edits.qualitative'); }
	get addPropertyApply2() { return $('.save-edits.quantitative'); }
	get step1() { return $('.activities > .box.activity:nth-child(1)'); }
	
	get anchorOfFirstStep() {
		return $('[data-name="First Step"] .anchor-link .hit-area');
	}
	get anchorOf2ndStep() { return $('.box.activity:nth-of-type(2) .anchor-link'); }
	get anchorOf3rdStep() { return $('.box.activity:nth-of-type(3) .anchor-link'); }
	get anchorOf4thStep() { return $('.box.activity:nth-of-type(4) .anchor-link'); }
	get anchorOf5thStep() { return $('.box.activity:nth-of-type(5) .anchor-link'); }
	get firstStepFirstRunLabel() {
		return $('.first-step .table-body tr.data-table-row:nth-child(1) td.run-label');
	}
	get nextStepFirstRunLabel() {
		return $('.final-step .table-body tr.data-table-row:nth-child(1) td.run-label');
	}
	
	get connectionActionBtn() {
		return $('.run-propagation-connect-action-button');
	}
	get firstRunRows() { return $('.table-body tr.data-table-row:nth-child(1)'); }
	get runTypeDropDown() { return $('.form-control.run-type'); }
	// get disconnectRuns() {
	// 	return $('.toolbar-actions button:nth-child(3)');
	// }
	get confirmation() {
		return $('.modal-overlay.showing .btn.default-button.action-button');
	}
	get allRunTRs() {
		return $('.resource-details-table tbody > tr');
	}
	get editDataContextMenu() {
		return $('span*=Edit Data');
	}

	createRunsAndFillPHValue(name, how_many, num) {

		CreateRun.createMultipleRuns(name, how_many);
		this.checkAllCheckbox.click();
		browser.pause(config.app.downloadWaitTime);
		this.run1stProperty8thCol.click();
		this.run1stProperty8thCol.setValue(num);
		browser.pause(config.app.downloadWaitTime);
		this.runFillDownBtn.click();
		browser.pause(config.app.downloadWaitTime);

	}

	deleteTestRuns() {

		this.headerRowToggleBox.click();
		browser.waitForElement(this.deleteRunsIcon, config.app.waitTime,
			`deleteRunsIcon ${errMsg}`);
		this.deleteRunsIcon.click();
		browser.waitForElement(this.confirmation, config.app.waitTime,
			`confirmation ${errMsg}`);
		this.confirmation.click();
		browser.pause(config.app.downloadWaitTime);

	}

	addMultiValueRuns() {

		this.run1stProperty8thCol.click();
		browser.pause(config.app.waitTime);
		this.run1stProperty8thCol.setValue(1);
		browser.pause(config.app.waitTime);
		this.run1stProperty8thCol.click();
		browser.pause(config.app.waitTime);
		this.run1stProperty8thCol.rightClick();
		browser.waitForElement(this.editDataContextMenu, config.app.waitTime,
			`Edit Data Context Menu Option ${errMsg}`);
		this.editDataContextMenu.click();
		browser.pause(config.app.waitTime);
		this.addDataRowButton.click();
		browser.pause(config.app.waitTime);
		this.editMultiValuedTD.click();
		browser.keys(['2']);
		browser.pause(config.app.waitTime);
		this.addDataRowButton.click();
		browser.pause(config.app.waitTime);
		this.editMultiValuedTD.click();
		browser.keys(['3']);
		browser.pause(config.app.waitTime);
		this.addDataRowButton.click();
		browser.pause(config.app.waitTime);
		this.editMultiValuedTD.click();
		browser.keys(['4']);
		browser.pause(config.app.waitTime);
		this.addDataRowButton.click();
		browser.pause(config.app.waitTime);
		this.editMultiValuedTD.click();
		browser.keys(['5']);
		browser.pause(config.app.waitTime);
		this.addDataRowButton.click();
		browser.pause(config.app.waitTime);
		this.editMultiValuedTD.click();
		browser.keys(['6']);
		browser.pause(config.app.waitTime);
		this.saveAllEdits.click();
		browser.pause(config.app.downloadWaitTime);

	}

	get cleanResultData() { return $('.btn.action-button.clean-result-data'); }

	get editMultiValuedTD() {
		return $('.isOutput.edited.current');
	}
	get addDataRowButton() {
		return $('.add-row');
	}
	get saveAllEdits() {
		return $('button.save-all-edits');
	}
	get cleanMethodDropdown() {
		return $('.select.form-control.select-method');
	}
	get kMeans() {
		return $('option[value="kmeans"]');
	}
	get kParam() {
		return $('.method-parameter');
	}
	get cleaningRule8thCol() {
		return $$('.data-table tr.data-table-row td.property-col div.display-value');
	}
	get applyProcedureToStep() { return $('button.btn.apply-parameters'); }
	get cleaningProcedureName() { return $('input.procedure-name'); }
	get createNewCleaningRuleButton() {
		return $('button*=Create New');
	}
	get viewAppliedProcedureButton() {
		return $('button.view-applied-procedure');
	}
	get editExistingProcedure() {
		return $('[data-content="Editing an existing procedure creates a new version"]');
	}
	get summarySelect() {
		return $('.select.form-control.select-summary');
	}
	get maxOption() {
		return $('option[value="max"]');
	}
	get closeCleaningProcedureModal() { return $('.clean-data-close-button'); }
	get cleaningMethod() { return $$('.cleaning-stage .capitalize'); }
	get clearProcedureFromStepBtn() { return $('.cancel-button.clear-procedure'); }

	createNewCleaningProcedure(name) {

		browser.waitForElement(this.cleanResultData, config.app.waitTime,
			`Clean Result Data icon at bottom tool bar ${errMsg}`);
		this.cleanResultData.click();
		browser.waitForElement(this.createNewCleaningRuleButton, config.app.waitTime,
			`Create New Cleaning Rule Button ${errMsg}`);
		this.createNewCleaningRuleButton.click();
		browser.waitForElement(this.cleaningProcedureName, config.app.waitTime,
			`Cleaning Procedure Name ${errMsg}`);
		this.cleaningProcedureName.setValue(name);
		browser.waitForElement(this.cleanMethodDropdown, config.app.waitTime,
			`Clean Method Dropdown ${errMsg}`);
		this.cleanMethodDropdown.click();
		browser.pause(config.app.waitTime);
		this.kMeans.click();
		browser.pause(config.app.waitTime);
		this.kParam.click();
		browser.pause(config.app.waitTime);
		this.kParam.keys(['Backspace','2']);
		browser.pause(config.app.waitTime);
		this.applyProcedureToStep.click();
		browser.pause(config.app.waitTime);
		browser.waitForElement(this.confirmation, config.app.waitTime,
			`OK button ${errMsg}`);
		this.confirmation.click();
		browser.pause(config.app.waitTime);

	}

	editAppliedProcedure() {

		browser.waitForElement(this.cleanResultData, config.app.waitTime,
			`Clean Result Data icon at bottom tool bar ${errMsg}`);
		this.cleanResultData.click();
		browser.waitForElement(this.viewAppliedProcedureButton, config.app.waitTime,
			`View Applied Procedure Button ${errMsg}`);
		this.viewAppliedProcedureButton.click();
		browser.waitForElement(this.editExistingProcedure, config.app.waitTime,
			`Edit Existing Procedure ${errMsg}`);
		this.editExistingProcedure.click();
		browser.waitForElement(this.summarySelect, config.app.waitTime,
			`Summary Dropdown ${errMsg}`);
		this.summarySelect.click();
		browser.waitForElement(this.maxOption, config.app.waitTime,
			`Max Option ${errMsg}`);
		this.maxOption.click();
		browser.pause(config.app.waitTime);
		this.applyProcedureToStep.click();
		browser.waitForElement(this.confirmation, config.app.waitTime,
			`OK button ${errMsg}`);
		this.confirmation.click();
		browser.pause(config.app.waitTime);

	}

	viewAppliedProcedure() {

		browser.pause(config.app.waitTime);
		browser.waitForElement(this.viewAppliedProcedureButton, config.app.waitTime,
			`View Applied Procedure Button ${errMsg}`);
		this.viewAppliedProcedureButton.click();
		browser.pause(config.app.waitTime);

	}

	clearProcedureFromStep() {

		browser.waitForElement(this.clearProcedureFromStepBtn, config.app.waitTime,
			`Clear Procedure From Step Button ${errMsg}`);
		this.clearProcedureFromStepBtn.click();
		browser.waitForElement(this.confirmation, config.app.waitTime,
			`OK button ${errMsg}`);
		this.confirmation.click();
		browser.pause(config.app.downloadWaitTime);

	}

}

export default new Run();