import Page from './page';
import Home from './home.page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const errMsg = 'element was not loaded';


class Process extends Page {

	create(randomName) {

		browser.waitForElement(Home.createProcessLink, config.app.waitTime,
			`createProcessLink ${errMsg}`);
		Home.createProcessLink.click();
		browser.waitForElement(this.processName, config.app.waitTime,
			`processName ${errMsg}`);
		this.processName.setValue(randomName);
		browser.waitForElement(this.processDesc, config.app.waitTime,
			`processDesc ${errMsg}`);
		this.processDesc.setValue('test description');
		this.updateProcessBtn.click();
		browser.pause(config.app.waitTime);
		browser.switchTab(browser.getTabIds()[1]);
		browser.pause(config.app.waitTime);

	}
	get groupDescription() { return $('textarea.activity-desc'); }
	get includeExperiment() { return $('.include-experiments-input'); }
	get dataDropdown() { return $('.process-info.experiment-data-menu'); }
	get processNavBar() { return $('.process-nav-item.crumbtrail'); }
	get layers() { return $('.layers'); }
	get canvas() { return $('.canvas'); }
	get processName() { return $('input.process-name-field'); }
	get processDesc() { return $('.process-desc-field'); }
	get createProcessLink() { return $('.create-Process'); }
	get updateProcessBtn() { return $('.update-process'); }
	get updateProcessNameBtn() { return $('.default-button.action-button'); }
	get duplicateProcessBtn() { return $('.duplicate-process'); }
	get firstProcessRowInLibrary() {
		return $('tr.library-table-row:nth-of-type(1) > td:nth-of-type(1)');
	}
	
	get shareProcessMnu() {
		return $('.context-items.dropdown-menu > li:nth-child(7)');
	}

	get searchUserBox() { return $('.search-box.search-box-text'); }
	get selectFirstUser() { return $('.-autocomplete-container'); }
	get userRoleDropDown() { return $('.role-item'); }
	get shareBtn() { return $('.send-invitation'); }
	get confirmationBtn() { return $('.btn.default-button.action-button'); }
	get shareWithTab() { return $('.tab-list > li:nth-child(2)'); }
	get cancelX() { return $('.close.cancel-button'); }
	get collaboratorFirstRow() {
		return $('.allowed-collaborators > tr.collaborator-row > td:nth-child(1)');
	}
	get moveToTrash() {
		return $('a*=Move to Trash');
	}
	get restore() {
		return $('a*=Restore');
	}
	get removeFromMyLibrary() {
		return $('a*=Remove from my library');
	}
	get deletePermanently() {
		return $('a*=Delete Permanently');
	}
	get renameProcess() { return $('a*=Rename'); }
	get trashProcess() { return $('a*=Trash'); }
	get allProcess() { return $('a*=All'); }
	get deleteAndRestoreProcess() { return $(`td*=Delete and Restore Test`); }
	get processTD() { return $('tbody > tr:nth-child(1) > td:nth-child(1)'); }
	get purgeButton() { return $('.purge-button'); }

	get addTagLinkContextMnu() {
		return $('a*=Add/Remove Tag');
	}

	get tagNameField() { return $('input.search-box'); }

	get tagUpdateBtn() {
		return $('button.tag-button');
	}

	get tagPill() {
		return $('.tag-pill');
	}

	get removeTag() { return $('.remove-review-pill'); }

	get processTitle() {
		return $('div.app-title-text.title');
	}

	get alertMessage() { return $('.alert-message > p'); }

}

export default new Process();