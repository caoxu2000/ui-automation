import Page from './page';
import Home from './home.page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const errMsg = 'element was not loaded';


class Team extends Page {

	create(teamName, teamMemberName) {

		browser.waitForElement(this.createTeamPlus, config.app.waitTime,
			`Create Team Plus Sign ${errMsg}`);
		this.createTeamPlus.click();
		browser.waitForElement(this.name, config.app.waitTime,
			`Team Name Input Field ${errMsg}`);
		this.name.setValue(teamName);
		browser.pause(config.app.waitTime);
		Home.confirm.click();
		browser.waitForElement(this.addNewUserSearchBox, config.app.waitTime,
			`Add New Team Members ${errMsg}`);
		this.addNewUserSearchBox.setValue(teamMemberName);
		browser.waitForElement(Home.autoComplete1stListItem, config.app.waitTime,
			`1st Option on autocomplete ${errMsg}`);
		Home.autoComplete1stListItem.click();
		browser.pause(config.app.waitTime);
		Home.confirm.click();
		browser.pause(config.app.waitTime);

	}

	removeFirstMemberFn() {

		browser.execute(() => {
			$('.team-members > .team-member:nth-child(2)').trigger('mouseover');
		});
		this.removeFirstMemberDiv.moveToObject();
		browser.waitForElement(this.removeFirstMemberDiv, config.app.waitTime,
			`Remove Team Member link ${errMsg}`);
		this.removeFirstMemberDiv.click();
		browser.pause(config.app.waitTime);

	}

	get removeFirstMemberDiv() {
		return $('.team-members > .team-member:nth-child(2) .remove-member');
	}

	get addNewUserSearchBox() { return $('.search-users > input.search-box'); }

	get name() { return $('input.form-control.team-name-field'); }

	get nameOnRename() { return $('input.form-control.process-name-field'); }

	get teamName() { return $('.team-name > .name'); }

	get createTeamPlus() {
		return $('.library-navigation-link > .create-entity.create-Team');
	}
	get teamsLeftNavLink() { return $('a*=Teams'); }

	get teamCreator() {
		return $('.team-members > .team-member:nth-child(1) .member-name');
	}

	get firstTeamMemberName() {
		// names are sorted that's why it's showing as 2nd row
		return $('.team-members > .team-member:nth-child(2) .member-name');
	}

	get firstTeamMemberEmail() {
		return $('.team-members > .team-member:nth-child(2) .member-email');
	}

	get leaveTeamContextMenu() {
		return $('a*=Leave team');
	}
	get teamSharedWithMe() {
		return $('a*=Teams Shared with Me');
	}

}
export default new Team();