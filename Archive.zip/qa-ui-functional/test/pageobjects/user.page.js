import Page from './page';

class User extends Page {

	get lastname() {
		return $('.user-lastName-field');
	}
	get formLastName() {
		return $('.profile-name-input.lastName');
	}
	get profile() {
		return $('a*=Profile');
	}
	get suspend() {
		return $('a*=Suspend');
	}
	get enable() {
		return $('a*=Enable');
	}
	get profileConfirm() {
		return $('.ui-organize.profile-button');
	}
}

export default new User();