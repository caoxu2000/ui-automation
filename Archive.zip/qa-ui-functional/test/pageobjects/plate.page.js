import Page from './page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const errMsg = 'element was not loaded';


class Plate extends Page {

	get creatPlateTransferRule() {
		return $('.rf-new-plate-config');;
	}

	get sourcePlateID() {
		return $('.rf-source-plate-id-value > input');
	}

	get sourcePlateSize() { return $('.rf-source-plate-size-value'); }

	get destinationPlateID() { return $('.rf-destination-plate-id-value > input'); }

	get destinationPlateSize() { return $('.rf-destination-plate-size-value'); }

	get sourcePlate2X3() {
		return $('.rf-source-plate-size-value option[value="6 (2x3)"]');
	}
	get destinationPlate2X3() {
		return $('.rf-destination-plate-size-value option[value="6 (2x3)"]');
	}

	get verifyButton() {
		return $('#rf-verify-plate-rules');
	}

	get applyButton() {
		return $('#rf-apply-plate-rules');
	}

	transferPlate(plateID) {

		browser.waitForElement(this.creatPlateTransferRule, config.app.waitTime,
			`Create Plate Transfer Rule Plus Sign ${errMsg}`);
		this.creatPlateTransferRule.click();
		browser.waitForElement(this.sourcePlateID, config.app.waitTime,
			`Plate ID Input Field ${errMsg}`);
		browser.pause(config.app.waitTime);
		this.sourcePlateID.click();
		this.sourcePlateID.keys([plateID]);
		this.sourcePlateSize.click();
		this.sourcePlate2X3.click();
		browser.pause(config.app.waitTime);
		this.destinationPlateID.click();
		this.destinationPlateID.keys([plateID]);
		this.destinationPlateSize.click();
		this.destinationPlate2X3.click();
		this.verifyButton.click();
		browser.pause(config.app.waitTime);
		this.applyButton.click();
		browser.pause(config.app.waitTime);

	}

}

export default new Plate();