import Step from './step.page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const errMsg = 'element was not loaded';
const M17 = '.htCore tbody tr:nth-child(17) td:nth-child(14)';

class fileUploadConfig {

	clickFileUpload(filePath) {

		browser.chooseFile('.upload-data-file-input', filePath);
		browser.pause(config.app.waitTime);

	}

	uploadAndConfigSave(filePath) {

		this.clickFileUpload(filePath);
		browser.pause(config.app.waitTime);
		this.newConfig.click();
		browser.waitForElement(this.fileNameConfigSave,
			config.app.waitTime, `Save File Name Button ${errMsg}`);
		this.fileNameConfigSave.click();
		browser.pause(config.app.waitTime);
		browser.waitForElement(this.createDataBlocks,
			config.app.waitTime, `Create Data Blocks Plus ${errMsg}`);

	}


	stepsUptoRunRules(filePath) {

		this.uploadAndConfigSave(filePath);
		this.createDataBlocks.click();
		browser.pause(config.app.waitTime);
		this.runRules.click();
		browser.pause(config.app.waitTime);
		this.runMatchingType.click();
		
	}

	upToInputResourceTypeDropdown() {

		this.runAttribute.click();
		this.runAttrOption.click();
		this.columnFromFile.click();
		this.sample1.click();
		this.resourceRules.click();
		browser.pause(config.app.waitTime);
		this.inputResourceTypeDropdown.click();

	}

	stepsAfterRunMatchingType(whichWay) {

		this.upToInputResourceTypeDropdown();
		if (whichWay == 'output') {
			this.inputUnassignedOption.click();
		} else {
			this.inputWaterOption.click();
		}
		this.inputResourceFromFile.click();
		browser.pause(config.app.waitTime);
		this.sample1.click();
		this.outputResourceTypeDropdown.click();
		if (whichWay == 'output') {
			this.outputWaterOption.click();
		} else {
			this.outputUnassignedOption.click();
		}
		this.outputResourceFromFile.click();
		browser.pause(config.app.waitTime);
		this.outputResourceFromFileSample1.click();
		this.propertyRules.click();
		this.fieldSelectDropdown.click();

	}

	config(filePath, whichWay) {

		this.stepsUptoRunRules(filePath);
		this.createEachRowFromFile.click();
		this.stepsAfterRunMatchingType(whichWay);
		if (whichWay == 'output') {
			this.pHOptionOutput.click();
		} else {
			this.pHOptionInput.click();	
		}
		this.uploadAndSave();

	}

	uploadAndSave() {

		this.uploadAndSaveBtn.click();
		browser.pause(config.app.downloadWaitTime);

	}

	stepsAfterRunMatchingType4Plate() {

		this.upToInputResourceTypeDropdown();
		this.inputUnassignedOption.click();
		this.outputResourceTypeDropdown.click();
		this.outputWaterOption.click();
		this.outputResourceFromFile.click();
		this.outputResourceFromFileSample1.click();
		this.propertyRules.click();

	}

	configPlateTest(filePath) {

		this.uploadAndConfigSave(filePath);
		this.createDataBlocks.click();
		browser.pause(config.app.waitTime);
		this.dataTypeDropDownForColumn.click();
    this.characterOption.click();
		browser.pause(config.app.waitTime);
		this.runRules.click();
		browser.pause(config.app.waitTime);
		this.runMatchingType.click();
		this.createEachRowFromFile.click();
		this.stepsAfterRunMatchingType4Plate();
		this.firstPropertyDropdown.click();
		this.plateIDOutput.click();
		this.secondPropertyDropdown.click();
		this.rowOutput.click();
		this.thirdPropertyDropdown.click();
		this.columnOutput.click();
		this.uploadAndSave();

	}

	addToNewCollection(name, filePath) {

		this.clickFileUpload(filePath);
		browser.waitForElement(this.addToCollectionDropdown,
			config.app.waitTime, `Config modal ${errMsg}`);
		this.addToCollectionDropdown.click();
		browser.pause(config.app.waitTime);
		this.newCollection.click();
		browser.pause(config.app.waitTime);
		this.configName.setValue(name);
		this.createNewCollectionBtn.click();
		browser.pause(config.app.downloadWaitTime);

	}

	applyNewCollection() {
		
		this.collecitonsTab.click();
		browser.pause(config.app.downloadWaitTime);
		this.applyButtonUnderCollectionsTab.click();
		browser.pause(config.app.downloadWaitTime);

	}

	addToExistingCollection(name, filePath) {

		this.config(filePath, 'output');
		this.addToNewCollection(name, filePath);
		this.closeButton.click();
		browser.pause(config.app.waitTime);
		this.config(filePath, 'output');
		this.clickFileUpload(filePath);
		this.addToCollectionDropdown.click();
		browser.pause(config.app.waitTime);
		this.firstExistingCollection.click();
		browser.pause(config.app.waitTime);
		this.confirmButton.click();
		browser.pause(config.app.downloadWaitTime);

	}

	overwriteExistingRuns(filePath) {

		this.stepsUptoRunRules(filePath);
		this.useExistingRuns.click();
		this.stepsAfterRunMatchingType('output');
		this.pHOptionOutput.click();
		this.uploadAndSave();

	}

	manualDataEntryConfig(filePath) {

		this.stepsUptoRunRules(filePath);
		this.createEachRowFromFile.click();
		this.stepsAfterRunMatchingType('output');
		this.manualDataEntryOption.click();
		browser.pause(config.app.waitTime);
		this.manualDataEntry.click();
		browser.pause(config.app.waitTime);
		this.manualDataEntryValue.setValue('1234');
		browser.pause(config.app.waitTime);
		this.uploadAndSave();

	}

	resizingDataBlocks() {

		this.resizingUpdate.click();
		browser.pause(config.app.downloadWaitTime);
		browser.keys(['Shift']).element(M17).click();
		this.resizingSave.click();
		browser.pause(config.app.waitTime);

	}

	duplicate(filePath) {

		this.clickFileUpload(filePath);
		browser.execute(() => {
			$('.config-name-clone').trigger('mouseover');
		});
		browser.pause(config.app.waitTime);
		this.duplicateConfig.moveToObject();
		browser.waitForElement(this.duplicateConfig,
			config.app.waitTime, `duplicate icon ${errMsg}`);
		this.duplicateConfig.click();
		browser.pause(config.app.downloadWaitTime);
		this.confirmButton.click();
		browser.pause(config.app.waitTime);

	}

	rename(name, filePath) {
		this.clickFileUpload(filePath);
		browser.execute(() => {
			$('.config-name-edit').trigger('mouseover');
		});
		browser.pause(config.app.waitTime);
		this.renameConfig.moveToObject();
		browser.waitForElement(this.renameConfig,
			config.app.waitTime, `rename icon ${errMsg}`);
		this.renameConfig.click();
		browser.pause(config.app.waitTime);
		this.editConfigName.setValue(name);
		browser.pause(config.app.waitTime);
		this.renameSave.click();
		browser.pause(config.app.downloadWaitTime);

	}

	delete(filePath) {

		this.clickFileUpload(filePath);
		browser.execute(() => {
			$('.config-name-delete').trigger('mouseover');
		});
		browser.pause(config.app.waitTime);
		this.deleteConfigName.moveToObject();
		browser.waitForElement(this.deleteConfigName,
			config.app.waitTime, `delete icon ${errMsg}`);
		this.deleteConfigName.click();
		browser.pause(config.app.downloadWaitTime);
		this.confirmButton.click();
		browser.pause(config.app.waitTime);

	}


	deleteTestCollection(filePath) {

		this.collecitonsTab.click();
		browser.pause(config.app.downloadWaitTime);
		browser.execute(() => {
			$('.pc-collection-row-delete').trigger('mouseover');
		});
		this.deleteCollectionButton.moveToObject();
		browser.waitForElement(this.deleteCollectionButton,
			config.app.waitTime, `deleteCollectionButton ${errMsg}`);
		this.deleteCollectionButton.click();
		browser.pause(config.app.downloadWaitTime);
		this.confirmButton.click();
		browser.pause(config.app.waitTime);

	}

	removeConfigFromCollection(filePath) {

		this.clickFileUpload(filePath);
		this.collecitonsTab.click();
		browser.pause(config.app.downloadWaitTime);
		this.collectionExpand.click();
		browser.execute(() => {
			$('.pc-name-remove').trigger('mouseover');
		});
		this.removeConfigCross.moveToObject();
		browser.waitForElement(this.removeConfigCross,
			config.app.waitTime, `removeConfig Crossbutton ${errMsg}`);
		this.removeConfigCross.click();
		browser.pause(config.app.waitTime);
		this.confirmButton.click();
		browser.pause(config.app.waitTime);

	}

	configMissingCells(filePath) {
		this.uploadAndConfigSave(filePath);
		this.createDataBlocks.click();
		this.resizingDataBlocks();
		this.field1Name.click();
		this.field1Name.setValue('RUNNUMBER');
		this.field3DataType.click();
		this.field3DataTypeNumberOption.click();
		browser.pause(config.app.waitTime);
		this.runRules.click();
		browser.pause(config.app.waitTime);
		this.runMatchingType.click();
		this.createEachRowFromFile.click();
		this.runAttribute.click();
		this.runAttrOption.click();
		this.columnFromFile.click();
		this.runNumber.click();
		browser.pause(config.app.waitTime);
		this.resourceRules.click();
		browser.pause(config.app.waitTime);
		this.inputResourceTypeDropdown.click();
		this.inputUnassignedOption.click();
		this.inputResourceFromFile.click();
		this.runNumber.click();
		this.propertyRules.click();
		browser.pause(config.app.waitTime);
		this.fieldSelectDropdown.click();
		this.field3.click();
		this.uploadAndSave();

	}

	get field1Name() {
		return $$('.form-control.data-block-field-input')[3];
	}
	get field3DataType() {
		return $$('.form-control.data-block-field-input')[8];
	}
	get field3DataTypeNumberOption() {
		return $$('select.form-control.data-block-field-input > option[value="number"]')[2];
	}
	get numberOption() { return $('option*=Number'); }
	get characterOption() {
		return $('.header-details-item:nth-of-type(6) select.form-control.data-block-field-input > option:nth-child(1)'); 
	}
	get dataTypeDropDownForColumn() {
		return $('.header-details-item:nth-of-type(6) select.form-control.data-block-field-input');
	}
	get noConfigText() { return $('.text.empty-row-text'); }
	get removeConfigCross() { return $('.pc-name-remove'); }
	get collectionExpand() { return $('.expansion-toggle'); }
	get deleteCollectionButton() { return $('.pc-collection-row-delete'); }
	get firstExistingCollection() {
		return $('.add-to-collection.dropdown-content-text');
	}
	get closeButton() { return $('.close.cancel-button.close-location'); }
	get resizingSave() {
		return $('.resizing-save');
	}
	get applyButtonUnderCollectionsTab() {
		return $('.wizard-submit-button.wizard-apply');
	}
	get collecitonsTab() {
		return $('[data-tab-name="Collections"]');
	}
	get createNewCollectionBtn() {
		return $('.config-name-input');
	}
	get configName() {
		return $('#parse-config-name');
	}
	get newCollection() {
		return $('#dropdown-collections > .btn-create-collection.first-row');
	}
	get addToCollectionDropdown() {
		return $('.dropdown > button.btn-add-to-collection');
	}
	get deleteConfigName() {
		return $('.config-name-delete');
	}
	get editConfigName() {
		return $('.edit-input.edit-config-name');
	}
	get renameSave() {
		return $('.config-name-edit-save');
	}
	get renameConfig() {
		return $('.config-name-edit');
	}
	get duplicateConfig() {
		return $('.config-name-clone');
	}
	get firstConfigName() {
		return $('.parse-config-table tbody tr td:nth-child(1)');
	}
	get newConfig() { return $('.btn-create-new'); }
	get fileNameConfigSave() { return $('.config-name-edit-save'); }
	get createDataBlocks() { return $('.create-new-datablock'); }
	get resizingUpdate() { return $('.resizing-start'); }
	get sixthDataBlockRow() {
		return $('.htCore tbody tr:nth-child(6) td:nth-child(4)');
	}
	get uploadAndSaveBtnDropdown() { return $('.dropdown-menu'); }
	get runRules() { return $('[data-step="RunRules"]'); }
	get resourceRules() { return $('[data-step="ResourceRules"]'); }
	get propertyRules() { return $('[data-step="PropertyRules"]'); }
	get manualDataEntry() { return $('[data-step="ManualDataEntry"]'); }
	get inputResourceTypeDropdown() {
		return $('#resource-rules tr.resource-rule > td:nth-child(2) > select');
	}
	get outputResourceTypeDropdown() {
		return $('#resource-attributes tr.resource-rule > td:nth-child(2) > select');
	}
	get inputResourceFromFile() {
		return $('#resource-rules tr.resource-rule > td:nth-child(4) > select');
	}
	get outputResourceFromFile() {
		return $('#resource-attributes tr.resource-rule > td:nth-child(4) > select');
	}
	get inputUnassignedOption() {
		return $('option*=Input | Unassigned | Name');
	}
	get inputWaterOption() {
		return $('option*=Input | Water | Name');
	}
	get passthroughUnassigned() {
		return $('option*=Pass-through | Unassigned | Name');
	}
	get passthroughWaterName() {
		return $('option*=Pass-through | Water | Name');
	}
	get outputWaterOption() {
		return $('option*=Output | Water | Name');
	}
	get outputUnassignedOption() {
		return $('option*=Output | Unassigned | Name');
	}
	get runMatchingType() {
		return $('.di-main-run-rules > div:nth-of-type(2) > .data-block-field-input');
	}
	get createEachRowFromFile() {
		return $('option*=Create as many runs as rows of file data');
	}
	get useExistingRuns() {
		return $('option*=Use existing runs on current step');
	}
	get runAttribute() {
		return $('#run-attributes .run-rule td:nth-child(2) select');
	}
	get runAttrOption() {
		return $('option*=Run | Name');
	}
	get columnFromFile() {
		return $('#run-attributes .run-rule td:nth-child(4) select');
	}
	get runNumber() { return $('option*=RUNNUMBER'); }
	get sample1() {
		return $('option*=Sample 1');
	}
	get outputResourceFromFileSample1() {
		return $('#resource-attributes tr.resource-rule > td:nth-child(4) > select optgroup:nth-of-type(1) > option:nth-of-type(1)');
	}
	get sampleA() {
		return $('option*=Sample A');
	}
	get field3() { return $('option*=Field 3'); }
	get fieldSelectDropdown() {
		return $('.property-item');
	}
	get firstPropertyDropdown() {
		return $('.outputs-table tr:nth-of-type(1) .property-item');
	}
	get secondPropertyDropdown() {
		return $('.outputs-table tr:nth-of-type(2) .property-item');
	}
	get thirdPropertyDropdown() {
		return $('.outputs-table tr:nth-of-type(3) .property-item');
	}
	get plateIDOutput() {
		return $('.outputs-table tr:nth-of-type(1) .property-item option:nth-of-type(3)');
	}
	get plateIDInput() {
		return $('.inputs-table tr:nth-of-type(1) .property-item option:nth-of-type(3)');
	}
	get rowOutput() {
		return $('.outputs-table tr:nth-of-type(2) .property-item option:nth-of-type(4)');
	}
	get columnOutput() {
		return $('.outputs-table tr:nth-of-type(3) .property-item option:nth-of-type(5)');
	}
	get pHOptionInput() {
		return $('.inputs-table tr:nth-of-type(1) td:nth-of-type(4) option:nth-of-type(2)');
	}
	get pHOptionOutput() {
		return $('.outputs-table tr:nth-of-type(1) td:nth-of-type(4) option:nth-of-type(2)');
	}
	get manualDataEntryOption() {
		return $('[value="new-manual-data"]');
	}
	get manualDataEntryValue() {
		return $('.manual-data-entry-value');
	}
	get inputPHDropdown() {
		return $('.inputs-table tr:nth-of-type(1) td:nth-of-type(4)');
	}
	get inputPHOption() {
		return $('.inputs-table tr:nth-of-type(1) td:nth-of-type(4) option:nth-of-type(5)');
	}
	get inputTemperatureDropdown() {
		return $('.inputs-table tr:nth-of-type(2) td:nth-of-type(4)');
	}
	get inputTemperatureOption() {
		return $('.inputs-table tr:nth-of-type(2) td:nth-of-type(4) option:nth-of-type(7)');
	}
	get inputVolumeDropdown() {
		return $('.inputs-table tr:nth-of-type(3) td:nth-of-type(4)');
	}
	get inputVolumeOption() {
		return $('.inputs-table tr:nth-of-type(3) td:nth-of-type(4) option:nth-of-type(6)');
	}
	get outputPHDropdown() {
		return $('.outputs-table tr:nth-of-type(1) td:nth-of-type(4)');
	}
	get outputPHOption() {
		return $('.outputs-table tr:nth-of-type(1) td:nth-of-type(4) option:nth-of-type(5)');
	}
	get outputTemperatureDropdown() {
		return $('.outputs-table tr:nth-of-type(2) td:nth-of-type(4)');
	}
	get outputTemperatureOption() {
		return $('.outputs-table tr:nth-of-type(2) td:nth-of-type(4) option:nth-of-type(7)');
	}
	get outputVolumeDropdown() {
		return $('.outputs-table tr:nth-of-type(3) td:nth-of-type(4)');
	}
	get outputVolumeOption() {
		return $('.outputs-table tr:nth-of-type(3) td:nth-of-type(4) option:nth-of-type(6)');
	}
	get uploadAndSaveBtn() {
		return $('.upload-save');
	}
	get confirmButton() { return $('.btn.default-button.action-button'); }
	get duplicateConfigName() {
		return $('.parse-config-table tbody tr:nth-child(1) td:nth-child(1)');
	}
	get collectionRow() { return $('.title-row.hide-btn.selected'); }
	get emptyAreaContainer() { return $('.empty-area-container'); }

}

export default new fileUploadConfig();