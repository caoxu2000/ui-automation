import Run from '../pageobjects/run.page';
import ResourceToolbar from '../pageobjects/resource.toolbar.page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const errMsg = 'element was not loaded';


class CreateRun {

	create1RunAtATime(name) {

		browser.pause(config.app.waitTime);
		Run.createNewRunInput.setValue(name);
		Run.createNewRunInput.keys(['Enter']);
		browser.pause(config.app.waitTime);

	}

	createMultipleRuns(name, how_many) {

		browser.waitForElement(ResourceToolbar.createNewRunPlus, config.app.waitTime,
			`createNewRunPlus ${errMsg}`);
		ResourceToolbar.createNewRunPlus.click();
		browser.waitForElement(ResourceToolbar.runCounter, config.app.waitTime,
			`runCounter ${errMsg}`);
		ResourceToolbar.runCounter.setValue(how_many);
		ResourceToolbar.runPrefixName.setValue(name);
		ResourceToolbar.createRunBtn.click();
		browser.pause(config.app.waitTime);

	}

}

export default new CreateRun();