import Comment from '../pageobjects/comment.page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const errMsg = 'element was not loaded';


class addComment {

	add(comment) {
		browser.waitForElement(Comment.observationsTab, config.app.waitTime,
			`Observations Tab ${errMsg}`);
		Comment.observationsTab.click();
		Comment.addComment.setValue(comment);
		browser.waitForElement(Comment.saveComment, config.app.waitTime,
			`SaveComment ${errMsg}`);
		Comment.saveComment.click();
		browser.waitForElement(Comment.firstCommentView, config.app.waitTime,
			`FirstCommentView ${errMsg}`);
	}

}

export default new addComment();