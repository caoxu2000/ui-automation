class Role {

	get role() {
		return $('.user-role');
	}

}

export default new Role();