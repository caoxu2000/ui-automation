import Process from './process.page';
import Experiment from './experiment.page';
import Resource from './resource.page';
import Run from './run.page';
import Step from './step.page';
import Property from './property.page';
import Home from './home.page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const errMsg = 'element was not loaded';


class experimentOfProcess {

	get url() { return browser.getUrl(); }

	create(name) {

		Process.create(name);
		browser.switchTab(browser.getTabIds()[1]);
		Experiment.create(name);
		browser.switchTab(browser.getTabIds()[2]);
		browser.pause(config.app.waitTime);
		
	}
	
	createConnectedSteps(name) {

		this.createProcessWithProperty(name);
		Experiment.create(name);
		browser.switchTab(browser.getTabIds()[2]);
		browser.pause(config.app.waitTime);

	}

	createMultipleExperiments(name, exp1, exp2, exp3, num1, num2, num3) {

		this.createProcessWithProperty(name);
		Experiment.create(exp1);
		browser.switchTab(browser.getTabIds()[2]);
		browser.pause(config.app.waitTime);
		Run.createRunsAndFillPHValue('automation ', 5, num1);
		browser.switchTab(browser.getTabIds()[1]);
		browser.pause(config.app.waitTime);
		Experiment.create(exp2);
		browser.switchTab(browser.getTabIds()[3]);
		browser.pause(config.app.waitTime);
		Run.createRunsAndFillPHValue('automation ', 5, num2);
		browser.switchTab(browser.getTabIds()[1]);
		browser.pause(config.app.waitTime);
		Experiment.create(exp3);
		browser.switchTab(browser.getTabIds()[4]);
		browser.pause(config.app.waitTime);
		Run.createRunsAndFillPHValue('automation ', 5, num3);
		browser.switchTab(browser.getTabIds()[1]);
		browser.pause(config.app.waitTime);

	}

	createProcessWithProperty(name) {
		
		Process.create(name);
		browser.switchTab(browser.getTabIds()[1]);
		browser.waitForElement(Resource.outputResourceNameUnassigned,
			config.app.waitTime, `outputResourceNameUnassigned ${errMsg}`);
		Resource.changeOutputUnassignedResourceType('water');
		Property.addPropertyToOutput('pH');
		Step.addStepAfter1st();
		Step.firstStepBox.click();
		Property.propagateFirstProperty();

	}
	addPlateProperties() {

		Property.addPropertyToOutput('plate ID');
		Property.addPropertyToOutput('row');
		Property.addPropertyToOutput('column');

	}
	createConnectedStepsForPlateTransfer(name) {

		Process.create(name);
		browser.switchTab(browser.getTabIds()[1]);
		browser.waitForElement(Resource.outputResourceNameUnassigned,
			config.app.waitTime, `outputResourceNameUnassigned ${errMsg}`);
		Resource.changeOutputUnassignedResourceType('water');
		this.addPlateProperties();
		Step.addStepAfter1st();
		Step.firstStepBox.click();
		Property.propagateFirstProperty();
		Property.propagateSecondProperty();
		Property.propagateThirdProperty();
		Step.nextStepBox.click();
		Resource.changeOutputUnassignedResourceType('air pump');
		this.addPlateProperties();
		Experiment.create(name);
		browser.switchTab(browser.getTabIds()[2]);
		browser.pause(config.app.waitTime);

	}
	create5ConnectedSteps(name) {

		Process.create(name);
		browser.switchTab(browser.getTabIds()[1]);
		Step.addStepAfter1st(); // this is the 2nd Step
		Step.addStepAfter2nd(); // this is the 3rd Step
		Step.addStepAfter1st(); // this is the 4th Step
		Step.addStepAfter3rd(); // this is the 5th Step
		Step.fourthStepBox.click();
		browser.pause(config.app.waitTime);
		Resource.changeOutputUnassignedResourceType('defensin');
		browser.pause(config.app.waitTime);
		Step.thirdStepBox.click();
		browser.pause(config.app.waitTime);
		Resource.addInput.click();
		browser.pause(config.app.waitTime);
		Resource.addSelectedResourceToStep.click();
		browser.pause(config.app.waitTime);
		Experiment.create(name);
		browser.switchTab(browser.getTabIds()[2]);
		browser.pause(config.app.waitTime);

	}
}

export default new experimentOfProcess();