import Run from './run.page';
import Home from './home.page';
import Resource from './resource.page';
import waitForElement from '../helpers/wait_for_element';

const config = require('config');
const errMsg = 'element was not loaded';
const outputCSSAddProp = '.resource-output-summary .resource-header .toolbar-actions .add-property';
const inputCSSAddProp = '.resource-input-summary .resource-header .toolbar-actions .add-property';
const outputCSSEditProp = '.resource-output-summary .toolbar-actions .change-property';
const inputCSSEditProp = '.resource-input-summary .toolbar-actions .change-property';


class Property {

	create(name) {
		browser.waitForElement(Home.openLeftNav,
			config.app.waitTime, `openLeftNav ${errMsg}`);
		Home.openLeftNav.click();
		browser.waitForElement(this.propertyLibraryLink,
			config.app.waitTime, `propertyLibraryLink ${errMsg}`);
		this.propertyLibraryLink.click();
		browser.waitForElement(this.createPropertyLink,
			config.app.waitTime, `createPropertyLink ${errMsg}`);
		this.createPropertyLink.click();
		browser.waitForElement(this.propertyNameInput,
			config.app.waitTime, `propertyNameInput ${errMsg}`);
		this.propertyNameInput.setValue(name);
		browser.pause(config.app.waitTime);
		this.addPropertyButton.click();
		browser.waitForElement(this.addUnitSearchBox,
			config.app.waitTime, `addUnitSearchBox ${errMsg}`);
		this.addUnitSearchBox.setValue('degree');
		browser.waitForElement(this.property1stOption,
			config.app.waitTime, `property1stOption ${errMsg}`);
		this.property1stOption.click();
		browser.pause(config.app.waitTime);
		Home.actionButton.click();
		browser.pause(config.app.waitTime);
	}
	get propertyLibraryLink() {
		return $('a*=Properties');
	}
	get createPropertyLink() {
		return $('span*=Create Property');
	}
	get propertyNameInput() {
		return $('input.property-name');
	}
	get nameFieldInDuplicate() {
		return $('.form-control.propertyType-name-field');
	}
	get duplicatePropertyConfirm() {
		return $('.btn.default-button.duplicate-button');
	}
	get propName() {
		return $('.property-name.user-defined');
	}
	get addPropertyButton() {
		return $('button.add-property');
	}

	get addUnitSearchBox() {
		return $('#search-units');
	}
	get property1stOption() {
		return $('ul.-autocomplete-list > li:nth-of-type(1)');
	}
	get permitted1stUnit() {
		return $('.permitted-units .unit-col.name');
	}
	get cancelPropertyButton() { return $('.cancel-property'); }
	get cancelPropertyCreate() { return $('.btn.cancel-create.cancel-button'); }
	get done() { return $('.btn.default-button.update-property'); }
	get targetInput() { return $('[data-field="target"]'); }

	searchProperty(propertyName) {

		Run.findPropertySearchBox.click();
		browser.waitForElement(Run.findPropertySearchBox, config.app.waitTime,
			`findPropertySearchBox ${errMsg}`);
		Run.findPropertySearchBox.setValue(propertyName);
		browser.pause(config.app.waitTime);
		Run.propertyOption.click();
		browser.pause(config.app.waitTime);

	}
	searchAndSelectProperty(propertyName) {
		
		this.searchProperty(propertyName);
		if (propertyName !== 'pH' && propertyName !== 'volume') {

			Run.addPropertyApply1.click();

		}
		else {

			Run.unitDropDown.click();
			if (propertyName == 'pH') {
				browser.waitForElement(this.targetInput, config.app.waitTime,
					`Target Input field ${errMsg}`);
				this.targetInput.setValue('12');
				browser.waitForElement(Run.unitPH, config.app.waitTime,
					`pH option ${errMsg}`);
				Run.unitPH.click();

			} else if (propertyName == 'volume') {

				browser.waitForElement(Run.unitML, config.app.waitTime,
					`mL option ${errMsg}`);
				Run.unitML.click();

			}
			Run.addPropertyApply2.click();
		}
	}
	addPropertyToOutput(propertyName) {
		browser.execute((cssSelector) => {
			$(cssSelector).trigger('mouseover');
		}, outputCSSAddProp);
		browser.pause(config.app.waitTime);
		Run.addPropertyToOutput.moveToObject();
		browser.pause(config.app.waitTime);
		Run.addPropertyToOutput.click();
		this.searchAndSelectProperty(propertyName);
	}
	addPropertyToInput(propertyName) {
		browser.execute((cssSelector) => {
			$(cssSelector).trigger('mouseover');
		}, inputCSSAddProp);
		browser.pause(config.app.waitTime);
		Run.addPropertyToInput.moveToObject();
		browser.pause(config.app.waitTime);
		Run.addPropertyToInput.click();
		this.searchAndSelectProperty(propertyName);
	}
	deleteFirstProperty() {
		browser.execute(() => {
			$('.resource-output-summary .resource-property .toolbar-actions .remove-property')
				.trigger('mouseover');
		});
		browser.pause(config.app.waitTime);
		Resource.removeProperty.moveToObject();
		browser.pause(config.app.waitTime);
		Resource.removeProperty.click();
		browser.pause(config.app.waitTime);
		Resource.removeEntityConfirm.click();
		browser.pause(config.app.waitTime);
	}
	propagateDownStream(propagateDownstream) {
		browser.pause(config.app.waitTime);
		propagateDownstream.moveToObject();
		browser.pause(config.app.waitTime);
		propagateDownstream.click();
		browser.pause(config.app.waitTime);
	}
	propagateFirstProperty() {
		browser.execute(() => {
			$('.resource-output-summary .resource-definition tr:nth-child(2) .toolbar-actions .propagate-downstream')
				.trigger('mouseover');
		});
		this.propagateDownStream(Resource.propagateFirstPropertyDownstream);
	}
	propagateSecondProperty() {
		browser.execute(() => {
			$('.resource-output-summary .resource-definition tr:nth-child(3) .toolbar-actions .propagate-downstream')
				.trigger('mouseover');
		});
		this.propagateDownStream(Resource.propagateSecondPropertyDownstream);
	}
	propagateThirdProperty() {
		browser.execute(() => {
			$('.resource-output-summary .resource-definition tr:nth-child(4) .toolbar-actions .propagate-downstream')
				.trigger('mouseover');
		});
		this.propagateDownStream(Resource.propagateThirdPropertyDownstream);
	}
	addPropertyToOutputForCustomizedProp(propertyName) {
		browser.execute((cssSelector) => {
			$(cssSelector).trigger('mouseover');
		}, outputCSSAddProp);
		browser.pause(config.app.waitTime);
		Run.addPropertyToOutput.moveToObject();
		browser.pause(config.app.waitTime);
		Run.addPropertyToOutput.click();
		this.searchProperty(propertyName);
		Run.addPropertyApply2.click();
	}
	editPropertyToOutput(propertyName) {
		browser.execute((cssSelector) => {
			$(cssSelector).trigger('mouseover');
		}, outputCSSEditProp);
		browser.pause(config.app.waitTime);
		Run.editPropertyToOutput.moveToObject();
		browser.pause(config.app.waitTime);
		Run.editPropertyToOutput.click();
		browser.waitForElement(this.propertyNameInput, config.app.waitTime,
			`Property Name Input ${errMsg}`);
		this.propertyNameInput.setValue(propertyName);
		Home.actionButton.click();
		browser.pause(config.app.waitTime);
	}

}

export default new Property();