import Process from '../pageobjects/process.page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const errMsg = 'element was not loaded';


class deleteProcess {

	delete(randomName) {

		const expectedAlertMsg = 'Are you sure you want to delete this process?';
		browser.url('library/processes');
		browser.pause(config.app.downloadWaitTime);
		$(`td*=${randomName}`).rightClick();
		browser.waitForElement(Process.moveToTrash, config.app.waitTime,
			`moveToTrashMenu ${errMsg}`);
		Process.moveToTrash.click();
		browser.pause(config.app.waitTime);
		Process.includeExperiment.click();
		Process.confirmationBtn.click();
		browser.pause(config.app.waitTime);
		let isElemExisting = $(`td*=${randomName}`).isExisting();
		expect(isElemExisting).to.be.false;
		
		// comment out the below code block to shorten test execution time

		// browser.waitForElement(Process.trashProcess, config.app.waitTime,
		// 	`trashProcessLeftNav ${errMsg}`);
		// Process.trashProcess.click();
		// browser.pause(config.app.waitTime);
		// $(`td*=${randomName}`).rightClick();
		// browser.waitForElement(Process.deletePermanently, config.app.waitTime,
		// 	`deletePermanentlyMenu ${errMsg}`);
		// Process.deletePermanently.click();
		// browser.pause(config.app.waitTime);
		// let actualAlertMsg = Process.alertMessage.getText();
		// expect(actualAlertMsg).equals(expectedAlertMsg);
		// Process.confirmationBtn.click();
		// browser.pause(config.app.waitTime);
		// expect($(`td*=${randomName}`).isExisting()).to.be.false;

	}

}

export default new deleteProcess();