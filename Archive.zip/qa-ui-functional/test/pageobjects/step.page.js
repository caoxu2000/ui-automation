import Page from './page';
import Property from './property.page';
const config = require('config');
const firstStepOutput = '[data-name="First Step"] .resource.output';
const firstStepInput = '[data-name="First Step"] .resource.input';
const secondStepOutput = '.box.activity:nth-of-type(2) .resource.output';
const thirdStepOutput = '.box.activity:nth-of-type(3) .resource.output';
const errMsg = 'element was not loaded';


class Step extends Page {

	stepsToAddStepFromOutput() {

		this.addStepAfter1stMenu.click();
		browser.pause(config.app.waitTime);

	}
	addStepAfter1st() {

		browser.execute((cssSelector) => {
			$(cssSelector).trigger('mouseover');
		}, firstStepOutput);
		$(firstStepOutput).rightClick();
		this.stepsToAddStepFromOutput();

	}

	addBeforeStep() {

		browser.execute((cssSelector) => {
			$(cssSelector).trigger('mouseover');
		}, firstStepInput);
		this.resourceInputIcon.rightClick();
		this.addBeforeStepMenu.click();
		browser.pause(config.app.waitTime);
		
	}

	addStepAfter2nd() {
		browser.execute((cssSelector) => {
			$(cssSelector).trigger('mouseover');
		}, secondStepOutput);
		$(secondStepOutput).rightClick();
		this.stepsToAddStepFromOutput();
	}
	addStepAfter3rd() {
		browser.execute((cssSelector) => {
			$(cssSelector).trigger('mouseover');
		}, thirdStepOutput);
		$(thirdStepOutput).rightClick();
		this.stepsToAddStepFromOutput();
	}

	get secondStepBox() { return $('.box.activity:nth-of-type(2)'); }
	get resourceInput2ndStep() { return $('.box.activity:nth-of-type(2) .resource.input'); }
	get resourceOutput2ndStep() { return $(secondStepOutput); }
	get activeStepActivityLabel() {
		return $('.editable-label-text');
	}

	get thirdStepBox() { return $('.box.activity:nth-of-type(3)'); }
	get resourceInput3rdStep() { return $('.box.activity:nth-of-type(3) .resource.input'); }
	get resourceOutput3rdStep() { return $(thirdStepOutput); }
	
	get fourthStepBox() { return $('.box.activity:nth-of-type(4)'); }
	get resourceInput4thStep() { return $('.box.activity:nth-of-type(4) .resource.input'); }
	get resourceOutput4thStep() { return $('.box.activity:nth-of-type(4) .resource.output'); }

	get fifthStepBox() { return $('.box.activity:nth-of-type(5)'); }
	get resourceInput5thStep() { return $('.box.activity:nth-of-type(5) .resource.input'); }
	get resourceOutput5thStep() { return $('.box.activity:nth-of-type(5) .resource.output'); }

	get resourceOutputIcon() {
		return $(firstStepOutput);
	}

	get resourceInputIcon() {
		return $(firstStepInput);
	}

	get linkedProcessEntity() {
		return $('.box.subgroup.linked-entity');
	}

	get firstProcessCheckbox() {
		return $('.process-table-row:nth-of-type(1) > .process-select > input');
	}

	get linkExistingProcessMenu() {
		return $('a*=Link Existing Process');
	}

	get addStepAfter1stMenu() {
		return $('a*=Add Step After');
	}

	get addBeforeStepMenu() {
		return $('a*=Add Step Before');
	}

	get processTopNavBar() {
		return $('.process-nav-item.crumbtrail');
	}

	get stepDescription() {
		return $('.activity-desc');
	}

	get unGroupNewBaseStepLabel() {
		return $('[data-name="First step of New Base Step"] .activity-label');
	}

	get addNewStepLnk() {
		return $('span.add-step');
	}

	get addNewBaseStepLink() { return $('span.add-step'); }

	get newBaseStep() { return $('[data-name="New Base Step"]'); }

	get firstStepNewBaseStep() {
		return $('[data-name="First step of New Base Step"]');
	}

	get stepOrderLabel() { return $('.step-order-label'); }

	get moveToParentGrp() { return $('a*=Move To Parent Group'); }

	get parentProcessLink() { return $('a*=UI Automated Test'); }
	
	get firstStepBox() {
		return $('[data-name="First Step"]');
	}
	get resourceInput1stStep() { return $('.box.activity:nth-of-type(1) .resource.input'); }
	get resourceOutput1stStep() { return $('.box.activity:nth-of-type(1) .resource.output'); }

	get firstStepBoxOrder() {
		return $('[data-name="Step 1"] .step-order-label');
	}

	get firstStepCopy() {
		return $('[data-name="First Step (copy)"]');
	}

	get encloseInNewGroup() {
		return $('a*=Enclose In New Group');
	}

	get moveToAdjacentGrp() {
		return $('a*=Move To Adjacent Group');
	}

	get unGroupSteps() {
		return $('a*=Ungroup Steps');
	}

	get groupIcon() { return $('.group-link'); }

	get prevStepBox() {
		return $('[data-name="Prev Step"]');
	}
	get nextStepBox() {
		return $('[data-name="Next Step"]');
	}
	get prevStepLabel() { return $('[data-name="Prev Step"] > .step-order-label'); }
	get nextStepLabel() { return $('[data-name="Next Step"] > .step-order-label'); }

	get addStepAfterLnk() { return $('a*=Add Step After'); }
	get deleteStepLnk() { return $('a*=Delete Step'); }

	get confirmation() { return $('.default-button.action-button'); }
	get no() { return $('.btn.cancel-button:not(.cancel-instruction-new)'); }

	get newStepBox() {
		return $('.activities > .box.activity:nth-child(2)');
	}

	get defaultFirstStep() {
		return $('.activities > .box.activity:nth-child(1)');
	}

	get contextMenu() {
		return $('.context-items');
	}

	get noAccessPopup() {
		return $('.modal-content .alert-message');
	}

	get outputResourceToolbar() {
		return $('.resource-output-summary .resource-name');
	}

	get viewStepOrder() { return $('a*=View Step Order'); }
	get showStepID() { return $('a*=Show Step ID'); }
	get addInput() { return $('a*=Add Input'); }
	get addOutput() { return $('a*=Add Output'); }
	get stepOrderBubble() { return $('.step-order-item-order-bubble') }
	get stepLabel() { return $('.step-label'); }
	get deleteGroupLnk() { return $('a*=Delete Group'); }
	get duplicateMenu() {	return $('a*=Duplicate'); }
	get fileIconOnStep() { return $('.badge-item.file-icon'); }
	get dbIconOnStep() { return $('.badge-item.db-query-icon'); }
	get requireFromFileMenu() { return $('a*=Require Data Upload From a File'); }
	get unRequireFromFileMenu() { return $('a*=Unrequire Data Upload From a File'); }
	get requireFromDB() { return $('a*=Require Data Upload From a DB Query'); }
	get unRequireFromDB() { return $('a*=Unrequire Data Upload From a DB Query'); }
	get pushDataRequirementsToWorking() {
		return $('a*=Push Data Requirements to Working');
	}
	addNewStep() {
		this.addNewStepLnk.click();
		browser.pause(config.app.waitTime);
	}
	removeNewStep() {
		this.newBaseStep.rightClick();
		this.deleteStepLnk.click();
		browser.pause(config.app.waitTime);
		this.confirmation.click();
		browser.pause(config.app.waitTime);
	}
	deleteGroup() {
		this.newBaseStep.rightClick();
		this.deleteGroupLnk.click();
		browser.pause(config.app.waitTime);
		this.confirmation.click();
		browser.pause(config.app.waitTime);
	}
	deleteStep() {
		this.newBaseStep.rightClick();
		this.deleteStepLnk.click();
		browser.pause(config.app.waitTime);
		this.confirmation.click();
		browser.pause(config.app.waitTime);
	}
	rightClickOnFirstStep() {

		browser.waitForElement(this.firstStepBox,
			config.app.waitTime, `First Step Box ${errMsg}`);
		this.firstStepBox.rightClick();

	}
	requireFromFile() {

		this.rightClickOnFirstStep();
		browser.waitForElement(
			this.requireFromFileMenu,
			config.app.waitTime,
			`Require Data Upload From File Menu ${errMsg}`
		);
		this.requireFromFileMenu.click();
		browser.pause(config.app.waitTime);

	}
	unrequireFromFile() {

		this.rightClickOnFirstStep();
		browser.waitForElement(
			this.unRequireFromFileMenu, config.app.waitTime,
			`Unrequire Data Upload From File Menu ${errMsg}`
		);
		this.unRequireFromFileMenu.click();
		browser.pause(config.app.waitTime);

	}
	requireFromDBQuery() {

		this.rightClickOnFirstStep();
		browser.waitForElement(
			this.requireFromDB, config.app.waitTime,
			`Require Data Upload From a DB query ${errMsg}`
		);
		this.requireFromDB.click();
		browser.pause(config.app.waitTime);

	}
	unRequireFromDBQuery() {

		this.rightClickOnFirstStep();
		browser.waitForElement(
			this.unRequireFromDB, config.app.waitTime,
			`Unrequire Data Upload From a DB query ${errMsg}`
		);
		this.unRequireFromDB.click();
		browser.pause(config.app.waitTime);

	}
}

export default new Step();