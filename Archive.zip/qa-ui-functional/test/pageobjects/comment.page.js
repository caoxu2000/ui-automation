class Comment {

	get infoTab() { return $('li*=Info'); }
	get observationsTab() {
		return $('li*=Observations');
	}
	get designNotesTab() {
		return $('li*=Design Notes');
	}
	get addTaskBtn() { return $('.show-add-step'); }
	get stepText() { return $('.add-step-text'); }
	get saveTaskBtn() { return $('.btn.add-instruction'); }
	get updateTaskButton() { return $('.btn.update-instruction'); }

	get uploadClip() { return $('.add-media-content'); }
	get uploadButton() { return $('.choose-media-upload'); }
	get clickToUpload() { return $('.add-media-files'); }
	get mediaImage() { return $('.media.image'); }
	get removeMedia() { return $('.btn.file-viewer-remove.remove-media'); }
	get downloadMedia() { return $('.btn.file-viewer-download'); }
	get mediaContent() { return $('.media-content.view'); }
	get confirm() { return $('.btn.default-button.action-button'); }

	get thirdTaskText() {
		return $('.procedure-step.view:nth-child(3) .procedure-step-text');
	}
	get thirdTaskOrder() {
		return $('.procedure-step.view:nth-child(3) .procedure-step-order');
	}
	get secondTaskStepText() {
		return $('.procedure-step.view:nth-child(2) .procedure-step-text');
	}
	get secondTaskStepOrder() {
		return $('.procedure-step.view:nth-child(2) .procedure-step-order');
	}
	get secondTaskStepMenu() {
		return $('.procedure-step.view:nth-child(2) .procedure-step-menu');
	}
	get firstTaskStepText() {
		return $('.procedure-step.view:nth-child(1) .procedure-step-text');
	}
	get firstTaskStepOrder() {
		return $('.procedure-step.view:nth-child(1) .procedure-step-order');
	}
	get firstTaskStepMenu() {
		return $('.procedure-step.view:nth-child(1) .procedure-step-menu');
	}
	get singleTaskStepText() {
		return $("textarea.procedure-step-text.edit");
	}

	get taskMain() { return $('.procedure-step-main'); }
	get saveButton() { return $('.save-instruction'); }
	get updateButton() { return $('.update-instruction'); }
	get cancelButton() { return $('.cancel-instruction'); }

	get contextMenuCrossSteps() { return $('.go-to-instruction.design'); }
	get removeAllCrossStepLinks() { return $('a*=Remove all cross step links'); }
	get firstStepWithinStep1() { return $('.procedure-step.view:nth-child(1)'); }
	get secondStepWithinStep1() { return $('.procedure-step.view:nth-child(2)'); }

	get makeTaskLast() { return $('a*=Make Last Task'); }
	get makeTaskFirst() { return $('a*=Make First Task'); }
	get deleteTask() { return $('a*=Delete task'); }
	get taskSteps() { return $('.procedure-step'); }
	get secondStep() { return $('.procedure-step.view:nth-child(2)'); }
	get editTask() { return $('.procedure-step-text.edit'); }

	get sideBar() {	return $('.side-bar'); }
	get addComment() { return $('textarea.add-comment'); }
	get saveComment() { return $('.btn.save-comment.hover'); }
	get saveReplyToComment() { return $('.save-comment.reply'); }
	get updateComment() { return $('.update-comment'); }
	get editComment() { return $('.edit-comment'); }
	get replyToComment() { return $('.reply-comment'); }
	get editCommentArea() { return $('textarea.add-comment.original'); }
	get replyToArea() { return $('.add-comment.reply'); }
	get deleteComment() { return $('.delete-comment'); }
	get firstCommentView() { return $('.content-row.comment .activity-comment.view'); }
	get replyToCommentView() { return $('.comment-reply .activity-comment.view'); }
	get contentAuthor() { return $('.content-author'); }

}

export default new Comment();