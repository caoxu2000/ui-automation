import waitForElement from '../helpers/wait_for_element';
import Resource from './resource.page';
const config = require('config');
const errMsg = 'element was not loaded';


class crudComponent {

	add(componentName) {
		browser.execute(() => {
			$('.resource-input-summary .resource-header .toolbar-actions .add-component')
				.trigger('mouseover');
		});
		browser.pause(config.app.waitTime);
		Resource.addComponentIcon.moveToObject();
		browser.pause(config.app.waitTime);
		Resource.addComponentIcon.click();
		browser.waitForElement(Resource.resourceTypeSearch, config.app.waitTime,
			`resourceTypeSearch ${errMsg}`);
		browser.waitUntil(() => {
			return Resource.resourceTypeSearch.isEnabled();
		}, config.app.waitTime, `resource search input field ${errMsg}`);
		Resource.resourceTypeSearch.setValue(componentName);
		browser.pause(config.app.downloadWaitTime);
		Resource.firstResource.click();
		browser.pause(config.app.downloadWaitTime);
		Resource.addComponent.click();
		browser.pause(config.app.downloadWaitTime);
	}
	change(anotherComponentName) {
		browser.execute(() => {
			$('.resource-input-summary .resource-header .toolbar-actions .change-component')
				.trigger('mouseover');
		});
		browser.pause(config.app.waitTime);
		Resource.changeComponentIcon.moveToObject();
		browser.pause(config.app.waitTime);
		Resource.changeComponentIcon.click();
		browser.waitForElement(Resource.resourceTypeSearch, config.app.waitTime,
			`resourceTypeSearch ${errMsg}`);
		browser.waitUntil(() => {
			return Resource.resourceTypeSearch.isEnabled();
		}, config.app.waitTime, `resource search input field ${errMsg}`);
		Resource.resourceTypeSearch.setValue(anotherComponentName);
		browser.pause(config.app.downloadWaitTime);
		Resource.firstResource.click();
		browser.pause(config.app.downloadWaitTime);
		Resource.changeComponent.click();
		browser.pause(config.app.downloadWaitTime);
	}
	propagate() {
		browser.execute(() => {
			$('.resource-input-summary .resource-header .toolbar-actions .propagate-downstream')
				.trigger('mouseover');
		});
		browser.pause(config.app.waitTime);
		Resource.propagateDownstreamIcon.moveToObject();
		browser.pause(config.app.waitTime);
		Resource.propagateDownstreamIcon.click();
		browser.pause(config.app.waitTime);
	}
	delete() {
		browser.execute(() => {
			$('.resource-input-summary .resource-header .toolbar-actions .remove-component')
				.trigger('mouseover');
		});
		browser.pause(config.app.waitTime);
		Resource.removeComponentIcon.moveToObject();
		browser.pause(config.app.waitTime);
		Resource.removeComponentIcon.click();
		browser.pause(config.app.waitTime);
		Resource.removeEntity.click();
		browser.pause(config.app.waitTime);
	}

}

export default new crudComponent();