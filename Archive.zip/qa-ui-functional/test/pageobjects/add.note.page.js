import Note from '../pageobjects/comment.page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const errMsg = 'element was not loaded';


class addNote {

	add(note) {
		browser.waitForElement(Note.designNotesTab, config.app.waitTime,
			`DesignNotesTab ${errMsg}`);
		Note.designNotesTab.click();
		Note.addComment.setValue(note);
		browser.waitForElement(Note.saveComment, config.app.waitTime,
			`SaveNote ${errMsg}`);
		Note.saveComment.click();
		browser.pause(config.app.waitTime);
	}

}

export default new addNote();