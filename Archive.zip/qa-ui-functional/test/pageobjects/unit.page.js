import Page from './page';
import Home from './home.page';
import waitForElement from '../helpers/wait_for_element';

const config = require('config');
const errMsg = 'element was not loaded';


class Unit extends Page {

	create(name) {

		browser.waitForElement(Home.openLeftNav,
			config.app.waitTime, `openLeftNav ${errMsg}`);
		Home.openLeftNav.click();
		browser.waitForElement(this.unitLibraryLink,
			config.app.waitTime, `unitLibraryLink ${errMsg}`);
		this.unitLibraryLink.click();
		browser.waitForElement(this.createUnitLink,
			config.app.waitTime, `createUnitLink ${errMsg}`);
		this.createUnitLink.click();
		browser.waitForElement(this.unitName,
			config.app.waitTime, `unitNameInputField ${errMsg}`);
		this.unitName.setValue(name);
		browser.waitForElement(this.symbol,
			config.app.waitTime, `unit symbol input field ${errMsg}`);
		this.symbol.setValue(name);
		browser.waitForElement(this.definition,
			config.app.waitTime, `unit definition input field ${errMsg}`);
		this.definition.setValue(name);
		browser.pause(config.app.waitTime);
		Home.actionButton.click();
		browser.pause(config.app.waitTime);

	}

	get unitLibraryLink() {
		return $('a*=Units');
	}

	get createUnitLink() {
		return $('span*=Create Unit');
	}

	get unitName() {
		return $('.unit-name');
	}

	get nameFieldInDuplicate() {
		return $('.form-control.unit-name-field');
	}

	get symbol() {
		return $('.unit-symbol');
	}

	get definition() {
		return $('.unit-def');
	}

	get duplicateUnitConfirm() {
		return $('.btn.default-button.duplicate-button');
	}

}

export default new Unit();