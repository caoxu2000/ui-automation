import Page from './page';
import waitForElement from '../helpers/wait_for_element';

const config = require('config');
const errMsg = 'element was not loaded';


class Experiment extends Page {

	get dataDropdown() { return $('.process-info.experiment-data-menu'); }
	get exportFromThisExperiment() {
		return $('span*=Export Data From This Experiment');
	}
	get exportFromAllExperiments() {
		return $('span*=Export Data From All Experiments');
	}
	get exportFileName() { return $('.experiment-data-name'); }
	get beginExport() { return $('.btn.export-data'); }
	get downloadIcon() { return $('.fa.fa-download'); }
	get experimentLnk() {
		return $('.process-info.experiment-menu.ready');
	}
	get createExptLnk() {
		return $('.expanded-dropdown-menu-actions td:nth-child(1)');
	}
	get measureTopNav() { return $('.mode-menu.measure'); }
	get moveToTrash() { return $('a*=Move to Trash'); }
	get confirmDeletion() { return $('.purge-button'); }
	get confirmDeleteMsg() { return $('.library-purge-entity > h4'); }
	get summaryLink() { return $('.title'); }
	get summaryInputField() { return $('.summary'); }
	get summaryUpdateBtn() { return $('.update-experiment-edits'); }
	get experimentName() { return $('.experiment-summary-title-edit'); }
	get appTitle() { return $('.app-title-text.title'); }
	get deleteIcon() { return $('.delete-comment'); }

	get createExptBtn() { return $('.modal-dialog .action-button'); }

	get exptName() { return $('.experiment-name-field'); }
	get exptPurpose() { return $('.experiment-purpose-field'); }

	get openDropDown() { return $('.mode-menu.organize'); }
	get duplicateContextMnu() {
		return $('a*=Duplicate');
	}
	get duplicateExperimentLink() {
		return $('a*=Duplicate Experiment');
	}
	get duplicateBtn() { return $('.duplicate-button'); }
	get cancelBtn() { return $('.cancel-button'); }

	runTableRow(tr_index, td_index) { 
		return $(`.resource-details-table tbody > 
			tr:nth-child(${tr_index}) > td:nth-child(${td_index})`);
	}
	get firstRunSecondCol() {
		return $('.resource-details-table tbody > tr:nth-child(1) > td:nth-child(2)');
	}
	get trashLeftNav() { return $('a*=Trash'); }
	get firstExperimentInLibrary() {
		return $('tr.library-table-row:nth-of-type(1) > td:nth-of-type(1)');
	}
	get restoreContextMenu() { return $('a*=Restore'); }
	get confirmRestoreBtn() {
		return $('.purge-button.action-button');
	}
	get allLeftNav() { return $('a*=All'); }
	get dupExpRow() { return $('td*=duplicate'); }
	get deletePermanentlyContextMenu() { return $('a*=Delete Permanently'); }
	get confirmButton() {
		return $('.default-button.action-button')
	}
	get shareWithAllUsers() {
		return $('input.experiment-inherit-access');
	}

	create(expName, shared = true) {
		browser.waitForElement(this.experimentLnk, config.app.waitTime,
			`ExperimentLnk ${errMsg}`);
		this.experimentLnk.click();
		browser.waitForElement(this.createExptLnk, config.app.waitTime,
			`createExptLnk ${errMsg}`);
		this.createExptLnk.click();
		browser.waitForElement(this.exptName, config.app.waitTime,
			`exptName ${errMsg}`);
		this.exptName.setValue(expName);
		this.exptPurpose.setValue(`${expName} by test automation`);
		if (!shared) {
			this.shareWithAllUsers.click();
		}
		this.createExptBtn.click();
		browser.pause(config.app.waitTime);
	}
}

export default new Experiment();