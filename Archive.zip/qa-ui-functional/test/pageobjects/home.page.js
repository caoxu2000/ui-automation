import Page from './page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const errMsg = 'element was not loaded';
const noSearchResultsFound = 'No search results found.';


class Home extends Page {

	get loginUserName() { return $('.user-name .name'); }
	get createProcessLink() { return $('.create-entity.create-Process'); }
	get libraryTable() { return $('.library-browse-table'); }
	get appTitleText() { return $('.app-title-text.title'); }
	get sideBar() { return $('.side-bar'); }
	get openLeftNav() { return $('span*=Open'); }
	get actionButton() { return $('.default-button.action-button'); }
	get closeModal() { return $('.close.cancel-button'); }
	get open() { return $('a*=Open'); }
	get rename() { return $('a*=Rename'); }
	get duplicate() { return $('a*=Duplicate'); }
	get delete() { return $('a*=Delete'); }
	get share() { return $('.context-menu-item.action.enabled:nth-of-type(5)'); }
	get shareTag() { return $('.context-menu-item.action.enabled:nth-of-type(3)'); }
	get removeFromMyLibrary() { return $('a*=Remove from my library'); }
	get duplicateConfirmButton() { return $('.btn.default-button.duplicate-button'); }
	get inactiveTab() { return $('.tab.inactive'); }

	get removeCollaboratorX() { return $('.remove-collaborator'); }

	get searchUserBox() { return $('.search-box.search-box-text'); }
	get selectFirstUser() { return $('.-autocomplete-container > ul > li:nth-child(1)'); }
	get userRoleDropDown() { return $('.role-item'); }
	get shareBtn() { return $('.send-invitation'); }
	get shareContextMenu() {
		return $('.context-menu-item.action.enabled:nth-of-type(7)');
	}
	get confirm() { return $('.btn.default-button.action-button'); }
	get searchInputField() { return $('.input-search.form-control'); }
	get searchResults() { return $('.library-table-empty-row > .no-results'); }
	get noSearchResults() { return $('.no-results'); }
	get clearSearch() { return $('.btn-clear-search'); }
	get nameTD() { return $('td.library-name'); }
	get userRoleTD() { return $('td.library-user-role'); }
	get all() { return $('a*=All'); }
	get createdByMe() { return $('a*=Created by me'); }
	get sharedWithMe() { return $('a*=Shared with me'); }
	get sharedWithRiffyn() { return $('a*=Shared with Riffyn'); }
	get public() { return $('a*=Public'); }
	get trash() { return $('a*=Trash'); }
	get libraryTableTRs() { return $('.library-table.table tbody > tr'); }
	get libraryTable1stTR1stTD() {
		return $('.library-table.table tbody > tr:nth-child(1) > td:nth-child(1)');
	}
	get libraryRow() {
		return $('.library-table-row');
	}
	get libraryEmptyRow() {
		return $('.library-table-empty-row');
	}
	get autoComplete1stListItem() {
		return $('ul.-autocomplete-list > li');
	}
	get makePublic() { return $('.make-public'); }
	get overlay() { return $('.modal-overlay.library-modal.showing'); }

	removeCollaborator() {

		browser.execute(() => {
			$('.remove-collaborator').trigger('mouseover');
		});
		browser.pause(config.app.waitTime);
		this.removeCollaboratorX.moveToObject();
		browser.pause(config.app.waitTime);
		this.removeCollaboratorX.click();
		browser.pause(config.app.waitTime);

	}
	searchAndAssert(name) {

		browser.waitForElement(this.searchInputField, config.app.waitTime,
			`Search Input Field ${errMsg}`);
		this.searchInputField.setValue(name);
		browser.keys(['Enter']);
		browser.waitForElement($(`td*=${name}`),
			config.app.waitTime, `Test Row ${name} ${errMsg}`);
		expect(this.nameTD.getText()).to.equal(name);
		browser.pause(config.app.waitTime);

	}
	searchAndAssertUserRole(name, role = 'admin') {
		browser.waitForElement(this.searchInputField, config.app.waitTime,
			`Search Input Field ${errMsg}`);
		this.searchInputField.setValue(name);
		browser.keys(['Enter']);
		browser.waitForElement($(`td*=${name}`),
			config.app.waitTime, `Test Row ${name} ${errMsg}`);
		expect(this.nameTD.getText()).to.equal(name);
		expect(this.userRoleTD.getText()).to.equal(role);
		browser.pause(config.app.waitTime);
	}
	searchAndNotFound(name) {

		browser.waitForElement(this.searchInputField,
			config.app.waitTime, `Search Input in Any Entity Library ${errMsg}`);
		this.searchInputField.setValue(name);
		browser.keys(['Enter']);
		browser.pause(config.app.waitTime);
		expect($(`td*=${name}`).isExisting()).to.be.false;
		expect(this.noSearchResults.isExisting()).to.be.true;
    expect(this.noSearchResults.getText()).to.equal(noSearchResultsFound);

	}
	deleteTestRow(name) {

		browser.waitForElement(this.delete, config.app.waitTime,
			`Delete Menu ${errMsg}`);
		$('a*=Delete').click();
		browser.waitForElement(this.actionButton,
			config.app.waitTime, `Delete Button ${errMsg}`);
		this.actionButton.click();
		browser.pause(config.app.waitTime);
		expect($(`td*=${name}`).isExisting()).to.be.false;

	}

	shareToPublic() {
		browser.waitForElement(this.makePublic,
			config.app.waitTime, `Share to Public ${errMsg}`);
		this.makePublic.click();
	}

	shareToRiffynAndPublic(name) {

		browser.waitForElement(this.searchInputField, config.app.waitTime,
			`Search Input Field ${errMsg}`);
		this.searchInputField.setValue(name);
		browser.keys(['Enter']);
		browser.pause(config.app.waitTime);
		browser.waitForElement($(`td*=${name}`),
			config.app.waitTime, `Test Row ${name} ${errMsg}`);
		$(`td*=${name}`).rightClick();
		browser.waitForElement(this.shareTag,
			config.app.waitTime, `Share on the Context Menu ${errMsg}`);
		this.shareTag.click();
		this.shareToPublic();
		browser.waitForElement(this.searchUserBox,
			config.app.waitTime, `User or Group Search field ${errMsg}`);
		this.searchUserBox.setValue('Riffyn');
		browser.pause(config.app.waitTime);
		browser.waitForElement(this.selectFirstUser,
			config.app.longerWait, `First user in autocomplete ${errMsg}`);
		this.selectFirstUser.click();
		browser.pause(config.app.waitTime);
		this.shareBtn.click();
		browser.waitForElement(this.confirm,
			config.app.longerWait, `Confirm sharing ${errMsg}`);
		this.confirm.click();

	}

}

export default new Home();