import Process from './process.page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const errMsg = 'element was not loaded';


class MainMenu {

	get dropdown() { return $('.mode-menu'); }

	get duplicateLnk() {
		return $('a*=Duplicate');
	}

	get dupMenu() {
		return $('.context-items.dropdown-menu > li:nth-child(5)');
	}

	get contextOverlay() {
		return $('.context-overlay.showing');
	}

	get moveToTrash() {
		return $('a*=Move to Trash');
	}
	get shareLnk() { return $('a*=Share'); }

	get shareable() { return $('.share-settings input'); }

	get collaboratorRole() {
		return $('.allowed-collaborators tr > td:nth-child(3) select');
	}

	shareWithRole(who, role, shared = true) {

		browser.waitForElement(this.dropdown,
			config.app.waitTime, `Design Upper Left Menu ${errMsg}`);
		this.dropdown.click();
		browser.waitForElement(this.shareLnk,
			config.app.waitTime, `Share Process Menu ${errMsg}`);
		this.shareLnk.click();
		browser.waitForElement(Process.searchUserBox,
			config.app.waitTime, `Search User Box ${errMsg}`);
		Process.searchUserBox.setValue(who);
		browser.waitForElement(Process.selectFirstUser,
			config.app.waitTime, `First User In Search Results ${errMsg}`);
		Process.selectFirstUser.click();
		browser.waitForElement(Process.userRoleDropDown,
			config.app.waitTime, `User Role DropDown ${errMsg}`);
		Process.userRoleDropDown.selectByValue(role);
		if (who == 'riffyn.test.2' && shared) {
			browser.waitForElement(this.shareable,
				config.app.waitTime, `Shareable checkbox ${errMsg}`);
			this.shareable.click();
		}
		browser.waitForElement(Process.shareBtn,
			config.app.waitTime, `Share Button ${errMsg}`);
		Process.shareBtn.click();
		browser.pause(config.app.waitTime);
		Process.confirmationBtn.click();
		browser.pause(config.app.waitTime);

	}
}

export default new MainMenu();