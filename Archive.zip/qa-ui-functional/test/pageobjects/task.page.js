import Comment from '../pageobjects/comment.page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const errMsg = 'element was not loaded';


class Task {

	addTask(text) {
		browser.waitForElement(Comment.infoTab, config.app.waitTime,
			`InfoTab ${errMsg}`);
		Comment.infoTab.click();
		Comment.addTaskBtn.click();
		Comment.stepText.setValue(text);
		browser.waitForElement(Comment.saveTaskBtn, config.app.waitTime,
			`SaveTask Button ${errMsg}`);
		Comment.saveTaskBtn.click();
		browser.pause(config.app.waitTime);
	}
	delete2ndTask() {
		this.rightClick2ndTaskStepMenu();
		browser.waitForElement(Comment.deleteTask, config.app.waitTime,
			`deleteTask trash icon ${errMsg}`);
		Comment.deleteTask.click();
		browser.pause(config.app.downloadWaitTime);
	}
	delete1stTask() {
		this.rightClick1stTaskStepMenu();
		browser.waitForElement(Comment.deleteTask, config.app.waitTime,
			`deleteTask trash icon ${errMsg}`);
		Comment.deleteTask.click();
		browser.pause(config.app.downloadWaitTime);
	}
	rightClick1stTaskStepMenu() {
		browser.execute(() => {
			$('.procedure-step.view:nth-child(1) .procedure-step-menu').trigger('mouseover');
		});
		browser.pause(config.app.waitTime);
		Comment.firstTaskStepMenu.moveToObject();
		browser.pause(config.app.waitTime);
		Comment.firstTaskStepMenu.click();
	}
	rightClick2ndTaskStepMenu() {
		browser.execute(() => {
			$('.procedure-step.view:nth-child(2) .procedure-step-menu').trigger('mouseover');
		});
		browser.pause(config.app.waitTime);
		Comment.secondTaskStepMenu.moveToObject();
		browser.pause(config.app.waitTime);
		Comment.secondTaskStepMenu.click();
	}
	make2ndTaskLast() {
		this.rightClick2ndTaskStepMenu();
		browser.waitForElement(Comment.makeTaskLast, config.app.waitTime,
			`makeTaskLast Menu ${errMsg}`);
		Comment.makeTaskLast.click();
		browser.pause(config.app.waitTime);
	}
	make2ndTaskFirst() {
		this.rightClick2ndTaskStepMenu();
		browser.waitForElement(Comment.makeTaskFirst, config.app.waitTime,
			`makeTaskFirst ${errMsg}`);
		Comment.makeTaskFirst.click();
		browser.pause(config.app.waitTime);
	}
	rightClickGotoInstructionMenu() {
		browser.execute(() => {
			$('.go-to-instruction.design').trigger('mouseover');
		});
		browser.pause(config.app.waitTime);
		Comment.contextMenuCrossSteps.moveToObject();
		browser.pause(config.app.waitTime);
		Comment.contextMenuCrossSteps.click();
	}
	removeAllCrossStepLinks() {
		this.rightClickGotoInstructionMenu();
		browser.waitForElement(Comment.removeAllCrossStepLinks, config.app.waitTime,
			`removeAllCrossStepLinks ${errMsg}`);
		Comment.removeAllCrossStepLinks.click();
		browser.pause(config.app.downloadWaitTime);
	}
	removeMedia() {
		browser.execute(() => {
			$('.media-content.view').trigger('mouseover');
		});
		browser.pause(config.app.waitTime);
		Comment.removeMedia.moveToObject();
		browser.pause(config.app.waitTime);
		Comment.removeMedia.click();
	}
	downloadMedia() {
		browser.execute(() => {
			$('.media.image').trigger('mouseover');
		});
		browser.pause(config.app.waitTime);
		Comment.downloadMedia.moveToObject();
		browser.pause(config.app.waitTime);
		Comment.downloadMedia.click();
		browser.pause(config.app.waitTime);
		if (Comment.confirm.isExisting()) {
			Comment.confirm.click();
			browser.execute(() => {
				$('.media.image').trigger('mouseover');
			});
			browser.pause(config.app.waitTime);
			Comment.downloadMedia.moveToObject();
			browser.pause(config.app.waitTime);
			Comment.downloadMedia.click();
		}
		browser.pause(config.app.downloadWaitTime);
		
	}
}

export default new Task();