import Page from './page';
import Home from './home.page';
import Property from './property.page';
import Resource from './resource.page';
import waitForElement from '../helpers/wait_for_element';

const config = require('config');
const errMsg = 'element was not loaded';


class ResourceType extends Page {

	create(resourceTypeName, propertyName, componentName) {

		browser.waitForElement(Home.openLeftNav,
			config.app.waitTime, `openLeftNav ${errMsg}`);
		Home.openLeftNav.click();
		browser.waitForElement(this.resourceTypeLink,
			config.app.waitTime, `Resource Type Menu ${errMsg}`);
		this.resourceTypeLink.click();
		browser.waitForElement(this.createResourceTypeLink,
			config.app.waitTime, `Create Resource Type Link ${errMsg}`);
		this.createResourceTypeLink.click();
		browser.waitForElement(this.resourceTypeNameInput,
			config.app.waitTime, `Resource Type Name Input ${errMsg}`);
		this.resourceTypeNameInput.setValue(resourceTypeName);
		this.addPropertyToResource(propertyName);
		this.addComponentToResource(componentName);
		browser.pause(config.app.waitTime);
		this.save.click();

	}
	
	get resourceTypeLink() { return $('a*=Resource Types'); }
	get createResourceTypeLink() {
		return $('span*=Create Resource Type');
	}
	get resourceTypeNameInput() { return $('.resource-name'); }
	
	get resourceTypeNameUpdateInput() {
		return $('.form-control.resourceType-name-field');
	}
	get dropdownMenu() {
		return $('div.name-header div.rf-menu-hook');
	}
	get addPropertyDropdownMenu() {
		return $('span*=Add Property');
	}
	get removePropertyDropdown() {
		return $('.rf-action-item.property-context-menu .rf-menu-hook');
	}
	get removePropertyContextMenu() {
		return $('span*=Remove Property');
	}
	get searchPropertiesInput() {
		return $('.search-properties #search');
	}
	get addComponentDropdownMenu() {
		return $('span*=Add Component');
	}
	get searchResourcesInput() {
		return $('.search-resources #search');
	}
	get save() {
		return $('.save-button');
	}
	get propertyContainerElmt() {
		return $('.property-name .rf-item-name');
	}
	get componentContainerElmt() {
		return $('.component-name .rf-item-name');
	}
	get confirmAddComponent() {
		return $('.add-component-library-resource');
	}
	get saveProperty() { return $('.save-edits'); }
	addPropertyToResource(name) {

		browser.waitForElement(this.dropdownMenu, config.app.waitTime,
			`Add Property and Component Dropdown Menu ${errMsg}`);
		this.dropdownMenu.click();
		this.addPropertyDropdownMenu.click();
		browser.waitForElement(this.searchPropertiesInput, config.app.waitTime,
			`Search Properties Input ${errMsg}`);
		Property.searchProperty(name);
		this.saveProperty.click();
		browser.pause(config.app.waitTime);

	}
	addComponentToResource(name) {

		browser.waitForElement(this.dropdownMenu, config.app.waitTime,
			`Add Property and Component Dropdown Menu ${errMsg}`);
		this.dropdownMenu.click();
		this.addComponentDropdownMenu.click();
		browser.waitForElement(Resource.resourceTypeSearch, config.app.waitTime,
			`resourceTypeSearch ${errMsg}`);
		browser.waitUntil(() => {
			return Resource.resourceTypeSearch.isEnabled();
		}, config.app.waitTime, `resource search input field ${errMsg}`);
		Resource.resourceTypeSearch.setValue(name);
		browser.pause(config.app.waitTime);
		Resource.firstResource.click();
		browser.pause(config.app.waitTime);
		this.confirmAddComponent.click();
		browser.pause(config.app.waitTime);

	}

}

export default new ResourceType();