import Page from './page';
import Home from './home.page';
import waitForElement from '../helpers/wait_for_element';

const config = require('config');
const errMsg = 'element was not loaded';


class Tag extends Page {

	create(name) {

		browser.waitForElement(Home.openLeftNav,
			config.app.waitTime, `openLeftNav ${errMsg}`);
		Home.openLeftNav.click();
		browser.waitForElement(this.tagLibraryLink,
			config.app.waitTime, `tagLibraryLink ${errMsg}`);
		this.tagLibraryLink.click();
		browser.waitForElement(this.createTagLink,
			config.app.waitTime, `createTagLink ${errMsg}`);
		this.createTagLink.click();
		browser.waitForElement(this.tagName,
			config.app.waitTime, `tagNameInputField ${errMsg}`);
		this.tagName.setValue(name);
		browser.pause(config.app.waitTime);
		Home.actionButton.click();
		browser.pause(config.app.waitTime);

	}
	get tagLibraryLink() {
		return $('a*=Tags');
	}

	get createTagLink() {
		return $('span*=Create Tag');
	}

	get tagName() {
		return $('.tag-name-field');
	}

	get tagInAddRemoveTagPopup() {
		return $('.tag-container .tag-pill');
	}

}

export default new Tag();