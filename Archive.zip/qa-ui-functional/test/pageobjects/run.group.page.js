class RunGroup {

	get runGroupDropDown() {
		return $('.run-group-name');
	}

	get newRunGroup() {
		return $('span*=Create New Run Collection');
	}

	get groupName() {
		return $('.group-name');
	}

	get confirmBtn() {
		return $('.default-button.action-button');
	}

	get headerRow() { return $('.header-row'); }
	get renameCurrentGroup() { return $('span*=Rename Current Collection'); }
	get actualSingleValued() {
		return $('span*=Export Single Valued Data For Collection');
	}
	get plannedMultipleValues() {
		return $('span*=Export Planned Values For Collection');
	}
	get planMenu() {
		return $('span*=Plan');
	}
	get newRunGroupDropDown() { return $('.run-group-details'); }
	get deleteCurrentCollection() {
		return $('span*=Delete Current Collection');
	}
	get selectData() { return $('.form-control.filter-selection'); }
	get createRunPlusBtn() { return $('.btn.action-button'); }

}

export default new RunGroup();