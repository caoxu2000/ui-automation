import Experiment from '../pageobjects/experiment.page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const errMsg = 'element was not loaded';


class deleteExperiment {

	moveExperimentToTrash(name) {

		browser.url('library/experiments');
		browser.waitForElement($(`td*=${name}`),
			config.app.waitTime, `testing experiment row ${errMsg}`);
		$(`td*=${name}`).rightClick();
		browser.waitForElement(Experiment.moveToTrash,
			config.app.waitTime, `moveToTrash ${errMsg}`);
		Experiment.moveToTrash.click();
		browser.pause(config.app.waitTime);
		Experiment.confirmDeletion.click();
		browser.pause(config.app.waitTime);

	}

	deleteTestExperiment(name) {

		this.moveExperimentToTrash(name);
		this.purgeFromTrash(name);

	}

	purgeFromTrash(name) {
		
		Experiment.trashLeftNav.click();
		browser.pause(config.app.downloadWaitTime);
		$(`td*=${name}`).rightClick();
		browser.waitForElement(Experiment.deletePermanentlyContextMenu,
			config.app.waitTime, `deletePermanentlyContextMenu ${errMsg}`);
		Experiment.deletePermanentlyContextMenu.click();
		browser.waitForElement(Experiment.confirmButton,
			config.app.waitTime, `confirmButton ${errMsg}`);
		Experiment.confirmButton.click();
		browser.pause(config.app.waitTime);

	}

}

export default new deleteExperiment();