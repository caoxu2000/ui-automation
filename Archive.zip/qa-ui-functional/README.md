# UI Functional testing framework using webdriverio

# Prerequisites
- download and install Node.js: http://nodejs.org
- download and install JAVA: https://java.com/en/download/


# To Start

- $ git clone the repo: https://github.com/RiffynInc/qa-ui-functional.git
- $ cd qa-ui-functional
- $ npm install
- $ npm run eng01 // run all the UI function tests
- $ npm run eng01 -- --spec test/specs/createExperimentTests.js

