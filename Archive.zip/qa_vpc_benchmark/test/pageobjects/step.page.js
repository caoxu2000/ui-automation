import Page from './page';
import Property from './property.page';
const config = require('config');

class Step extends Page {

	get amsaWashStep() { return $('[data-name*="AMSA Wash"]'); }
	get samplingProcStep() { return $('[data-name="Sampling procedure"]'); }
	
	addAfterStep() {

		browser.execute(() => {
			$('.resource.output.unconnected').trigger('mouseover');
		});
		this.resourceOutputIcon.rightClick();
		this.addAfterStepMenu.click();
		browser.pause(config.app.waitTime);

	}

	addBeforeStep() {
		browser.execute(() => {
			$('.resource.input.unconnected').trigger('mouseover');
		});
		this.resourceInputIcon.rightClick();
		this.addBeforeStepMenu.click();
		browser.pause(config.app.waitTime);
		
	}

	get resourceOutputIcon() {
		return $('.resource.output.unconnected');
	}

	get resourceInputIcon() {
		return $('.resource.input.unconnected');
	}

	get addAfterStepMenu() {
		return $('a*=Add Step After');
	}

	get addBeforeStepMenu() {
		return $('a*=Add Step Before');
	}

	get processTopNavBar() {
		return $('.process-nav-item.crumbtrail');
	}

	get stepDescription() {
		return $('.activity-desc');
	}

	get stepBox() {
		return $('[data-name="New Base Step"] .foreground');
	}

	get firstStepBoxLabel() {
		return $('[data-name="Step 1"] .activity-label');
	}

	get unGroupNewBaseStepLabel() {
		return $('[data-name="First step of New Base Step"] .activity-label');
	}

	get addNewStepLnk() {
		return $('.btn.add-step');
	}

	get addNewBaseStepLink() { return $('.btn.add-step'); }

	get newBaseStep() { return $('[data-name="New Base Step"]'); }

	get firstStepNewBaseStep() {
		return $('[data-name="First step of New Base Step"]');
	}

	get stepOrderLabel() { return $('.step-order-label'); }

	get moveToParentGrp() { return $('a*=Move To Parent Group'); }

	get parentProcessLink() { return $('a*=UI Automated Test'); }
	
	get firstStep() { return $('[data-name*="First Step"]'); }
	
	get firstStepBox() {
		return $('[data-name*="First Step"]');
	}

	get firstStepBoxOrder() {
		return $('[data-name="Step 1"] .step-order-label');
	}

	get firstStepCopy() {
		return $('[data-name*="First Step (copy)"]');
	}
	get secondStepBox() {
		return $('[data-name*="Step 2"]');
	}

	get encloseInNewGroup() {
		return $('a*=Enclose In New Group');
	}

	get moveToAdjacentGrp() {
		return $('a*=Move To Adjacent Group');
	}

	get unGroupSteps() {
		return $('a*=Ungroup Steps');
	}

	get groupIcon() { return $('.group-link'); }

	get prevStepBox() {
		return $('[data-name="Prev Step"]');
	}
	get nextStepBox() {
		return $('[data-name="Next Step"]');
	}
	get prevStepLabel() { return $('[data-name="Prev Step"] > .step-order-label'); }
	get nextStepLabel() { return $('[data-name="Next Step"] > .step-order-label'); }

	get secondStepOutputResource() {
		return $('[data-name="Step 2"] .resource.output');
	}
	get addStepAfterLnk() { return $('a*=Add Step After'); }
	get deleteStepLnk() { return $('a*=Delete Step'); }

	get confirmation() { return $('.action-button'); }

	get newStepBox() {
		return $('.activities > .box.activity:nth-child(2)');
	}

	get defaultFirstStep() {
		return $('.activities > .box.activity:nth-child(1)');
	}

	get contextMenu() {
		return $('.context-items');
	}

	get noAccessPopup() {
		return $('.modal-content .alert-message');
	}

	get outputResourceToolbar() {
		return $('.resource-output-summary .resource-name');
	}

	get viewStepOrder() { return $('a*=View Step Order'); }
	get showStepID() { return $('a*=Show Step ID'); }
	get addInput() { return $('a*=Add Input'); }
	get addOutput() { return $('a*=Add Output'); }
	get stepOrderBubble() { return $('.step-order-item-order-bubble') }
	get secondStepOrderTableRow() { return $('.order-steps-panel tr:nth-child(2)'); }
	get stepLabel() { return $('.step-label'); }
	get deleteGroupLnk() { return $('a*=Delete Group'); }
	get duplicateMenu() {	return $('a*=Duplicate'); }

	addNewStep() {
		this.addNewStepLnk.click();
		browser.pause(config.app.waitTime);
	}
	removeNewStep() {
		this.newBaseStep.rightClick();
		this.deleteStepLnk.click();
		browser.pause(config.app.waitTime);
		this.confirmation.click();
		browser.pause(config.app.waitTime);
	}
	deleteGroup() {
		this.newBaseStep.rightClick();
		this.deleteGroupLnk.click();
		browser.pause(config.app.waitTime);
		this.confirmation.click();
		browser.pause(config.app.waitTime);
	}
	deleteStep() {
		this.newBaseStep.rightClick();
		this.deleteStepLnk.click();
		browser.pause(config.app.waitTime);
		this.confirmation.click();
		browser.pause(config.app.waitTime);
	}

}

export default new Step();