import Page from './page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const errMsg = 'element was not loaded';


class Home extends Page {

	get createProcessLink() { return $('.create-entity.create-Process'); }
	get libraryTable() { return $('.library-browse-table'); }
	get appTitleText() { return $('.app-title-text.title'); }
	get sideBar() { return $('.side-bar'); }
	get openLeftNav() { return $('span*=Open'); }
	get actionButton() { return $('.default-button.action-button'); }
	get closeModal() { return $('.close.cancel-button'); }
	get openTestRow() { return $('a*=Open'); }
	get searchInputField() { return $('.input-search.form-control'); }
	get searchResults() { return $('.library-table-empty-row > .no-results'); }
	get libraryRow() {
		return $('.library-table-row');
	}
	get libraryEmptyRow() {
		return $('.library-table-empty-row');
	}
	deleteTestRow(name) {
		$('a*=Delete').click();
		browser.waitForElement(this.actionButton,
			config.app.waitTime, `Delete Button ${errMsg}`);
		this.actionButton.click();
		browser.pause(config.app.waitTime);
		expect($(`td*=${name}`).isExisting()).to.be.false;

	}

}

export default new Home();