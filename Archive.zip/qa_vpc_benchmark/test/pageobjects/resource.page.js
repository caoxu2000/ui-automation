import Page from './page';
import waitForElement from '../helpers/wait_for_element';

const config = require('config');
const errMsg = 'element was not loaded';


class Resource extends Page {

	get outputResourceNameUnassigned() {
		return $('.resource-output-summary div.resource-name');
	}
	get removeEntityConfirm() {
		return $('.remove-entity');
	}
	get addProperty() {
		return $('.resource-output-summary .resource-header .toolbar-actions .add-property');
	}
	get removeProperty() {
		return $('.resource-output-summary .resource-property .toolbar-actions .remove-property');
	}
	get propagateDownstream() {
		return $('.resource-output-summary .resource-property .toolbar-actions .propagate-downstream');
	}
	get propertyName() { return $('.resource-output-summary div.property-name'); }
	get assignResourceLnk() {
		return $('tr.data-table-row > td:nth-child(6) > .rf-resource-status-container');
	}

	get step2Box() {
		return $('[data-name="Step 2"] rect:nth-child(1)');
	}

	get createRunInput() {
		return $('.run-name-field');
	}

	get resourceValue() {
		return $('tr.data-table-row:nth-of-type(1) > td:nth-child(6) > .rf-resource-put');
	}

	get createNewResource() {
		return $('.btn.define-resource > .create-new-icon');
	}

	get resourceName() {
		return $('input[data-id="resource_name"]');
	}

	get createResourceBtn() {
		return $('.create-resource');
	}

	get assignResourceBtn() {
		return $('.assign-all');
	}
	get addComponent() {
		return $('.resource-actions .add-component');
	}
	get changeComponent() {
		return $('.resource-actions .change-component');
	}
	get componentName() { return $('.component-name'); }
	get addComponentIcon() {
		return $('.resource-input-summary .resource-header .toolbar-actions .add-component');
	}
	get changeComponentIcon() {
		return $('.resource-input-summary .resource-component .toolbar-actions .change-component');
	}
	get propagateDownstreamIcon() {
		return $('.resource-input-summary .resource-component .toolbar-actions .propagate-downstream');
	}
	get removeComponentIcon() {
		return $('.resource-input-summary .resource-component .toolbar-actions .remove-component');
	}
	get removeEntity() { return $('.remove-entity'); }
	get resourceTypeSearch() { return $('#search'); }
	get firstResource() { return $('ul.-autocomplete-list > li'); }
	get airCompressorSearchOption() { return $('li*=air compressor'); }
	get addResourceTypeToStep() { return $('.default-button.add-to-activity'); }
	get changeResourceTypeSubmit() { return $('.default-button.change-resource'); }
	get defaultResourceTD() {
		return $('.resource-input-summary table.resource-summary-set > tbody > tr:first-child > td:first-child');
	}
	get changeResourceTypeIcon() {
		return $('.resource-input-summary .resource-header .toolbar-actions .change-resource');
	}
	get copyToOutputIcon() {
		return $('.resource-input-summary .resource-definition tr:nth-child(2) .toolbar-actions .copy-input');
	}
	get inputFirstResource() {
		return $('.resource-input-summary table.resource-summary-set tr:first-child td.resource-header-name:first-child');
	}
	get inputSecondResource() {
		return $('.resource-input-summary table.resource-summary-set tr:nth-child(2) td.resource-header-name:first-child');
	}
	get outputSecondResource() {
		return $('.resource-output-summary table.resource-summary-set tr:nth-child(2) td.resource-header-name:first-child');
	}
	get outputComponent() {
		return $('.resource-output-summary table.resource-summary-set tr.resource-component .component-name');
	}
	get secondResourceRemoveIcon() {
		return $('.resource-output-summary tbody.resource-definition tr:nth-child(2) td:nth-child(2) div.toolbar-actions button.remove-resource');
	}
	searchResource(resourceName) {
		browser.waitForElement(this.resourceTypeSearch, config.app.waitTime,
			`resourceTypeSearch ${errMsg}`);
		browser.waitUntil(() => {
			return this.resourceTypeSearch.isEnabled();
		}, config.app.waitTime, `resource search input field ${errMsg}`);
		this.resourceTypeSearch.setValue(resourceName);
		browser.pause(config.app.waitTime);
		this.firstResource.click();
		browser.pause(config.app.waitTime);
	}
	addResource(resourceName) {
		browser.pause(config.app.waitTime);
		this.searchResource(resourceName);
		this.addResourceTypeToStep.click();
		browser.pause(config.app.waitTime);
	}
	changeResourceType(resourceName) {
		browser.execute(() => {
			$('.resource-input-summary .resource-header .toolbar-actions .change-resource').trigger('mouseover');
		});
		browser.pause(config.app.waitTime);
		this.changeResourceTypeIcon.moveToObject();
		browser.waitForElement(this.changeResourceTypeIcon, config.app.waitTime,
			`changeResourceTypeIcon ${errMsg}`);
		this.changeResourceTypeIcon.click();
		this.searchResource(resourceName);
		this.changeResourceTypeSubmit.click();
		browser.pause(config.app.waitTime);
	}
	copyToOutput(resourceName) {
		browser.execute(() => {
			$('.resource-input-summary .resource-definition tr:nth-child(2) .toolbar-actions .copy-input').trigger('mouseover');
		});
		browser.pause(config.app.waitTime);
		this.copyToOutputIcon.moveToObject();
		browser.waitForElement(this.copyToOutputIcon, config.app.waitTime,
			`copyToOutputIcon ${errMsg}`);
		this.copyToOutputIcon.click();
		browser.pause(config.app.waitTime);
	}

}

export default new Resource();