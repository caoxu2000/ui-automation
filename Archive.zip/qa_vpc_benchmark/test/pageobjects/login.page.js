import Page from './page';
import waitForElement from '../helpers/wait_for_element';

const config = require('config');
const errMsg = 'element was not loaded';

class LoginPage extends Page {

	get username() { return $('input[name="username"]'); } 
	get password() { return $('input[name="password"]'); }
	get signInBtn() { return $('.button[type="submit"]'); }
	get signOut() {
		return $('a*=Sign Out');
	}

	get logoutLnk() { return $('.user-info'); }
	get contextMenu() {
		return $('.context-items.dropdown-menu.menu-with-title.normal');
	}
	login(username, password) {
		browser.waitForElement(this.username, config.app.waitTime,
			`username ${errMsg}`);
		this.username.setValue(username);
		browser.waitForElement(this.password, config.app.waitTime,
			`password ${errMsg}`);
		this.password.setValue(password);
		this.signInBtn.click();
		browser.pause(config.app.waitTime);
	}

	logout() {
		browser.pause(config.app.waitTime);
		this.logoutLnk.click();
		browser.waitForElement(this.signOut, config.app.waitTime,
			`signOut ${errMsg}`);
		this.signOut.click();
		browser.pause(config.app.waitTime);
	}

}

export default new LoginPage();