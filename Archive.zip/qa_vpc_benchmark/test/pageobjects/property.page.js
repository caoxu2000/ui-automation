import Run from './run.page';
import Resource from './resource.page';
import waitForElement from '../helpers/wait_for_element';

const config = require('config');
const errMsg = 'element was not loaded';


class Property {

	get propertyLibraryLink() {
		return $('a*=Properties');
	}
	get createPropertyLink() {
		return $('span*=Create Property');
	}
	get propertyNameInput() {
		return $('input.property-name');
	}
	get addPropertyButton() {
		return $('button.add-property');
	}

	get addUnitSearchBox() {
		return $('#search-units');
	}
	get property3rdOption() {
		return $('ul.-autocomplete-list > li:nth-of-type(3)');
	}
	get permitted1stUnit() {
		return $('.permitted-units .unit-col.name');
	}
	get cancelPropertyButton() { return $('.cancel-property'); }

	addFirst(propertyName) {
		browser.execute(() => {
			$('.resource-output-summary .resource-header .toolbar-actions .add-property')
				.trigger('mouseover');
		});
		browser.pause(config.app.waitTime);
		Run.addProperty.moveToObject();
		browser.pause(config.app.waitTime);
		Run.addProperty.click();
		Run.findPropertySearchBox.click();
		browser.waitForElement(Run.findPropertySearchBox, config.app.waitTime,
			`findPropertySearchBox ${errMsg}`);
		Run.findPropertySearchBox.setValue(propertyName);
		browser.pause(config.app.waitTime);
		Run.propertyOption.click();
		browser.pause(config.app.waitTime);

		if (propertyName !== 'pH') {
			Run.addPropertyApply1.click();
		}
		else {
			Run.unitDropDown.click();
			browser.waitForElement(Run.editToolbar, config.app.waitTime,
				`editToolbar ${errMsg}`);
			Run.editToolbar.click();
			browser.waitForElement(Run.unitPH, config.app.waitTime,
				`unitPH ${errMsg}`);
			Run.unitPH.click();
			Run.addPropertyApply2.click();
		}
	}
	deleteFirstProperty() {
		browser.execute(() => {
			$('.resource-output-summary .resource-property .toolbar-actions .remove-property')
				.trigger('mouseover');
		});
		browser.pause(config.app.waitTime);
		Resource.removeProperty.moveToObject();
		browser.pause(config.app.waitTime);
		Resource.removeProperty.click();
		browser.pause(config.app.waitTime);
		Resource.removeEntityConfirm.click();
		browser.pause(config.app.waitTime);
	}
	propagateFirstProperty() {
		browser.execute(() => {
			$('.resource-output-summary .resource-property .toolbar-actions .propagate-downstream')
				.trigger('mouseover');
		});
		browser.pause(config.app.waitTime);
		Resource.propagateDownstream.moveToObject();
		browser.pause(config.app.waitTime);
		Resource.propagateDownstream.click();
		browser.pause(config.app.waitTime);
	}
}

export default new Property();