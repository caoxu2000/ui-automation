import Page from './page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const errMsg = 'element was not loaded';


class Run extends Page {

	get runTableRow() { return $('.data-table-row'); }
	
	get collectionItem() {
		return $('.item.hide-btn');
	}
	get collectionItemName() {
		return $('.text.nameColumn');
	}
	get collectionExpansionToggle() {
		return $('.expansion-toggle');
	}
	get deleteRunsIcon() {
		return $('.fa-trash');
	}
	get headerRowToggleBox() {
		return $('.header-row .toggle-box.select-none');
	}
	get resourceName() { return $('.resource-name'); }
	get resourceEditHeader() {
		return $('.resource-summary-set header edit');
	}
	get editToolbar() { return $('.property-edit-tools'); }
	get runTable() { return $('.data-table'); }
	get unitPH() { return $('option[value="ph"]'); }
	get unitDropDown() {
		return $('.unit-item.form-control');
	}
	get numericResource() {
		return $('div[title="pH"]');
	}
	get textResource() {
		return $('div[title="tag"]');
	}
	get dateResource() {
		return $('div[title="date/time"]');
	}
	get formulaEditor() {
		return $('a*=Formula editor');
	}

	get formulaInput() {
		return $('.calculated-formula');
	}

	get updateFormulaBtn() {
		return $('.formula-editor-footer > .action-button');
	}

	get calculationBtn() { return $('.calculation-button'); }
	get calculatedResultCell() { return $('.calculated.has-single-value'); }

	get pH8() {
		return $('tr.data-table-row:nth-of-type(1) td:nth-child(8) > input');
	}
	get pH9() {
		return $('tr.data-table-row:nth-of-type(1) td:nth-child(9) > input');
	}
	get secondRunPH8() {
		return $('tr.data-table-row:nth-of-type(2) td:nth-child(8) > input');
	}
	get resourceName() {
		return $('tr.data-table-row:nth-of-type(1) td:nth-child(6) > input');
	}
	get runName() {
		return $('tr.data-table-row:nth-of-type(1) td:nth-child(3) > input');
	}
	get multiValueCell() {
		return $('tr.data-table-row:nth-of-type(1) td:nth-child(8) > div.display-value > i.fa.fa-table');
	}
	get firstMultiValuePH() {
		return $('.htCore tr:nth-of-type(1) td.isOutput');
	}
	get secondMultiValuePH() {
		return $('.htCore tr:nth-of-type(2) td.isOutput');
	}
	
	get firstRunPH() {
		return $('tr.data-table-row:nth-of-type(1) td:nth-child(8) > input');
	}
	get firstRunName() {
		return $('tr.data-table-row:nth-of-type(1) td:nth-child(3) > input');
	}
	get sixthRunName() {
		return $('tr.data-table-row:nth-of-type(6) > td.run-name > input');
	}
	get firstRunResource() {
		return $('tr.data-table-row:nth-of-type(1) td:nth-child(6) > input');
	}

	get runFillDownBtn() {
		// return $('button[data-original-title="Fill Down"]');
		return $('.action-button-strip > button.update-run-status:nth-child(2)');
	}
	get checkAllCheckbox() { return $('.toggle-box'); }
	get checkAllRuns() {
		return $('.header-row .toggle-box.select-none');
	}
	get checkBoxesForAllRuns() { return $('.data-table-row .toggle-box.select-none'); }
	get trash() { return $('.fa-trash'); }
	get confirmBtn() { return $('.footer-buttons > button:nth-of-type(2)'); }
	get uploadIcon() { return $('button.upload-data-file'); }
	get fileUploadIcon() { return $('.btn.action-button.query-data-source'); }
	get modifyRun() {
		return $('.rf-experiement-editor-panel-toolbar > .rf-panel-option.ad-hoc');
	}
	get actualRun() { return $('.rf-mode.inactive:nth-of-type(2) span:nth-of-type(2)'); }
	get addProperty() {
		return $('.resource-output-summary .resource-header .toolbar-actions .add-property');
	}
	get removeProperty() {
		return $('.resource-output-summary .resource-property .toolbar-actions .remove-property');
	}
	get propertyOption() {
		return $('ul.-autocomplete-list > li');
	}
	get findPropertySearchBox() { return $('#search'); }
	get addPropertyApply1() { return $('.save-edits.qualitative'); }
	get addPropertyApply2() { return $('.save-edits.quantitative'); }
	get step1() { return $('.activities > .box.activity:nth-child(1)'); }
	
	get anchorOfFirstStep() {
		return $('[data-name="First Step"] .anchor-link .hit-area');
	}
	get firstStepFirstRunCheckBox() {
		return $('.first-step .data-table-row:nth-of-type(1) .toggle-box:nth-of-type(1)');
	}
	get nextStepFirstRunCheckBox() {
		return $('.final-step .data-table-row:nth-of-type(1) .toggle-box:nth-of-type(1)');
	}
	get firstRunResourceOutput() {
		return $('.first-step .data-table-row:nth-of-type(1) .rf-resource-put:nth-of-type(1)');
	}
	get finalRunResourceInput() {
		return $('.final-step .data-table-row:nth-of-type(1) .rf-resource-put:nth-of-type(1)');
	}
	get nextStepFirstRunCheckBox() {
		return $('.final-step .data-table-row:nth-of-type(1) .toggle-box:nth-of-type(1)');
	}
	get connectionActionBtn() {
		return $('.run-propagation-connect-action-button');
	}
	get firstRunRows() { return $('.data-table-row:nth-of-type(1)'); }
	get runTypeDropDown() { return $('.form-control.run-type'); }
	get disconnectRuns() {
		return $('.toolbar-actions button:nth-child(3)');
	}
	get confirmation() {
		return $('.btn.default-button.action-button');
	}
	get allRunTRs() {
		return $('.resource-details-table tbody > tr');
	}

	deleteTestRuns() {

		this.headerRowToggleBox.click();
		browser.waitForElement(this.deleteRunsIcon, config.app.waitTime,
			`deleteRunsIcon ${errMsg}`);
		this.deleteRunsIcon.click();
		browser.waitForElement(this.confirmation, config.app.waitTime,
			`confirmation ${errMsg}`);
		this.confirmation.click();
		browser.pause(config.app.downloadWaitTime);

	}

}

export default new Run();