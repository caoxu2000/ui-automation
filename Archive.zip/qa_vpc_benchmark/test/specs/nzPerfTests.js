import LoginPage from '../pageobjects/login.page';
import Step from '../pageobjects/step.page';
import Run from '../pageobjects/run.page';
import waitForElement from '../helpers/wait_for_element';
const fs = require('fs');
const config = require('config');
const errMsg = 'element was not loaded';
let moment = require('moment');

let perf1, perf2, tableRows, stream, csv, today,
		firstStep6thRunName, sixthStep6thRunName, timeOutMsg;

csv = 'test-results/nzperf.csv';
stream = fs.createWriteStream(csv, { flags: 'a'});
firstStep6thRunName = 'JX-3B-0011';
sixthStep6thRunName = 'ADP-1-F1-swatch1-F1';
timeOutMsg = 'waited 20 seconds but expected text did not show up';

const recordTime = runName => {

	const start = new Date();
	browser.waitUntil(() => {
		Run.sixthRunName.waitForExist();
		return Run.sixthRunName.getValue() === runName;
	}, config.app.waitTimeOut, timeOutMsg);
	const end = new Date();
	const perf = (end - start) / 1000;
	return perf;

};

describe('NZ Perf Test', () => {

	it('should load the page with maximum 60 sec wait time', () => {

		LoginPage.login(config.app.admin.username, config.app.admin.password);

		try {
			browser.url('experiments/L7Pky3dGG63nskCcs');
			perf1 = recordTime(firstStep6thRunName);
			Step.amsaWashStep.click();
			perf2 = recordTime(sixthStep6thRunName);
			today = moment().utc().format('YYYY-MM-DD HH:mm');
			stream.write(`${today},${perf1},${perf2}\n`);
		}
		catch(error) {
			console.error(error);
		}

	});

});