import LoginPage from '../pageobjects/login.page';
import Step from '../pageobjects/step.page';
import Run from '../pageobjects/run.page';
import waitForElement from '../helpers/wait_for_element';
const config = require('config');
const fs = require('fs');
const errMsg = 'element was not loaded';
let moment = require('moment');

let perf1, perf2, tableRows, stream, csv, today,
		fourthStep6thRunName, seventhStep6thRunName, timeOutMsg;

csv = 'test-results/appperf.csv';
stream = fs.createWriteStream(csv, { flags: 'a'}); 
fourthStep6thRunName = 'HJ12';
seventhStep6thRunName = 'HJ07-06 presample';
timeOutMsg = 'waited 20 seconds but expected text did not show up';

const recordTime = runName => {

	const start = new Date();
	browser.waitUntil(() => {
		Run.sixthRunName.waitForExist();
		return Run.sixthRunName.getValue() === runName;
	}, config.app.waitTimeOut, timeOutMsg);
	const end = new Date();
	const perf = (end - start) / 1000;
	return perf;

};

describe('APP Perf Test', () => {

	it('should load the page with maximum 60 sec wait time', () => {

		LoginPage.login(config.app.admin.username, config.app.admin.password);

		try {
			browser.url('experiments/SH49SFojqiEWzgDkJ');
			perf1 = recordTime(fourthStep6thRunName);
			Step.samplingProcStep.click();
			perf2 = recordTime(seventhStep6thRunName);
			today = moment().utc().format('YYYY-MM-DD HH:mm');
			stream.write(`${today},${perf1},${perf2}\n`);
		}
		catch(error) {
			console.error(error);
		}

	});

});