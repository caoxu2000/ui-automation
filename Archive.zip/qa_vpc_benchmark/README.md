# Benchmark clients' VPC page load performance

# Prerequisites
- download and install Node.js: http://nodejs.org
- download and install JAVA: https://java.com/en/download/

# Configuration and directory structure
- All the clients' VPC main urls are store in config/
- Test result .csv, .log files are stored in test-results/ which
  will be generated when you run the test

# To Start

- $ git clone the repo: https://github.com/RiffynInc/qa_vpc_benchmark.git
- $ cd qa_vpc_benchmark
- $ npm install
- $ npm run nz -- --spec test/specs/nzPerfTests.js

