#!/bin/sh

cd ~/Desktop/qa_vpc_benchmark
. ~/.nvm/nvm.sh
npm run nz -- --spec test/specs/nzPerfTests.js
pgrep -a java | xargs kill -9
npm run app -- --spec test/specs/appPerfTests.js
pgrep -a java | xargs kill -9