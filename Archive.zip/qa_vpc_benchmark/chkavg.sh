#!/bin/sh

cd ~/Desktop/qa_vpc_benchmark
. ~/.nvm/nvm.sh
node checkaverage.js