const readLastLines = require('read-last-lines');
const nodemailer = require('nodemailer');
const lastNumOfLines = 8;
const file1 = './test-results/nzperf.csv';
const file2 = './test-results/appperf.csv';
const from = 'riffynqa@gmail.com';
const to = 'xcao@riffyn.com';
const pass = '54321.Quality';
const threshold = 20;
const subject = `Last 8 Runs Average > ${threshold}% for nz and app`;
const nzBaselineAvg = { "avg1": 3.690, "avg2": 7.844 };
const appBaselineAvg = { "avg1": 3.584, "avg2": 7.538 };

const transporter = nodemailer.createTransport({
  service: 'gmail',
  auth: {
    user: from,
    pass: pass
  }
});

const isGreaterThanThreshold = (actual, expected) => {
	let variation = Math.abs(actual - expected) / expected * 100;
	// console.log(variation);
	if (variation > threshold) {
		return true;
	} else {
		return false;
	}
};

const avg = (file, lastNumOfLines) => {
	return readLastLines.read(file, lastNumOfLines)
		.then(lines => {
			let perfArray = [];
			let step1 = [];
			let step2 = [];
			perfArray = lines.split('\n');

			for (let i = 0; j = perfArray.length - 1, i < j; i++) {
				let temp = perfArray[i].split(',');
				step1.push(parseFloat(temp[1]));
				step2.push(parseFloat(temp[2]));
			}
			let sum1 = step1.reduce((a, b) => a + b, 0);
			let sum2 = step2.reduce((a, b) => a + b, 0);
			let avg1 = (sum1 / (perfArray.length - 1)).toFixed(3);
			let avg2 = (sum2 / (perfArray.length - 1)).toFixed(3);
			let avg = { "avg1": avg1, "avg2": avg2 };
			return avg;
		});
};

let result1 = avg(file1, lastNumOfLines);
let result2 = avg(file2, lastNumOfLines);

result1.then(avg => {
	if (isGreaterThanThreshold(avg.avg1, nzBaselineAvg.avg1) ||
			isGreaterThanThreshold(avg.avg2, nzBaselineAvg.avg2)) {
		const mailOptions = {
		  from: from,
		  to: to,
		  subject: subject,
		  text: `nz actual: { avg1: ${avg.avg1}, avg2: ${avg.avg2} }
  expected: { avg1: ${nzBaselineAvg.avg1}, avg2: ${nzBaselineAvg.avg2} }`
		};
		transporter.sendMail(mailOptions, function(error, info){
		  if (error) {
		    console.log(error);
		  } else {
		    console.log('Email sent: ' + info.response);
		  }
		});
	}
	console.log(`nz expected: { avg1: ${nzBaselineAvg.avg1}, avg2: ${nzBaselineAvg.avg2} }`);
	console.log(`nz actual: { avg1: ${avg.avg1}, avg2: ${avg.avg2} }`);
});
result2.then(avg => {
	if (isGreaterThanThreshold(avg.avg1, appBaselineAvg.avg1) ||
			isGreaterThanThreshold(avg.avg2, appBaselineAvg.avg2)) {
		const mailOptions = {
		  from: from,
		  to: to,
		  subject: subject,
		  text: `app actual: { avg1: ${avg.avg1}, avg2: ${avg.avg2} }
  expected: { avg1: ${appBaselineAvg.avg1}, avg2: ${appBaselineAvg.avg2} }`
		};
		transporter.sendMail(mailOptions, function(error, info){
		  if (error) {
		    console.log(error);
		  } else {
		    console.log('Email sent: ' + info.response);
		  }
		});
	}
	console.log(`app expected: { avg1: ${appBaselineAvg.avg1}, avg2: ${appBaselineAvg.avg2} }`);
	console.log(`app actual: { avg1: ${avg.avg1}, avg2: ${avg.avg2} }`);
});